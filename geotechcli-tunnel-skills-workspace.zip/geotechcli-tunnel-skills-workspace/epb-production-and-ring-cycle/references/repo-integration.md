# repo integration scaffold

## future geotechCLI deterministic tools

- `analyze_epb_ring_cycle`
- `forecast_epb_shift_production`

## recommended core file

- `packages/core/src/geo/tunnel/epb-production.ts`

## tool registry hook

Add schemas for:

- ring number and date
- cycle minutes and target cycle minutes
- downtime reason and downtime minutes
- ring target and ring length
- optional chamber pressure, thrust, torque, screw rate, settlement, and volume loss

## guardrails

Add checks for:

- negative cycle or downtime minutes
- impossible totals such as downtime exceeding the entire shift length without explanation
- missing ring identifiers when multiple rows exist
- invalid ring target or ring length

## swarm and cli follow-on

- add to simulation or operations allowlists for shift review tasks
- add a CLI surface such as `geotech tunnel production-report`
- persist `results`, `final-report`, and `review-checklist` candidates
