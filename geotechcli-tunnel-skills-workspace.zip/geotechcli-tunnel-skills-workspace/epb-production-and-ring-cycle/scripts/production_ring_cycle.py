
#!/usr/bin/env python3
import argparse
import csv
import json
import math
from pathlib import Path


def read_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_csv(path):
    with open(path, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def as_float(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == '':
        return default
    try:
        return float(text)
    except ValueError:
        return default


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'y', 'high', 'mixed'}


def normalize_text(value, default=''):
    return str(value or default).strip()


def load_ground_model(path):
    data = read_json(path)
    strata = data.get('strata', [])
    if not strata and 'layers' in data:
        strata = data['layers']
    groundwater = data.get('groundwater', {})
    tunnel = data.get('tunnel', {})
    return data, strata, groundwater, tunnel


def load_machine(path):
    data = read_json(path)
    return data.get('machine', data)


def select_stratum(strata, depth):
    for stratum in strata:
        start = as_float(stratum.get('from_m', stratum.get('depth_from_m')), 0.0)
        end = as_float(stratum.get('to_m', stratum.get('depth_to_m')), None)
        if end is None:
            continue
        if start <= depth <= end:
            return stratum
    return strata[-1] if strata else {}


def water_pressure_bar(zone, groundwater, axis_depth):
    explicit = as_float(zone.get('water_head_bar'))
    if explicit is not None:
        return explicit
    wt = as_float(groundwater.get('water_table_depth_m'))
    if wt is None:
        return 0.0
    head = max(axis_depth - wt, 0.0)
    return head * 9.81 / 100.0


def uscs_family(uscs):
    u = normalize_text(uscs).upper()
    if u.startswith('C'):
        return 'clay'
    if u.startswith('M'):
        return 'silt'
    if u.startswith('S'):
        return 'sand'
    if u.startswith('G'):
        return 'gravel'
    return 'mixed'


def sensitivity_thresholds(label):
    key = normalize_text(label).lower()
    if key == 'high':
        return (10.0, 15.0)
    if key == 'medium':
        return (15.0, 25.0)
    return (20.0, 35.0)


def safe_write(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)


def canonical_reason(value):
    text = normalize_text(value).lower().replace(' ', '_')
    if not text:
        return 'other'
    if 'cutter' in text:
        return 'cutter_inspection'
    if 'segment' in text:
        return 'segment_supply'
    if 'grout' in text:
        return 'grout'
    return 'other'


def build_markdown(result):
    best = result['best_cycle']
    worst = result['worst_cycle']
    lines = [
        '# EPB Production and Ring Cycle Report',
        f"Date: {result['date']}",
        '',
        '## Production Summary',
        f"- Total advance: {result['total_advance_m']} m",
        f"- Total rings built: {result['total_rings']}",
        f"- Target rings/day: {result['target_rings']}",
        f"- Achievement vs target: {'Met target' if result['met_ring_target'] else 'Below target'}",
        '',
        '## Ring Cycle Performance',
        f"- Average cycle time: {result['avg_cycle_min']} min/ring",
        f"- Best ring cycle: {best['minutes']} min (Ring {best['ring']})",
        f"- Worst ring cycle: {worst['minutes']} min (Ring {worst['ring']})",
        f"- Rings under {result['cycle_target_min']} min target: {result['rings_under_target']} / {result['total_rings']}",
        f"- Performance vs cycle target: {'Better than target' if result['avg_cycle_min'] <= result['cycle_target_min'] else 'Worse than target'}",
        '',
        '## Downtime Breakdown',
        f"- Cutter inspection: {result['downtime_min']['cutter_inspection']} min",
        f"- Segment supply: {result['downtime_min']['segment_supply']} min",
        f"- Grout: {result['downtime_min']['grout']} min",
        f"- Other: {result['downtime_min']['other']} min",
        f"- Total downtime: {result['downtime_min']['total']} min",
        '',
        '## Supervisor Summary',
    ]
    for line in result['supervisor_summary']:
        lines.append(f'- {line}')
    lines += ['', '## JSON', json.dumps(result, indent=2)]
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='analyse EPB production and ring-cycle performance')
    parser.add_argument('--monitoring', default='assets/examples/monitoring.csv')
    parser.add_argument('--machine-config', default='assets/examples/machine_config.json')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--output-json')
    parser.add_argument('--output-markdown')
    args = parser.parse_args()

    machine = load_machine(args.machine_config)
    rows = read_csv(args.monitoring)
    if not rows:
        raise SystemExit('monitoring.csv contains no rows')

    cycles = []
    advance_values = []
    downtime = {'cutter_inspection': 0, 'segment_supply': 0, 'grout': 0, 'other': 0}
    date = normalize_text(rows[0].get('date')) or 'unknown'
    cycle_target = as_float(rows[0].get('target_cycle_min'), 38.0)
    ring_target = int(as_float(rows[0].get('target_rings'), 0) or 0)
    ring_length = as_float(machine.get('ring_length_m'), 1.5)

    for row in rows:
        ring = int(as_float(row.get('ring'), 0) or 0)
        cycle = as_float(row.get('cycle_minutes'), 0.0) or 0.0
        advance = as_float(row.get('advance_m'))
        if advance is None:
            advance = ring_length
        advance_values.append(advance)
        cycles.append({'ring': ring, 'minutes': cycle})
        minutes = int(as_float(row.get('downtime_minutes'), 0.0) or 0)
        reason = canonical_reason(row.get('downtime_reason'))
        downtime[reason] += minutes

    total_rings = len(cycles)
    total_advance = round(sum(advance_values), 1)
    avg_cycle = round(sum(item['minutes'] for item in cycles) / total_rings, 1)
    best = min(cycles, key=lambda item: item['minutes'])
    worst = max(cycles, key=lambda item: item['minutes'])
    rings_under = sum(1 for item in cycles if item['minutes'] < cycle_target)
    downtime['total'] = sum(v for k, v in downtime.items() if k != 'total')
    supervisor_summary = [
        f"The shift {'achieved' if total_rings >= ring_target else 'did not achieve'} the daily production target with {total_rings} rings completed.",
        f"Average ring cycle was {avg_cycle} min/ring, which is {'better' if avg_cycle <= cycle_target else 'worse'} than the {int(cycle_target)} min/ring target.",
        f"Ring {worst['ring']} was the main negative outlier at {int(worst['minutes'])} min and should be reviewed for root cause.",
        f"The largest downtime contributor was {'cutter inspection' if downtime['cutter_inspection'] >= max(downtime['segment_supply'], downtime['grout'], downtime['other']) else max(['segment supply','grout','other'], key=lambda label: downtime[label.replace(' ', '_')])} at {max(downtime['cutter_inspection'], downtime['segment_supply'], downtime['grout'], downtime['other'])} min.",
        "Segment supply delays were the second biggest loss and are the clearest opportunity to improve tomorrow's output." if downtime['segment_supply'] >= downtime['grout'] else 'Review non-segment delays together with cutter and grout controls before the next shift.',
    ]
    result = {
        'skill': 'epb-production-and-ring-cycle',
        'analysis_type': 'shift_production_review',
        'date': date,
        'total_advance_m': total_advance,
        'total_rings': total_rings,
        'target_rings': ring_target,
        'met_ring_target': total_rings >= ring_target,
        'avg_cycle_min': avg_cycle,
        'best_cycle': best,
        'worst_cycle': worst,
        'rings_under_target': rings_under,
        'cycle_target_min': int(cycle_target),
        'downtime_min': downtime,
        'supervisor_summary': supervisor_summary,
        'critical_risks': ['ring-cycle outlier' if worst['minutes'] > cycle_target + 8 else 'none'],
        'missing_inputs': [],
        'recommended_next_tools': ['soft-ground-settlement-observational-control', 'mixed-face-transition-planning'],
    }
    markdown = build_markdown(result)
    if args.output_json:
        safe_write(args.output_json, json.dumps(result, indent=2) + '\n')
    if args.output_markdown:
        safe_write(args.output_markdown, markdown)
    if args.json or (not args.output_json and not args.output_markdown):
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
