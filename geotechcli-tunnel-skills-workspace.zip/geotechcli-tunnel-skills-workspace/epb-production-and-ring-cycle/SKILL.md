---
name: epb-production-and-ring-cycle
description: analyze epb ring-build production, downtime, cycle time losses, and next-shift improvement priorities using monitoring.csv and machine_config.json, with optional ground_model.json and alignment_zones.csv context. use when chatgpt needs a shift production report, ring-cycle outlier review, downtime ranking, or a structured production handoff for tunnel delivery control.
---

# EPB Production and Ring Cycle

## Overview

Turn ring-level monitoring into a production-control report that supervisors can use on the next shift, not just a raw dashboard dump.

## Workflow

1. check that `monitoring.csv` exists and load `machine_config.json` to resolve ring length when advance is not given. use `ground_model.json` and `alignment_zones.csv` only to add context to slow zones.
2. run `python scripts/production_ring_cycle.py --monitoring monitoring.csv --machine-config machine_config.json --json`.
3. preserve the production numbers exactly as returned by the script when writing the markdown report.
4. highlight the worst ring, the dominant downtime source, and the clearest next-shift improvement action.
5. produce the three-part output bundle and map the report into `results`, `final-report`, and `review-checklist` candidates.

## Decision rules

- Use the default local-file contract from `references/input-contract.md` unless the user explicitly supplies different filenames.
- Run the deterministic script first. Do not write the markdown report before the script result exists.
- Preserve script warnings, missing inputs, and blocked conditions in the final narrative.
- Use `references/design-basis.md` to keep the report universal and tied to ITA-AITES, EFNARC, BTS-aligned review language, and observational-method thinking.
- Use `references/repo-integration.md` only when the user asks how to promote the standalone tool into geotechCLI core, guardrails, swarm, or CLI code.

## Script entrypoint

Run:

```bash
python scripts/production_ring_cycle.py --help
```

Default analysis call:

```bash
python scripts/production_ring_cycle.py --json
```

If the user wants a saved file, write JSON with `--output-json <path>` and markdown with `--output-markdown <path>`.

## Output bundle

After the script runs, follow `references/output-pattern.md` and return:

1. a swarm handoff json block
2. an engineering markdown report
3. a project and case-file artifact map

## Resources

- `references/input-contract.md` — shared file contract and accepted fields
- `references/output-pattern.md` — required three-part response bundle
- `references/design-basis.md` — universal reference stack and model philosophy
- `references/repo-integration.md` — future geotechCLI core/tool/guardrail/swarm/cli mapping
- `assets/examples/` — small local examples for testing the script before packaging
