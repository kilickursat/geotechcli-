
#!/usr/bin/env python3
import argparse
import csv
import json
import math
from pathlib import Path


def read_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_csv(path):
    with open(path, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def as_float(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == '':
        return default
    try:
        return float(text)
    except ValueError:
        return default


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'y', 'high', 'mixed'}


def normalize_text(value, default=''):
    return str(value or default).strip()


def load_ground_model(path):
    data = read_json(path)
    strata = data.get('strata', [])
    if not strata and 'layers' in data:
        strata = data['layers']
    groundwater = data.get('groundwater', {})
    tunnel = data.get('tunnel', {})
    return data, strata, groundwater, tunnel


def load_machine(path):
    data = read_json(path)
    return data.get('machine', data)


def select_stratum(strata, depth):
    for stratum in strata:
        start = as_float(stratum.get('from_m', stratum.get('depth_from_m')), 0.0)
        end = as_float(stratum.get('to_m', stratum.get('depth_to_m')), None)
        if end is None:
            continue
        if start <= depth <= end:
            return stratum
    return strata[-1] if strata else {}


def water_pressure_bar(zone, groundwater, axis_depth):
    explicit = as_float(zone.get('water_head_bar'))
    if explicit is not None:
        return explicit
    wt = as_float(groundwater.get('water_table_depth_m'))
    if wt is None:
        return 0.0
    head = max(axis_depth - wt, 0.0)
    return head * 9.81 / 100.0


def uscs_family(uscs):
    u = normalize_text(uscs).upper()
    if u.startswith('C'):
        return 'clay'
    if u.startswith('M'):
        return 'silt'
    if u.startswith('S'):
        return 'sand'
    if u.startswith('G'):
        return 'gravel'
    return 'mixed'


def sensitivity_thresholds(label):
    key = normalize_text(label).lower()
    if key == 'high':
        return (10.0, 15.0)
    if key == 'medium':
        return (15.0, 25.0)
    return (20.0, 35.0)


def safe_write(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)


def trough_k(zone, stratum):
    family = uscs_family(stratum.get('uscs'))
    if family == 'clay':
        return 0.45
    if family == 'sand':
        return 0.55
    if family == 'gravel':
        return 0.60
    return 0.50


def zone_observation(zone, strata, groundwater, machine, monitoring_rows):
    diameter = as_float(machine.get('diameter_m'), 0.0)
    cover = as_float(zone.get('cover_m'), 0.0)
    axis_depth = cover + diameter / 2.0
    stratum = select_stratum(strata, axis_depth)
    k = trough_k(zone, stratum)
    i_val = k * axis_depth
    area = math.pi * diameter * diameter / 4.0 if diameter else 0.0
    zone_rows = [row for row in monitoring_rows if normalize_text(row.get('zone_id')) == normalize_text(zone.get('zone_id'))]
    observed_smax = max((as_float(row.get('settlement_mm'), 0.0) or 0.0) for row in zone_rows) if zone_rows else 0.0
    observed_vl = max((as_float(row.get('volume_loss_percent'), 0.0) or 0.0) for row in zone_rows) if zone_rows else 0.0
    if observed_vl > 0 and i_val > 0 and area > 0:
        predicted_smax = observed_vl / 100.0 * area / (math.sqrt(2.0 * math.pi) * i_val) * 1000.0
    else:
        predicted_smax = 0.0
    if observed_smax > 0 and i_val > 0 and area > 0:
        back_vl = observed_smax / 1000.0 * math.sqrt(2.0 * math.pi) * i_val / area * 100.0
    else:
        back_vl = observed_vl
    amber, red = sensitivity_thresholds(zone.get('settlement_sensitivity_class'))
    if observed_smax >= red:
        trigger = 'RED'
        action = 'hold current optimisation, tighten chamber and advance control, intensify review and pre-defined contingency actions'
    elif observed_smax >= amber:
        trigger = 'AMBER'
        action = 'keep excavation under review, reduce variability, and confirm the next trigger threshold before continuing'
    else:
        trigger = 'GREEN'
        action = 'continue within the planned control band and keep routine monitoring active'
    return {
        'zone_id': normalize_text(zone.get('zone_id')),
        'cover_m': cover,
        'axis_depth_m': round(axis_depth, 2),
        'trough_k': round(k, 2),
        'trough_i_m': round(i_val, 2),
        'predicted_smax_mm': round(predicted_smax, 1),
        'observed_smax_mm': round(observed_smax, 1),
        'backanalyzed_volume_loss_percent': round(back_vl, 2),
        'trigger_state': trigger,
        'action': action,
    }


def build_markdown(result):
    lines = [
        '# Soft ground settlement observational control report',
        '',
        '## basis and assumptions',
        '- peck-style trough screening with observational-method trigger logic.',
        '- observed settlement governs the trigger state when monitoring is available.',
        '',
        '## key findings',
    ]
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: predicted Smax {zone['predicted_smax_mm']} mm, observed Smax {zone['observed_smax_mm']} mm, trigger {zone['trigger_state']}.")
    lines += ['', '## design or operational actions']
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: {zone['action']}.")
    lines += ['', '## limitations']
    for item in result['limitations']:
        lines.append(f'- {item}')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='predict and back-analyse settlement for observational control')
    parser.add_argument('--ground-model', default='assets/examples/ground_model.json')
    parser.add_argument('--machine-config', default='assets/examples/machine_config.json')
    parser.add_argument('--alignment-zones', default='assets/examples/alignment_zones.csv')
    parser.add_argument('--monitoring', default='assets/examples/monitoring.csv')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--output-json')
    parser.add_argument('--output-markdown')
    args = parser.parse_args()

    _, strata, groundwater, _ = load_ground_model(args.ground_model)
    machine = load_machine(args.machine_config)
    zones = read_csv(args.alignment_zones)
    monitoring_rows = read_csv(args.monitoring)
    zone_results = [zone_observation(zone, strata, groundwater, machine, monitoring_rows) for zone in zones]
    result = {
        'skill': 'soft-ground-settlement-observational-control',
        'analysis_type': 'settlement_trigger_review',
        'zone_results': zone_results,
        'critical_risks': [zone['zone_id'] for zone in zone_results if zone['trigger_state'] == 'RED'],
        'missing_inputs': [],
        'recommended_next_tools': ['epb-face-support-window', 'epb-production-and-ring-cycle'],
        'limitations': [
            'predicted settlement is a screening estimate and must be reconciled against project-specific monitoring geometry.',
            'trigger thresholds are generic by settlement sensitivity class and should be replaced by project trigger sheets where available.',
        ],
    }
    markdown = build_markdown(result)
    if args.output_json:
        safe_write(args.output_json, json.dumps(result, indent=2) + '\n')
    if args.output_markdown:
        safe_write(args.output_markdown, markdown)
    if args.json or (not args.output_json and not args.output_markdown):
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
