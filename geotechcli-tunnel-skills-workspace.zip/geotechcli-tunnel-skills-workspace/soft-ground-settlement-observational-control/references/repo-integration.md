# repo integration scaffold

## future geotechCLI deterministic tools

- `backanalyze_tunnel_volume_loss`
- `evaluate_settlement_triggers`
- optional helper: `predict_soft_ground_settlement`

## recommended core file

- `packages/core/src/geo/tunnel/epb-settlement-control.ts`

## tool registry hook

Add schemas for:

- tunnel diameter and cover by zone
- settlement sensitivity class
- measured settlement or volume loss by zone
- groundwater depth or head
- optional offset and trough parameter overrides

## guardrails

Add checks for:

- non-positive tunnel diameter or cover
- negative settlement magnitudes where absolute value is expected
- invalid volume loss percent
- trigger thresholds not in ascending order

## swarm and cli follow-on

- add to simulation and reviewer workflows
- add a CLI surface such as `geotech tunnel settlement-control`
- persist `results`, `review-checklist`, `acceptance-status`, and `issues-and-corrections` candidates
