---
name: soft-ground-settlement-observational-control
description: predict and back-analyze soft-ground settlement, volume loss, and trigger status for mechanized tunnelling using ground_model.json, machine_config.json, alignment_zones.csv, and monitoring.csv. use when chatgpt needs peck-style settlement screening, observed-versus-predicted review, trigger-state actions, or an observational-method control note for tunnel operations.
---

# Soft Ground Settlement Observational Control

## Overview

Connect predicted settlement, observed settlement, and pre-defined actions so the tunnel team can respond through an observational-method loop.

## Workflow

1. check that all four default files exist.
2. run `python scripts/settlement_control.py --ground-model ground_model.json --machine-config machine_config.json --alignment-zones alignment_zones.csv --monitoring monitoring.csv --json`.
3. read the predicted settlement, observed settlement, back-analyzed volume loss, and trigger status for each zone.
4. if the script returns `trigger_state=red`, state the pre-defined action path before any narrative optimisation.
5. produce the three-part output bundle with explicit observational-method language and an artifact map for monitoring, results, and acceptance status.

## Decision rules

- Use the default local-file contract from `references/input-contract.md` unless the user explicitly supplies different filenames.
- Run the deterministic script first. Do not write the markdown report before the script result exists.
- Preserve script warnings, missing inputs, and blocked conditions in the final narrative.
- Use `references/design-basis.md` to keep the report universal and tied to ITA-AITES, EFNARC, BTS-aligned review language, and observational-method thinking.
- Use `references/repo-integration.md` only when the user asks how to promote the standalone tool into geotechCLI core, guardrails, swarm, or CLI code.

## Script entrypoint

Run:

```bash
python scripts/settlement_control.py --help
```

Default analysis call:

```bash
python scripts/settlement_control.py --json
```

If the user wants a saved file, write JSON with `--output-json <path>` and markdown with `--output-markdown <path>`.

## Output bundle

After the script runs, follow `references/output-pattern.md` and return:

1. a swarm handoff json block
2. an engineering markdown report
3. a project and case-file artifact map

## Resources

- `references/input-contract.md` — shared file contract and accepted fields
- `references/output-pattern.md` — required three-part response bundle
- `references/design-basis.md` — universal reference stack and model philosophy
- `references/repo-integration.md` — future geotechCLI core/tool/guardrail/swarm/cli mapping
- `assets/examples/` — small local examples for testing the script before packaging
