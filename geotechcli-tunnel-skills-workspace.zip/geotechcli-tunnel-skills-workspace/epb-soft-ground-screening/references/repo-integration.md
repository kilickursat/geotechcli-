# repo integration scaffold

## future geotechCLI deterministic tools

- `screen_epb_soft_ground`
- optional helper: `score_soft_ground_zone`

## recommended core file

- `packages/core/src/geo/tunnel/epb-soft-ground.ts`

## tool registry hook

Register a new tool in `packages/core/src/agents/tools.ts` with a JSON schema that accepts:

- tunnel diameter and machine capability limits
- per-zone cover, water head, mixed-face flag, boulder risk
- fines, PI, permeability, USCS, cu or phi

## guardrails

Add checks for:

- non-positive tunnel diameter
- cover below crown depth or negative cover
- invalid water head
- permeability below zero
- fines outside 0-100 percent
- contradictory soft-ground inputs such as `ground_type=soft_ground` with rock-only properties and no soil parameters

## swarm and cli follow-on

- add the tool to the simulation allowlist when the interpretation agent has already normalized zone data
- add a CLI surface such as `geotech tunnel epb-screen`
- map outputs into `ground-model`, `analysis-plan`, and `results` case-file artifacts
