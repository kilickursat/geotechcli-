---
name: epb-soft-ground-screening
description: screen earth pressure balance tunnelling suitability in soft-ground or transitional tunnel projects using ground_model.json, machine_config.json, and alignment_zones.csv. use when chatgpt needs a zone-by-zone epb versus slurry versus convertible screening, a soft-ground risk ranking, a missing-data list, or an operational handoff before detailed pressure, conditioning, production, or settlement work.
---

# EPB Soft Ground Screening

## Overview

Screen whether EPB is a defensible primary machine mode for each chainage zone before deeper pressure, conditioning, or production analysis.

## Workflow

1. check that `ground_model.json`, `machine_config.json`, and `alignment_zones.csv` exist. use `monitoring.csv` only if the user asks to reconcile the screening against live performance.
2. run `python scripts/epb_soft_ground_screen.py --ground-model ground_model.json --machine-config machine_config.json --alignment-zones alignment_zones.csv --json`.
3. read the zone-level scores, recommendation class, missing inputs, and control notes.
4. produce the three-part output bundle using `references/output-pattern.md`.
5. consult `references/repo-integration.md` if the user wants to promote the standalone tool into the geotechCLI repo.

## Decision rules

- Use the default local-file contract from `references/input-contract.md` unless the user explicitly supplies different filenames.
- Run the deterministic script first. Do not write the markdown report before the script result exists.
- Preserve script warnings, missing inputs, and blocked conditions in the final narrative.
- Use `references/design-basis.md` to keep the report universal and tied to ITA-AITES, EFNARC, BTS-aligned review language, and observational-method thinking.
- Use `references/repo-integration.md` only when the user asks how to promote the standalone tool into geotechCLI core, guardrails, swarm, or CLI code.

## Script entrypoint

Run:

```bash
python scripts/epb_soft_ground_screen.py --help
```

Default analysis call:

```bash
python scripts/epb_soft_ground_screen.py --json
```

If the user wants a saved file, write JSON with `--output-json <path>` and markdown with `--output-markdown <path>`.

## Output bundle

After the script runs, follow `references/output-pattern.md` and return:

1. a swarm handoff json block
2. an engineering markdown report
3. a project and case-file artifact map

## Resources

- `references/input-contract.md` — shared file contract and accepted fields
- `references/output-pattern.md` — required three-part response bundle
- `references/design-basis.md` — universal reference stack and model philosophy
- `references/repo-integration.md` — future geotechCLI core/tool/guardrail/swarm/cli mapping
- `assets/examples/` — small local examples for testing the script before packaging
