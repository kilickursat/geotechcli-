
#!/usr/bin/env python3
import argparse
import csv
import json
import math
from pathlib import Path


def read_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_csv(path):
    with open(path, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def as_float(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == '':
        return default
    try:
        return float(text)
    except ValueError:
        return default


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'y', 'high', 'mixed'}


def normalize_text(value, default=''):
    return str(value or default).strip()


def load_ground_model(path):
    data = read_json(path)
    strata = data.get('strata', [])
    if not strata and 'layers' in data:
        strata = data['layers']
    groundwater = data.get('groundwater', {})
    tunnel = data.get('tunnel', {})
    return data, strata, groundwater, tunnel


def load_machine(path):
    data = read_json(path)
    return data.get('machine', data)


def select_stratum(strata, depth):
    for stratum in strata:
        start = as_float(stratum.get('from_m', stratum.get('depth_from_m')), 0.0)
        end = as_float(stratum.get('to_m', stratum.get('depth_to_m')), None)
        if end is None:
            continue
        if start <= depth <= end:
            return stratum
    return strata[-1] if strata else {}


def water_pressure_bar(zone, groundwater, axis_depth):
    explicit = as_float(zone.get('water_head_bar'))
    if explicit is not None:
        return explicit
    wt = as_float(groundwater.get('water_table_depth_m'))
    if wt is None:
        return 0.0
    head = max(axis_depth - wt, 0.0)
    return head * 9.81 / 100.0


def uscs_family(uscs):
    u = normalize_text(uscs).upper()
    if u.startswith('C'):
        return 'clay'
    if u.startswith('M'):
        return 'silt'
    if u.startswith('S'):
        return 'sand'
    if u.startswith('G'):
        return 'gravel'
    return 'mixed'


def sensitivity_thresholds(label):
    key = normalize_text(label).lower()
    if key == 'high':
        return (10.0, 15.0)
    if key == 'medium':
        return (15.0, 25.0)
    return (20.0, 35.0)


def safe_write(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)


def zone_assessment(zone, strata, groundwater, machine):
    diameter = as_float(machine.get('diameter_m'), 0.0)
    cover = as_float(zone.get('cover_m'), 0.0)
    axis_depth = cover + diameter / 2.0
    stratum = select_stratum(strata, axis_depth)
    fines = as_float(stratum.get('fines_pct'), 0.0)
    pi = as_float(stratum.get('plasticity_index_pct'), 0.0)
    perm = as_float(stratum.get('permeability_m_s'), 0.0)
    family = uscs_family(stratum.get('uscs'))
    water_bar = water_pressure_bar(zone, groundwater, axis_depth)
    mixed = as_bool(zone.get('mixed_face_flag'))
    boulder = normalize_text(zone.get('boulder_risk')).lower()

    score = 100.0
    reasons = []
    risks = []
    conditioning = []
    missing = []

    if diameter <= 0:
        missing.append('machine diameter_m')
    if cover <= 0:
        missing.append('zone cover_m')
    if not stratum:
        missing.append('ground model stratum at tunnel axis')

    if mixed:
        score -= 22
        reasons.append('mixed-face transition reduces EPB robustness')
        risks.append('mixed-face instability and cutterhead imbalance')
    if boulder in {'medium', 'high'}:
        score -= 12 if boulder == 'medium' else 18
        reasons.append(f'boulder risk is {boulder}')
        risks.append('blockage and local cutter overload')
    if perm and perm > 1.0e-4:
        score -= 22
        reasons.append('high permeability pushes the zone toward slurry or convertible review')
        risks.append('rapid inflow and pressure-control sensitivity')
    elif perm and perm > 1.0e-5:
        score -= 10
        reasons.append('moderately permeable ground needs tighter EPB pressure control')
    if fines < 10:
        score -= 18
        reasons.append('very low fines reduce natural face paste quality')
        conditioning.append('strong foam or slurry-assist conditioning demand')
    elif 15 <= fines <= 60:
        score += 6
        reasons.append('fines range is generally compatible with EPB support paste')
    if family == 'clay' and pi >= 15:
        score += 3
        conditioning.append('anti-clay polymer and tool-cleaning controls')
        risks.append('sticky face and screw conveyor build-up')
    elif family in {'sand', 'gravel'}:
        conditioning.append('foam and water-retention control')
    if water_bar > 5.0:
        score -= 12
        reasons.append('high water head narrows the operational envelope')
        risks.append('elevated face pressure and sealing demand')
    elif water_bar > 3.0:
        score -= 6
        reasons.append('moderate water head requires disciplined chamber control')
    if cover and diameter and cover / diameter < 0.7:
        score -= 20
        reasons.append('very low cover raises blowout and settlement sensitivity')
        risks.append('low cover pressure-control risk')
    elif cover and diameter and cover / diameter < 1.0:
        score -= 8
        reasons.append('cover less than one diameter requires tighter surface control')

    score = max(0.0, min(score, 100.0))
    if score >= 75:
        recommendation = 'EPB_PREFERRED'
    elif score >= 55:
        recommendation = 'EPB_WITH_TIGHT_CONTROLS'
    elif score >= 40:
        recommendation = 'CONVERTIBLE_OR_SLURRY_REVIEW'
    else:
        recommendation = 'SLURRY_PREFERRED'

    return {
        'zone_id': normalize_text(zone.get('zone_id')),
        'chainage_from_m': as_float(zone.get('chainage_from_m')),
        'chainage_to_m': as_float(zone.get('chainage_to_m')),
        'ground_type': normalize_text(zone.get('ground_type')),
        'cover_m': cover,
        'axis_depth_m': round(axis_depth, 2),
        'uscs': normalize_text(stratum.get('uscs')),
        'material': normalize_text(stratum.get('material')),
        'fines_pct': fines,
        'plasticity_index_pct': pi,
        'permeability_m_s': perm,
        'water_head_bar': round(water_bar, 2),
        'suitability_score': round(score, 1),
        'recommendation': recommendation,
        'conditioning_focus': conditioning,
        'key_reasons': reasons,
        'critical_risks': risks,
        'missing_inputs': missing,
    }


def build_markdown(result):
    lines = [
        '# EPB soft ground screening report',
        '',
        '## basis and assumptions',
        '- universal soft-ground EPB screening using machine limits, cover, groundwater, fines, plasticity, permeability, and mixed-face flags.',
        '- result is a production-oriented screening, not a contractual machine selection submission.',
        '',
        '## key findings',
    ]
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: {zone['recommendation']} (score {zone['suitability_score']}/100) with water head {zone['water_head_bar']} bar and cover {zone['cover_m']} m.")
    lines += ['', '## design or operational actions']
    for zone in result['zone_results']:
        actions = zone['conditioning_focus'] or ['no special conditioning emphasis flagged']
        lines.append(f"- {zone['zone_id']}: " + '; '.join(actions))
    lines += ['', '## limitations']
    missing = result['missing_inputs'] or ['no critical missing inputs flagged by the screening script']
    for item in missing:
        lines.append(f'- {item}')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='screen EPB soft-ground suitability by zone')
    parser.add_argument('--ground-model', default='assets/examples/ground_model.json')
    parser.add_argument('--machine-config', default='assets/examples/machine_config.json')
    parser.add_argument('--alignment-zones', default='assets/examples/alignment_zones.csv')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--output-json')
    parser.add_argument('--output-markdown')
    args = parser.parse_args()

    _, strata, groundwater, _ = load_ground_model(args.ground_model)
    machine = load_machine(args.machine_config)
    zones = read_csv(args.alignment_zones)
    zone_results = [zone_assessment(zone, strata, groundwater, machine) for zone in zones]
    missing_inputs = sorted({item for zone in zone_results for item in zone['missing_inputs']})
    overall = max(zone_results, key=lambda z: z['suitability_score'])['recommendation'] if zone_results else 'NO_DATA'
    result = {
        'skill': 'epb-soft-ground-screening',
        'analysis_type': 'zone_screening',
        'overall_recommendation': overall,
        'zone_results': zone_results,
        'critical_risks': sorted({r for zone in zone_results for r in zone['critical_risks']}),
        'missing_inputs': missing_inputs,
        'recommended_next_tools': [
            'epb-face-support-window',
            'epb-conditioning-clogging',
            'mixed-face-transition-planning',
        ],
        'limitations': [
            'screening output only; confirm with project-specific design and live operating response.',
            'suitability score combines geotechnical and machine-operability cues and is not a procurement score.',
        ],
    }
    markdown = build_markdown(result)
    if args.output_json:
        safe_write(args.output_json, json.dumps(result, indent=2) + '\n')
    if args.output_markdown:
        safe_write(args.output_markdown, markdown)
    if args.json or (not args.output_json and not args.output_markdown):
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
