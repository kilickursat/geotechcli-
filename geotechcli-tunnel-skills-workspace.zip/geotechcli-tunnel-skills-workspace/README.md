# geotechcli tunnel skill workspace

This workspace contains six standalone packaged skills that fill the current EPB and soft-ground gap identified in geotechCLI's existing agent and deterministic tunnel stack. The current repo already exposes rock-oriented TBM performance tools, TBM type selection, swarm review, and case-file persistence, but the uploaded code also states that a validated EPB-in-clay penetration model is still missing and that soft-ground performance needs a stronger deterministic bridge. fileciteturn14file13 fileciteturn14file12

## included skills

- `epb-soft-ground-screening`
- `epb-face-support-window`
- `epb-conditioning-clogging`
- `epb-production-and-ring-cycle`
- `soft-ground-settlement-observational-control`
- `mixed-face-transition-planning`

## why this bundle fits geotechCLI

geotechCLI already uses a deterministic-first architecture, explicit tool registration, swarm role separation, and case-file artifacts. New production tunnel tools are expected to be added in `packages/core/src/geo/`, then registered in `packages/core/src/agents/tools.ts`, guarded in `guardrails.ts`, and surfaced into the swarm/tool policy and CLI. Each skill therefore includes a repo-integration note that maps the standalone script to the future geotechCLI core function, tool name, guardrails, swarm access, and CLI surface. fileciteturn14file14turn14file1turn14file2

## build order

1. validate every skill locally
2. package each skill individually
3. test the scripts against the example files in `assets/examples/`
4. choose which standalone tool contracts should be promoted into `packages/core/src/geo/tunnel/`
5. add the matching guardrails, swarm allowlists, and CLI commands in the repo

## package all skills

Run from this workspace root:

```bash
bash package_all.sh
```

Packaged zips are written into `dist/<skill-name>/skill.zip`.
