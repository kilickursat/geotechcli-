# repo integration scaffold

## future geotechCLI deterministic tools

- `evaluate_mixed_face_transition_risk`
- optional helper: `estimate_transition_control_band`

## recommended core file

- `packages/core/src/geo/tunnel/mixed-face-transition.ts`

## tool registry hook

Add schemas for:

- chainage zone lengths
- cover, water head, mixed-face flag, boulder risk
- material contrast proxies such as fines, PI, permeability, cu, phi
- machine torque, thrust, and chamber pressure limits

## guardrails

Add checks for:

- transition zones with zero length
- mixed-face flag without any contrast driver
- negative water head or cover
- recommendations outside machine pressure limits

## swarm and cli follow-on

- add to the simulation allowlist
- add a CLI surface such as `geotech tunnel mixed-face-plan`
- persist `analysis-plan`, `results`, `review-checklist`, and `issues-and-corrections` candidates
