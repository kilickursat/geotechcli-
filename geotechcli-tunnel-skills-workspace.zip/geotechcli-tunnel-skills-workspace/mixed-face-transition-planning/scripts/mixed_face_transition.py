
#!/usr/bin/env python3
import argparse
import csv
import json
import math
from pathlib import Path


def read_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_csv(path):
    with open(path, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def as_float(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == '':
        return default
    try:
        return float(text)
    except ValueError:
        return default


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'y', 'high', 'mixed'}


def normalize_text(value, default=''):
    return str(value or default).strip()


def load_ground_model(path):
    data = read_json(path)
    strata = data.get('strata', [])
    if not strata and 'layers' in data:
        strata = data['layers']
    groundwater = data.get('groundwater', {})
    tunnel = data.get('tunnel', {})
    return data, strata, groundwater, tunnel


def load_machine(path):
    data = read_json(path)
    return data.get('machine', data)


def select_stratum(strata, depth):
    for stratum in strata:
        start = as_float(stratum.get('from_m', stratum.get('depth_from_m')), 0.0)
        end = as_float(stratum.get('to_m', stratum.get('depth_to_m')), None)
        if end is None:
            continue
        if start <= depth <= end:
            return stratum
    return strata[-1] if strata else {}


def water_pressure_bar(zone, groundwater, axis_depth):
    explicit = as_float(zone.get('water_head_bar'))
    if explicit is not None:
        return explicit
    wt = as_float(groundwater.get('water_table_depth_m'))
    if wt is None:
        return 0.0
    head = max(axis_depth - wt, 0.0)
    return head * 9.81 / 100.0


def uscs_family(uscs):
    u = normalize_text(uscs).upper()
    if u.startswith('C'):
        return 'clay'
    if u.startswith('M'):
        return 'silt'
    if u.startswith('S'):
        return 'sand'
    if u.startswith('G'):
        return 'gravel'
    return 'mixed'


def sensitivity_thresholds(label):
    key = normalize_text(label).lower()
    if key == 'high':
        return (10.0, 15.0)
    if key == 'medium':
        return (15.0, 25.0)
    return (20.0, 35.0)


def safe_write(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)


def transition_assessment(zone, strata, groundwater, machine):
    diameter = as_float(machine.get('diameter_m'), 0.0)
    cover = as_float(zone.get('cover_m'), 0.0)
    zone_length = (as_float(zone.get('chainage_to_m'), 0.0) or 0.0) - (as_float(zone.get('chainage_from_m'), 0.0) or 0.0)
    axis_depth = cover + diameter / 2.0
    stratum = select_stratum(strata, axis_depth)
    fines = as_float(stratum.get('fines_pct'), 0.0)
    perm = as_float(stratum.get('permeability_m_s'), 0.0)
    water_bar = water_pressure_bar(zone, groundwater, axis_depth)
    mixed = as_bool(zone.get('mixed_face_flag')) or normalize_text(zone.get('ground_type')).lower() == 'mixed'
    boulder = normalize_text(zone.get('boulder_risk')).lower()

    score = 0.0
    drivers = []
    controls = []

    if mixed:
        score += 35
        drivers.append('explicit mixed-face flag')
    if boulder in {'medium', 'high'}:
        score += 12 if boulder == 'medium' else 18
        drivers.append(f'boulder risk {boulder}')
    if water_bar > 2.0:
        score += 10
        drivers.append('elevated water head')
    if perm and perm > 1e-5:
        score += 8
        drivers.append('permeable transition material')
    if zone_length and diameter and zone_length < diameter:
        score += 10
        drivers.append('short abrupt transition length')
    if cover and diameter and cover / diameter < 1.0:
        score += 8
        drivers.append('cover less than one diameter')
    if fines < 15:
        score += 6
        drivers.append('low fines reduce face paste continuity in transition')

    if score >= 55:
        risk = 'CRITICAL'
    elif score >= 40:
        risk = 'HIGH'
    elif score >= 25:
        risk = 'ELEVATED'
    else:
        risk = 'ROUTINE'

    controls.append('tighten chamber pressure operating band through the transition')
    controls.append('reduce advance variability and verify screw discharge stability')
    if risk in {'HIGH', 'CRITICAL'}:
        controls.append('increase cutterhead inspection frequency and pre-plan intervention triggers')
        controls.append('increase settlement and machine parameter review frequency before and through the transition')
    if water_bar > 2.0:
        controls.append('couple pressure steps with groundwater response checks')
    if boulder in {'medium', 'high'}:
        controls.append('prepare blockage and local overload response for coarse inclusions')

    return {
        'zone_id': normalize_text(zone.get('zone_id')),
        'chainage_from_m': as_float(zone.get('chainage_from_m')),
        'chainage_to_m': as_float(zone.get('chainage_to_m')),
        'transition_risk_class': risk,
        'risk_score': round(score, 1),
        'dominant_drivers': drivers,
        'mandatory_controls': controls,
    }


def build_markdown(result):
    lines = [
        '# Mixed-face transition planning report',
        '',
        '## basis and assumptions',
        '- transition plan screened from mixed-face flags, cover, water head, permeability, zone length, and boulder cues.',
        '- mandatory controls are written as operational actions, not as generic advisory wording.',
        '',
        '## key findings',
    ]
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: {zone['transition_risk_class']} transition risk (score {zone['risk_score']}/100).")
    lines += ['', '## design or operational actions']
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: " + '; '.join(zone['mandatory_controls']))
    lines += ['', '## limitations']
    for item in result['limitations']:
        lines.append(f'- {item}')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='plan controls for mixed-face transition zones')
    parser.add_argument('--ground-model', default='assets/examples/ground_model.json')
    parser.add_argument('--machine-config', default='assets/examples/machine_config.json')
    parser.add_argument('--alignment-zones', default='assets/examples/alignment_zones.csv')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--output-json')
    parser.add_argument('--output-markdown')
    args = parser.parse_args()

    _, strata, groundwater, _ = load_ground_model(args.ground_model)
    machine = load_machine(args.machine_config)
    zones = read_csv(args.alignment_zones)
    filtered = [zone for zone in zones if as_bool(zone.get('mixed_face_flag')) or normalize_text(zone.get('ground_type')).lower() == 'mixed']
    zone_results = [transition_assessment(zone, strata, groundwater, machine) for zone in filtered]
    result = {
        'skill': 'mixed-face-transition-planning',
        'analysis_type': 'transition_control_plan',
        'zone_results': zone_results,
        'critical_risks': [zone['zone_id'] for zone in zone_results if zone['transition_risk_class'] in {'HIGH', 'CRITICAL'}],
        'missing_inputs': [],
        'recommended_next_tools': ['epb-face-support-window', 'epb-conditioning-clogging'],
        'limitations': [
            'transition risk is screened from zone-level contrast cues and does not replace detailed geology or machine intervention planning.',
            'controls should be merged with the project inspection, probing, and instrumentation plans before execution.',
        ],
    }
    markdown = build_markdown(result)
    if args.output_json:
        safe_write(args.output_json, json.dumps(result, indent=2) + '\n')
    if args.output_markdown:
        safe_write(args.output_markdown, markdown)
    if args.json or (not args.output_json and not args.output_markdown):
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
