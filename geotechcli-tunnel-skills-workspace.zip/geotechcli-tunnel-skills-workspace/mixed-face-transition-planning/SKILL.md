---
name: mixed-face-transition-planning
description: plan mixed-face transition controls for mechanized tunnelling using ground_model.json, machine_config.json, and alignment_zones.csv, with optional monitoring.csv for live confirmation. use when chatgpt needs a zone-by-zone transition risk class, pressure and advance controls, inspection triggers, or a construction handoff for transitions between soft ground, gravel lenses, and mixed face conditions.
---

# Mixed Face Transition Planning

## Overview

Turn mixed-face geometry and machine limits into an operational transition plan with measurable controls rather than generic caution language.

## Workflow

1. check that `ground_model.json`, `machine_config.json`, and `alignment_zones.csv` exist. use `monitoring.csv` only if the user wants to compare the plan against actual performance.
2. run `python scripts/mixed_face_transition.py --ground-model ground_model.json --machine-config machine_config.json --alignment-zones alignment_zones.csv --json`.
3. read the transition risk score, dominant drivers, and mandatory controls for each mixed or variable zone.
4. if the script identifies a critical transition, keep the report action-oriented: reduced advance, tighter pressure control, inspection, probing, and intensified monitoring.
5. produce the three-part output bundle and map the plan into `analysis-plan`, `results`, and `review-checklist` candidates.

## Decision rules

- Use the default local-file contract from `references/input-contract.md` unless the user explicitly supplies different filenames.
- Run the deterministic script first. Do not write the markdown report before the script result exists.
- Preserve script warnings, missing inputs, and blocked conditions in the final narrative.
- Use `references/design-basis.md` to keep the report universal and tied to ITA-AITES, EFNARC, BTS-aligned review language, and observational-method thinking.
- Use `references/repo-integration.md` only when the user asks how to promote the standalone tool into geotechCLI core, guardrails, swarm, or CLI code.

## Script entrypoint

Run:

```bash
python scripts/mixed_face_transition.py --help
```

Default analysis call:

```bash
python scripts/mixed_face_transition.py --json
```

If the user wants a saved file, write JSON with `--output-json <path>` and markdown with `--output-markdown <path>`.

## Output bundle

After the script runs, follow `references/output-pattern.md` and return:

1. a swarm handoff json block
2. an engineering markdown report
3. a project and case-file artifact map

## Resources

- `references/input-contract.md` — shared file contract and accepted fields
- `references/output-pattern.md` — required three-part response bundle
- `references/design-basis.md` — universal reference stack and model philosophy
- `references/repo-integration.md` — future geotechCLI core/tool/guardrail/swarm/cli mapping
- `assets/examples/` — small local examples for testing the script before packaging
