---
name: epb-conditioning-clogging
description: evaluate soil conditioning demand, clogging likelihood, and consumable strategy for epb tunnelling in soft ground using ground_model.json, machine_config.json, and alignment_zones.csv. use when chatgpt needs foam or polymer windows, anti-clay actions, clogging risk classes, or an operations handoff for difficult sticky or variable face ground.
---

# EPB Conditioning and Clogging

## Overview

Translate fines, plasticity, permeability, and ground type into a production-ready conditioning and clogging control plan.

## Workflow

1. check that `ground_model.json`, `machine_config.json`, and `alignment_zones.csv` exist.
2. run `python scripts/conditioning_clogging.py --ground-model ground_model.json --machine-config machine_config.json --alignment-zones alignment_zones.csv --json`.
3. read the conditioning family, clogging score, FIR and FER ranges, and anti-clay controls.
4. if the script flags a coarse highly permeable zone, carry that forward as a conditioning warning rather than pretending EPB foam alone is sufficient.
5. produce the three-part output bundle and list the consumable and monitoring variables that must be tracked in the next shift.

## Decision rules

- Use the default local-file contract from `references/input-contract.md` unless the user explicitly supplies different filenames.
- Run the deterministic script first. Do not write the markdown report before the script result exists.
- Preserve script warnings, missing inputs, and blocked conditions in the final narrative.
- Use `references/design-basis.md` to keep the report universal and tied to ITA-AITES, EFNARC, BTS-aligned review language, and observational-method thinking.
- Use `references/repo-integration.md` only when the user asks how to promote the standalone tool into geotechCLI core, guardrails, swarm, or CLI code.

## Script entrypoint

Run:

```bash
python scripts/conditioning_clogging.py --help
```

Default analysis call:

```bash
python scripts/conditioning_clogging.py --json
```

If the user wants a saved file, write JSON with `--output-json <path>` and markdown with `--output-markdown <path>`.

## Output bundle

After the script runs, follow `references/output-pattern.md` and return:

1. a swarm handoff json block
2. an engineering markdown report
3. a project and case-file artifact map

## Resources

- `references/input-contract.md` — shared file contract and accepted fields
- `references/output-pattern.md` — required three-part response bundle
- `references/design-basis.md` — universal reference stack and model philosophy
- `references/repo-integration.md` — future geotechCLI core/tool/guardrail/swarm/cli mapping
- `assets/examples/` — small local examples for testing the script before packaging
