# input contract

Use the same four local files across the tunnel skill workspace unless the user explicitly provides different filenames.

## default files

- `ground_model.json`
- `machine_config.json`
- `alignment_zones.csv`
- `monitoring.csv`

## ground_model.json

Expect a tunnel diameter block, groundwater block, and one or more strata. Each stratum should provide at least depth range, material description, USCS symbol when known, and either strength or stiffness indicators. Common fields accepted by the scripts include:

- `from_m`, `to_m`
- `material`, `uscs`
- `unit_weight_kN_m3`
- `fines_pct`, `liquid_limit_pct`, `plasticity_index_pct`
- `permeability_m_s`
- `cu_kPa` or `phi_deg`

## machine_config.json

Expect one machine object with TBM and ring-build limits. Common fields accepted by the scripts include:

- `diameter_m`
- `shield_length_m`
- `ring_length_m`
- `cutterhead_opening_ratio_pct`
- `installed_thrust_kN`
- `installed_torque_kNm`
- `rpm_min`, `rpm_max`
- `chamber_pressure_min_bar`, `chamber_pressure_max_bar`
- `screw_conveyor_capacity_m3_h`

## alignment_zones.csv

Use one row per chainage zone. Recommended columns:

- `zone_id`
- `chainage_from_m`, `chainage_to_m`
- `ground_type`
- `cover_m`
- `mixed_face_flag`
- `boulder_risk`
- `water_head_bar`
- `settlement_sensitivity_class`
- `notes`

## monitoring.csv

Use one row per ring or one row per time slice. The scripts accept a flexible set of production and monitoring columns. Recommended fields include:

- `date`, `ring`, `zone_id`
- `advance_m`, `cycle_minutes`
- `target_cycle_min`, `target_rings`
- `chamber_pressure_bar`, `torque_kNm`, `thrust_kN`, `screw_rate_rpm`
- `settlement_mm`, `volume_loss_percent`
- `downtime_reason`, `downtime_minutes`

## missing data rule

Do not invent missing geotechnical data. If a field is missing, let the script report the gap and carry the limitation into the markdown report and artifact map.
