# repo integration scaffold

## future geotechCLI deterministic tools

- `evaluate_epb_conditioning_window`
- `predict_epb_clogging_risk`

## recommended core file

- `packages/core/src/geo/tunnel/epb-conditioning.ts`

## tool registry hook

Add schemas for:

- fines, LL, PI, permeability, USCS
- cover and water head by zone
- cutterhead opening ratio and screw capacity
- boulder and mixed-face flags

## guardrails

Add checks for:

- invalid fines or plasticity data
- negative permeability
- unrealistically high FIR or FER values
- conflicting outputs such as `polymer_dominant` in clean gravel without clay fines

## swarm and cli follow-on

- add to the interpretation and simulation workflow boundary when the user requests conditioning design
- add a CLI surface such as `geotech tunnel conditioning-plan`
- persist `assumptions`, `results`, and `issues-and-corrections` candidates
