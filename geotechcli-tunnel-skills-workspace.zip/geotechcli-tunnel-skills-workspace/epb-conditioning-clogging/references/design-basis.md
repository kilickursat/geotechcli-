# design basis

This skill bundle is intentionally universal rather than country-specific.

## primary reference stack

- ITA-AITES / WG14 style mechanized tunnelling guidance for machine class logic, EPB operating principles, and mixed-face risk framing.
- EFNARC mechanised tunnelling guidance for soil conditioning, foam and polymer families, annulus grout awareness, and soft-ground consumable practice.
- Observational method principles for monitoring, trigger values, pre-defined actions, and update loops between prediction and measured performance.
- BTS-aligned best-practice language only as a secondary review lens for constructability, recording, and operational discipline. Do not frame the output as UK-only compliance.

## model philosophy

Treat the scripts as production-oriented screening and control tools, not as contract design replacements.

- prefer explicit ranges to false precision
- report missing data instead of masking it
- keep all limits and warnings visible in the final narrative
- separate machine capability limits from geotechnical limits
- keep operational recommendations tied to measurable control variables

## citation practice inside the skill

When writing the final markdown, refer to the reference families above in prose. Do not claim formal compliance with a project code unless the user explicitly supplies that project code.
