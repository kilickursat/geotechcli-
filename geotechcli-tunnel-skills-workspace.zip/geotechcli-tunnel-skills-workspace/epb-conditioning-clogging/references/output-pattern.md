# output pattern

After running the analysis script, always produce the bundle below in this order.

## 1. swarm handoff json

Wrap the key script result into a fenced `json` block with these top-level keys:

- `skill`
- `analysis_type`
- `project_summary`
- `zone_results` or `production_summary`
- `critical_risks`
- `missing_inputs`
- `recommended_next_tools`

## 2. engineering markdown

Use short sections and direct engineering language.

- `# [skill title] report`
- `## basis and assumptions`
- `## key findings`
- `## design or operational actions`
- `## limitations`

## 3. project and case-file artifact map

List what should be persisted into geotechCLI memory.

- named dataset keys
- derived parameters
- assumption records
- candidate case-file artifact types

If the script reports a blocked condition or no safe window, say so explicitly and do not convert it into a positive recommendation.
