
#!/usr/bin/env python3
import argparse
import csv
import json
import math
from pathlib import Path


def read_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_csv(path):
    with open(path, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def as_float(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == '':
        return default
    try:
        return float(text)
    except ValueError:
        return default


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'y', 'high', 'mixed'}


def normalize_text(value, default=''):
    return str(value or default).strip()


def load_ground_model(path):
    data = read_json(path)
    strata = data.get('strata', [])
    if not strata and 'layers' in data:
        strata = data['layers']
    groundwater = data.get('groundwater', {})
    tunnel = data.get('tunnel', {})
    return data, strata, groundwater, tunnel


def load_machine(path):
    data = read_json(path)
    return data.get('machine', data)


def select_stratum(strata, depth):
    for stratum in strata:
        start = as_float(stratum.get('from_m', stratum.get('depth_from_m')), 0.0)
        end = as_float(stratum.get('to_m', stratum.get('depth_to_m')), None)
        if end is None:
            continue
        if start <= depth <= end:
            return stratum
    return strata[-1] if strata else {}


def water_pressure_bar(zone, groundwater, axis_depth):
    explicit = as_float(zone.get('water_head_bar'))
    if explicit is not None:
        return explicit
    wt = as_float(groundwater.get('water_table_depth_m'))
    if wt is None:
        return 0.0
    head = max(axis_depth - wt, 0.0)
    return head * 9.81 / 100.0


def uscs_family(uscs):
    u = normalize_text(uscs).upper()
    if u.startswith('C'):
        return 'clay'
    if u.startswith('M'):
        return 'silt'
    if u.startswith('S'):
        return 'sand'
    if u.startswith('G'):
        return 'gravel'
    return 'mixed'


def sensitivity_thresholds(label):
    key = normalize_text(label).lower()
    if key == 'high':
        return (10.0, 15.0)
    if key == 'medium':
        return (15.0, 25.0)
    return (20.0, 35.0)


def safe_write(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)


def conditioning_plan(zone, strata, groundwater, machine):
    diameter = as_float(machine.get('diameter_m'), 0.0)
    cover = as_float(zone.get('cover_m'), 0.0)
    axis_depth = cover + diameter / 2.0
    stratum = select_stratum(strata, axis_depth)
    fines = as_float(stratum.get('fines_pct'), 0.0)
    ll = as_float(stratum.get('liquid_limit_pct'), 0.0)
    pi = as_float(stratum.get('plasticity_index_pct'), 0.0)
    perm = as_float(stratum.get('permeability_m_s'), 0.0)
    family = uscs_family(stratum.get('uscs'))
    mixed = as_bool(zone.get('mixed_face_flag'))
    water_bar = water_pressure_bar(zone, groundwater, axis_depth)

    score = 20.0
    if family == 'clay':
        score += 20
    if 20 <= fines <= 70:
        score += 18
    if pi >= 20:
        score += 22
    elif pi >= 10:
        score += 12
    if ll >= 40:
        score += 8
    if perm and perm < 1e-7:
        score += 10
    if mixed:
        score += 8
    if family in {'sand', 'gravel'} and fines < 10:
        score -= 15
    score = max(0.0, min(score, 100.0))

    if family in {'sand', 'gravel'} and fines < 15:
        family_name = 'foam_dominant'
        fir = '30-60 %'
        fer = '10-20'
        lor = '5-15 l/m3'
    elif family == 'sand' or (fines < 35 and pi < 10):
        family_name = 'foam_plus_water_retention'
        fir = '20-45 %'
        fer = '8-15'
        lor = '4-10 l/m3'
    elif family == 'clay' and pi >= 15:
        family_name = 'polymer_anti_clay_dominant'
        fir = '5-15 %'
        fer = '3-8'
        lor = '1-4 l/m3'
    else:
        family_name = 'foam_plus_polymer_hybrid'
        fir = '10-25 %'
        fer = '5-10'
        lor = '2-6 l/m3'

    controls = []
    if family_name == 'polymer_anti_clay_dominant':
        controls.append('plan regular cutterhead and screw conveyor cleaning intervals')
        controls.append('watch sticky clay build-up and torque drift')
    if family_name.startswith('foam'):
        controls.append('verify foam quality and maintain paste continuity at the screw conveyor')
    if perm and perm > 1e-5:
        controls.append('consider bentonite or slurry-assist support where permeability is high')
    if water_bar > 3.0:
        controls.append('link conditioner demand to chamber pressure stability and water ingress response')
    if mixed:
        controls.append('tighten sampling frequency through the mixed-face transition')

    risk_class = 'LOW'
    if score >= 70:
        risk_class = 'HIGH'
    elif score >= 45:
        risk_class = 'MODERATE'

    return {
        'zone_id': normalize_text(zone.get('zone_id')),
        'material': normalize_text(stratum.get('material')),
        'uscs': normalize_text(stratum.get('uscs')),
        'fines_pct': fines,
        'liquid_limit_pct': ll,
        'plasticity_index_pct': pi,
        'permeability_m_s': perm,
        'clogging_score': round(score, 1),
        'clogging_risk_class': risk_class,
        'conditioning_family': family_name,
        'recommended_fir': fir,
        'recommended_fer': fer,
        'recommended_lor': lor,
        'controls': controls,
    }


def build_markdown(result):
    lines = [
        '# EPB conditioning and clogging report',
        '',
        '## basis and assumptions',
        '- conditioning families are screened from fines, plasticity, permeability, groundwater, and mixed-face cues.',
        '- dosage windows are starting bands for field adjustment, not laboratory acceptance values.',
        '',
        '## key findings',
    ]
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: {zone['conditioning_family']} with clogging score {zone['clogging_score']}/100 and risk class {zone['clogging_risk_class']}.")
    lines += ['', '## design or operational actions']
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: FIR {zone['recommended_fir']}, FER {zone['recommended_fer']}, LOR {zone['recommended_lor']}; " + '; '.join(zone['controls']))
    lines += ['', '## limitations']
    for item in result['limitations']:
        lines.append(f'- {item}')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='evaluate EPB conditioning demand and clogging risk')
    parser.add_argument('--ground-model', default='assets/examples/ground_model.json')
    parser.add_argument('--machine-config', default='assets/examples/machine_config.json')
    parser.add_argument('--alignment-zones', default='assets/examples/alignment_zones.csv')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--output-json')
    parser.add_argument('--output-markdown')
    args = parser.parse_args()

    _, strata, groundwater, _ = load_ground_model(args.ground_model)
    machine = load_machine(args.machine_config)
    zones = read_csv(args.alignment_zones)
    zone_results = [conditioning_plan(zone, strata, groundwater, machine) for zone in zones]
    result = {
        'skill': 'epb-conditioning-clogging',
        'analysis_type': 'conditioning_and_clogging',
        'zone_results': zone_results,
        'critical_risks': sorted({zone['clogging_risk_class'] for zone in zone_results if zone['clogging_risk_class'] == 'HIGH'}),
        'missing_inputs': [],
        'recommended_next_tools': ['epb-production-and-ring-cycle', 'mixed-face-transition-planning'],
        'limitations': [
            'conditioning windows are operating start bands and should be verified against site-specific trials and spoil response.',
            'clogging score is a heuristic index and not a mineralogical laboratory classification.',
        ],
    }
    markdown = build_markdown(result)
    if args.output_json:
        safe_write(args.output_json, json.dumps(result, indent=2) + '\n')
    if args.output_markdown:
        safe_write(args.output_markdown, markdown)
    if args.json or (not args.output_json and not args.output_markdown):
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
