# implementation todo

1. keep the standalone skills self-contained and individually packageable
2. use the shared local-file contract across all six skills
3. keep the design basis universal: ITA-AITES, EFNARC, BTS-aligned review language, and observational method
4. keep scripts production-oriented but honest about screening-level limits
5. map every skill to future geotechCLI tool, guardrail, swarm, and CLI integration points
6. package and validate each skill individually
