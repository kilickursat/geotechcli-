#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
VALIDATOR="/home/oai/skills/skill-creator/scripts/quick_validate.py"
for skill_dir in "$ROOT_DIR"/*/ ; do
  [ -d "$skill_dir" ] || continue
  skill_name="$(basename "$skill_dir")"
  case "$skill_name" in
    dist) continue ;;
  esac
  python3 "$VALIDATOR" "$skill_dir"
done
