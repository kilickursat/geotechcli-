#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKAGER="/home/oai/skills/skill-creator/scripts/package_skill.py"
mkdir -p "$ROOT_DIR/dist"
for skill_dir in "$ROOT_DIR"/*/ ; do
  [ -d "$skill_dir" ] || continue
  skill_name="$(basename "$skill_dir")"
  case "$skill_name" in
    dist) continue ;;
  esac
  mkdir -p "$ROOT_DIR/dist/$skill_name"
  python3 "$PACKAGER" "$skill_dir" "$ROOT_DIR/dist/$skill_name"
done
