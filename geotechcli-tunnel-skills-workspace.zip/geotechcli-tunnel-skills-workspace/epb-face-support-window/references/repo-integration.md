# repo integration scaffold

## future geotechCLI deterministic tools

- `calculate_epb_face_pressure_window`
- optional helper: `estimate_zone_k0`

## recommended core file

- `packages/core/src/geo/tunnel/epb-face-support.ts`

## tool registry hook

Add a tool schema that accepts:

- tunnel diameter
- cover and groundwater head by zone
- unit weight, permeability, fines, PI, cu or phi
- machine chamber minimum and maximum pressure

## guardrails

Add checks for:

- upper pressure lower than lower pressure
- chamber limits below the calculated lower bound
- crown depth less than zero
- water head inconsistent with water table depth
- support pressure outside machine capability

## swarm and cli follow-on

- add to the simulation allowlist
- add a CLI surface such as `geotech tunnel face-pressure-window`
- persist `results`, `review-checklist`, and `acceptance-status` candidates
