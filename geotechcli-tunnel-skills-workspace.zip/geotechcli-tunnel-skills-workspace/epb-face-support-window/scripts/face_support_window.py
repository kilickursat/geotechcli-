
#!/usr/bin/env python3
import argparse
import csv
import json
import math
from pathlib import Path


def read_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_csv(path):
    with open(path, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def as_float(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == '':
        return default
    try:
        return float(text)
    except ValueError:
        return default


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'y', 'high', 'mixed'}


def normalize_text(value, default=''):
    return str(value or default).strip()


def load_ground_model(path):
    data = read_json(path)
    strata = data.get('strata', [])
    if not strata and 'layers' in data:
        strata = data['layers']
    groundwater = data.get('groundwater', {})
    tunnel = data.get('tunnel', {})
    return data, strata, groundwater, tunnel


def load_machine(path):
    data = read_json(path)
    return data.get('machine', data)


def select_stratum(strata, depth):
    for stratum in strata:
        start = as_float(stratum.get('from_m', stratum.get('depth_from_m')), 0.0)
        end = as_float(stratum.get('to_m', stratum.get('depth_to_m')), None)
        if end is None:
            continue
        if start <= depth <= end:
            return stratum
    return strata[-1] if strata else {}


def water_pressure_bar(zone, groundwater, axis_depth):
    explicit = as_float(zone.get('water_head_bar'))
    if explicit is not None:
        return explicit
    wt = as_float(groundwater.get('water_table_depth_m'))
    if wt is None:
        return 0.0
    head = max(axis_depth - wt, 0.0)
    return head * 9.81 / 100.0


def uscs_family(uscs):
    u = normalize_text(uscs).upper()
    if u.startswith('C'):
        return 'clay'
    if u.startswith('M'):
        return 'silt'
    if u.startswith('S'):
        return 'sand'
    if u.startswith('G'):
        return 'gravel'
    return 'mixed'


def sensitivity_thresholds(label):
    key = normalize_text(label).lower()
    if key == 'high':
        return (10.0, 15.0)
    if key == 'medium':
        return (15.0, 25.0)
    return (20.0, 35.0)


def safe_write(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)


def estimate_k0(stratum):
    phi = as_float(stratum.get('phi_deg'))
    family = uscs_family(stratum.get('uscs'))
    if phi is not None:
        return max(0.35, min(1.0, 1.0 - math.sin(math.radians(phi))))
    if family == 'clay':
        return 0.8
    if family == 'silt':
        return 0.65
    if family == 'sand':
        return 0.5
    return 0.6


def pressure_window(zone, strata, groundwater, machine):
    diameter = as_float(machine.get('diameter_m'), 0.0)
    cover = as_float(zone.get('cover_m'), 0.0)
    axis_depth = cover + diameter / 2.0
    crown_depth = cover
    stratum = select_stratum(strata, axis_depth)
    gamma = as_float(stratum.get('unit_weight_kN_m3'), 19.0)
    perm = as_float(stratum.get('permeability_m_s'), 0.0)
    fines = as_float(stratum.get('fines_pct'), 0.0)
    pi = as_float(stratum.get('plasticity_index_pct'), 0.0)
    water_bar = water_pressure_bar(zone, groundwater, axis_depth)
    u_axis = water_bar * 100.0
    sigma_v_total_axis = gamma * axis_depth
    sigma_v_total_crown = gamma * max(crown_depth, 0.0)
    sigma_v_eff_axis = max(sigma_v_total_axis - u_axis, 0.0)
    k0 = estimate_k0(stratum)
    mixed = as_bool(zone.get('mixed_face_flag'))
    sens = normalize_text(zone.get('settlement_sensitivity_class')).lower()
    chamber_min = as_float(machine.get('chamber_pressure_min_bar'))
    chamber_max = as_float(machine.get('chamber_pressure_max_bar'))

    stability_margin = 0.15
    if perm and perm > 1e-5:
        stability_margin += 0.10
    if fines < 15:
        stability_margin += 0.12
    if mixed:
        stability_margin += 0.15
    if pi >= 15:
        stability_margin += 0.05

    blowout_margin = 0.15
    if sens == 'high':
        blowout_margin += 0.10
    if diameter and cover / diameter < 1.0:
        blowout_margin += 0.10

    lower = (k0 * sigma_v_eff_axis + u_axis) / 100.0 + stability_margin
    upper = sigma_v_total_crown / 100.0 - blowout_margin
    if chamber_max is not None:
        upper = min(upper, chamber_max)
    if chamber_min is not None:
        lower = max(lower, chamber_min)
    no_safe = upper <= lower
    target = lower if no_safe else (lower + upper) / 2.0
    warnings = []
    if no_safe:
        warnings.append('no safe screening window inside current assumptions and machine limits')
    if chamber_max is not None and chamber_max < lower:
        warnings.append('machine chamber maximum is below screening lower bound')
    if chamber_min is not None and chamber_min > upper and not no_safe:
        warnings.append('machine chamber minimum is above screening upper bound')
    return {
        'zone_id': normalize_text(zone.get('zone_id')),
        'cover_m': cover,
        'axis_depth_m': round(axis_depth, 2),
        'crown_depth_m': round(crown_depth, 2),
        'estimated_k0': round(k0, 3),
        'water_head_bar': round(water_bar, 2),
        'lower_support_bar': round(lower, 2),
        'target_support_bar': round(target, 2),
        'upper_support_bar': round(upper, 2),
        'no_safe_window': no_safe,
        'warnings': warnings,
    }


def build_markdown(result):
    lines = [
        '# EPB face support window report',
        '',
        '## basis and assumptions',
        '- lower bound is screened from estimated at-rest confinement plus groundwater plus a stability margin.',
        '- upper bound is screened against crown blowout sensitivity and machine pressure caps.',
        '',
        '## key findings',
    ]
    for zone in result['zone_results']:
        lines.append(f"- {zone['zone_id']}: lower {zone['lower_support_bar']} bar, target {zone['target_support_bar']} bar, upper {zone['upper_support_bar']} bar.")
    lines += ['', '## design or operational actions']
    for zone in result['zone_results']:
        if zone['no_safe_window']:
            lines.append(f"- {zone['zone_id']}: stop and re-open the assumptions, because no safe screening window was found.")
        else:
            lines.append(f"- {zone['zone_id']}: keep live chamber pressure inside the screening band and tighten response if settlement sensitivity is high.")
    lines += ['', '## limitations']
    for item in result['limitations']:
        lines.append(f'- {item}')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description='calculate screening EPB face support window by zone')
    parser.add_argument('--ground-model', default='assets/examples/ground_model.json')
    parser.add_argument('--machine-config', default='assets/examples/machine_config.json')
    parser.add_argument('--alignment-zones', default='assets/examples/alignment_zones.csv')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--output-json')
    parser.add_argument('--output-markdown')
    args = parser.parse_args()

    _, strata, groundwater, _ = load_ground_model(args.ground_model)
    machine = load_machine(args.machine_config)
    zones = read_csv(args.alignment_zones)
    zone_results = [pressure_window(zone, strata, groundwater, machine) for zone in zones]
    result = {
        'skill': 'epb-face-support-window',
        'analysis_type': 'pressure_window',
        'zone_results': zone_results,
        'critical_risks': sorted({w for zone in zone_results for w in zone['warnings']}),
        'missing_inputs': [],
        'recommended_next_tools': ['epb-conditioning-clogging', 'soft-ground-settlement-observational-control'],
        'limitations': [
            'screening window only; confirm against project-specific face-support design and operating response.',
            'k0 and blowout margins are estimated from available parameters and not from a full constitutive model.',
        ],
    }
    markdown = build_markdown(result)
    if args.output_json:
        safe_write(args.output_json, json.dumps(result, indent=2) + '\n')
    if args.output_markdown:
        safe_write(args.output_markdown, markdown)
    if args.json or (not args.output_json and not args.output_markdown):
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
