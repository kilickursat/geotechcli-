---
name: epb-face-support-window
description: calculate a screening-level epb face support pressure window in soft-ground tunnel zones using ground_model.json, machine_config.json, and alignment_zones.csv. use when chatgpt needs lower and upper pressure bounds, target chamber pressure bands, blowout and instability warnings, or a handoff for operational control planning before shift execution.
---

# EPB Face Support Window

## Overview

Estimate a screening pressure window that respects both face stability and blowout risk before the crew tunes live chamber pressure targets.

## Workflow

1. check that `ground_model.json`, `machine_config.json`, and `alignment_zones.csv` exist.
2. run `python scripts/face_support_window.py --ground-model ground_model.json --machine-config machine_config.json --alignment-zones alignment_zones.csv --json`.
3. if the script returns `no_safe_window=true` for a zone, stop and say so directly. do not soften it into a recommendation.
4. convert the result into a swarm handoff json block, a markdown pressure-control note, and an artifact map.
5. consult `references/repo-integration.md` for the future geotechCLI core/tool/guardrail hook points.

## Decision rules

- Use the default local-file contract from `references/input-contract.md` unless the user explicitly supplies different filenames.
- Run the deterministic script first. Do not write the markdown report before the script result exists.
- Preserve script warnings, missing inputs, and blocked conditions in the final narrative.
- Use `references/design-basis.md` to keep the report universal and tied to ITA-AITES, EFNARC, BTS-aligned review language, and observational-method thinking.
- Use `references/repo-integration.md` only when the user asks how to promote the standalone tool into geotechCLI core, guardrails, swarm, or CLI code.

## Script entrypoint

Run:

```bash
python scripts/face_support_window.py --help
```

Default analysis call:

```bash
python scripts/face_support_window.py --json
```

If the user wants a saved file, write JSON with `--output-json <path>` and markdown with `--output-markdown <path>`.

## Output bundle

After the script runs, follow `references/output-pattern.md` and return:

1. a swarm handoff json block
2. an engineering markdown report
3. a project and case-file artifact map

## Resources

- `references/input-contract.md` — shared file contract and accepted fields
- `references/output-pattern.md` — required three-part response bundle
- `references/design-basis.md` — universal reference stack and model philosophy
- `references/repo-integration.md` — future geotechCLI core/tool/guardrail/swarm/cli mapping
- `assets/examples/` — small local examples for testing the script before packaging
