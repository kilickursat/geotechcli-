# Excavation Support Staged Review

## Summary
Review excavation staging, support level timing, exposure windows, and sequence-dependent geotechnical risk.

## Key metrics
- sequence status: pass
- support level count: 3

## Engineering workflow
- Review stage-by-stage excavation exposure between support installations.
- Sequence status: pass.

## Warnings
- no blocking warnings in the standalone screening run.

## Structured details
### stages
- {'stage': 1, 'from_m': 0.0, 'to_m': 2.5, 'unsupported_exposure_m': 2.5, 'status': 'pass'}
- {'stage': 2, 'from_m': 2.5, 'to_m': 6.0, 'unsupported_exposure_m': 3.5, 'status': 'pass'}
- {'stage': 3, 'from_m': 6.0, 'to_m': 9.0, 'unsupported_exposure_m': 3.0, 'status': 'pass'}
- {'stage': 4, 'from_m': 9.0, 'to_m': 12.0, 'unsupported_exposure_m': 3.0, 'status': 'pass'}
