---
name: shallow-foundation-option-screening
description: screen pad, strip, and raft concepts against bearing, settlement, groundwater, and constructability constraints. use when the task is in geotechnical engineering and needs a repeatable foundations workflow. use when the task is to compare shallow foundation concepts, decide whether shallow foundations remain feasible, or prepare a first-pass foundation option note from ground_model.json and foundation_scheme.json. this skill is for standalone packaged execution with local files and should produce swarm handoff json, engineering markdown, and case-file artifact mapping.
---

# Shallow Foundation Option Screening

## Overview

Use this skill to make the agent more reliable in foundations work. The skill wraps a deterministic standalone tool, a strict local-file contract, and a repeatable engineering output pattern.

## Workflow

1. Confirm that the required local files exist. Read the shared contract in `references/input-contract.md`.
2. Identify the governing founding, excavation, groundwater, and serviceability conditions from the input files.
3. Run the standalone tool script.
4. Review `swarm_handoff.json`, `engineering_report.md`, and `case_file_artifact_map.json`.
5. If the result is marginal or warning-heavy, route the output to a reviewer or follow-on skill instead of treating it as final design.

## What this skill is trying to answer

- screen pad, strip, and raft concepts using bearing reserve, settlement risk, groundwater interference, and basement depth interaction.
- treat the output as a production-oriented screening note, not a final design certificate.
- flag when shallow options should be replaced by piled or piled-raft alternatives.

## Tooling

Run the deterministic script like this:

```bash
python scripts/shallow_foundation_option_screening.py --input-dir <path/to/input-dir> --output-dir <path/to/output-dir>
```

The default bundled input directory is `assets/example-inputs/` and the default output directory is `outputs/`.

## Inputs

- Use `ground_model.json` as the geotechnical baseline.
- Use `foundation_scheme.json` for foundation-driven tasks.
- Use `excavation_support_config.json` for retaining and excavation tasks.
- Use `monitoring.csv` when trigger logic, observational control, or sequence review matters.

Read the exact contract in `references/input-contract.md`.

## Output contract

Always keep the three-output pattern.

- `swarm_handoff.json` for machine-readable orchestration
- `engineering_report.md` for the engineering note
- `case_file_artifact_map.json` for deterministic storage mapping

Read the details in `references/output-contract.md`.

## Design basis

Keep the skill universal and production-oriented. Use the overview in `references/design-basis.md` and explicitly state when project-specific code checks or specialist numerical models are still required.

## Repo integration

If this standalone skill is later promoted into geotechCLI itself, use `references/repo-integration.md` to convert the logic into `packages/core/src/geo/`, register tools, add guardrails, expose swarm access, and add tests.
