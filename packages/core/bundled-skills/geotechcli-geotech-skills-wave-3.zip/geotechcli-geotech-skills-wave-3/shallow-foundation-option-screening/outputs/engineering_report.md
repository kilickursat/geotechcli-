# Shallow Foundation Option Screening

## Summary
Screen pad, strip, and raft concepts against bearing, settlement, groundwater, and constructability constraints.

## Key metrics
- width m: 3.2
- depth m: 2.6
- phi deg: 22.0
- cohesion for screen kpa: 8.0
- q ultimate kpa: 674.6
- q allowable kpa: 224.9
- applied service pressure kpa: 180.0
- bearing reserve ratio: 1.25
- immediate settlement mm: 61.3
- consolidation settlement mm: 486.5
- predicted total settlement mm: 547.8
- allowable total settlement mm: 45.0
- settlement utilization ratio: 12.17
- preferred system: piled_or_piled_raft

## Engineering workflow
- Screen founding stratum at 2.6 m depth.
- Compare bearing reserve against service pressure and serviceability movement limit.
- Preferred concept after screening: piled or piled raft.

## Warnings
- predicted settlement exceeds the project serviceability limit.
- groundwater is close to founding level and may complicate excavation and blinding operations.
