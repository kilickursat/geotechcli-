# Retaining Wall Preliminary Design

## Summary
Screen retaining wall concepts, embedment, pressure regime, and groundwater interaction for preliminary design decisions.

## Key metrics
- selected envelope: at-rest/intermediate
- ka: 0.455
- k0: 0.625
- kp: 2.198
- design k: 0.54
- effective soil force kN per m: 385.5
- surcharge force kN per m: 129.6
- water force kN per m: 510.3
- total lateral force kN per m: 1025.5
- embedment ratio: 0.67
- recommended wall system: propped_secant_or_diaphragm_wall

## Engineering workflow
- Estimate design lateral force and combine it with wall restraint assumptions.
- Recommend propped secant or diaphragm wall at screening level.

## Warnings
- no blocking warnings in the standalone screening run.
