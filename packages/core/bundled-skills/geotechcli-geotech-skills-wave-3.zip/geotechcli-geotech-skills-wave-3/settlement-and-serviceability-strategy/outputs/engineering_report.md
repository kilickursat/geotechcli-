# Settlement And Serviceability Strategy

## Summary
Build a settlement-control strategy around total settlement, differential settlement, compressibility, and monitoring sensitivity.

## Key metrics
- immediate settlement mm: 61.3
- consolidation settlement mm: 486.5
- predicted total settlement mm: 547.8
- allowable total settlement mm: 45.0
- settlement utilization ratio: 12.17
- serviceability strategy: switch concept or improve ground before proceeding

## Engineering workflow
- Estimate immediate and consolidation-driven settlement demand.
- Compare movement demand to the project serviceability limit.
- Serviceability strategy: switch concept or improve ground before proceeding.

## Warnings
- compressible founding stratum suggests consolidation-sensitive performance.
- movement demand is close to the allowable settlement limit.
