# Raft And Piled Raft Screening

## Summary
Compare raft and piled-raft concepts using settlement reduction, load share, groundwater, and construction complexity.

## Key metrics
- raft predicted total settlement mm: 547.8
- piled raft predicted total settlement mm: 210.1
- assumed load share to piles percent: 61.6
- preferred system: pile_group
- group efficiency: 0.89

## Engineering workflow
- Compare raft settlement against a piled-raft settlement reduction assumption.
- Use group spacing to infer plausible pile load sharing.
- Preferred concept after screening: pile group.

## Warnings
- downdrag may erode the assumed piled-raft benefit and needs project-specific verification.
