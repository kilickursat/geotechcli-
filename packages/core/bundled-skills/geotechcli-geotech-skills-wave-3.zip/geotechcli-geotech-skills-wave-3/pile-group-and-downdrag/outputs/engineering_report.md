# Pile Group And Downdrag

## Summary
Screen pile-group efficiency, negative skin friction, and dragload consequences for production-level foundation planning.

## Key metrics
- spacing over diameter: 3.33
- group efficiency: 0.89
- dragload per pile kN: 135.7
- total dragload kN: 2171.5
- effective group resistance kN: 3972.3
- downdrag ratio: 0.55
- pile length m: 24.0
- pile count: 16

## Engineering workflow
- Screen pile-group efficiency and downdrag.

## Warnings
- no blocking warnings in the standalone screening run.
