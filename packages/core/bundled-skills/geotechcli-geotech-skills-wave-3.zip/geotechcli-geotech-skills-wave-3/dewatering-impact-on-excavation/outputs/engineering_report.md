# Dewatering Impact On Excavation

## Summary
Screen how dewatering strategy affects inflow, adjacent settlement risk, base stability, and construction sequencing.

## Key metrics
- drawdown target m: 5.0
- observed drawdown m: 3.8
- permeability m s: 6e-09
- inflow index m3 per day per m: 0.03
- drawdown risk class: high

## Engineering workflow
- Estimate inflow intensity and off-site drawdown sensitivity.
- Drawdown risk class: high.

## Warnings
- drawdown control should be tied to off-site settlement and recharge review.
