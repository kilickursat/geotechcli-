# geotechCLI geotechnical skills - wave 3

This workspace contains the Wave 3 standalone skill bundle for geotechCLI.

Packs included:
- foundations and serviceability
- retaining and excavation support

Each skill folder is ready to package individually and already includes:
- SKILL.md
- agents/openai.yaml
- deterministic python tool script
- bundled example inputs
- shared reference files
- tri-output contract

Dist packages are written under `dist/<skill-name>/skill.zip`.
