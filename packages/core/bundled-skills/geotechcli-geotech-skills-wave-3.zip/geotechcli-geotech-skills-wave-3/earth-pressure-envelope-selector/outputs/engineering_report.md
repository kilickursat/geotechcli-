# Earth Pressure Envelope Selector

## Summary
Select the governing earth-pressure envelope and movement assumption for retaining and excavation support systems.

## Key metrics
- selected envelope: at-rest/intermediate
- ka: 0.455
- k0: 0.625
- kp: 2.198
- design k: 0.54
- effective soil force kN per m: 385.5
- surcharge force kN per m: 129.6
- water force kN per m: 510.3
- total lateral force kN per m: 1025.5

## Engineering workflow
- Select an earth-pressure envelope consistent with wall movement and support stiffness.
- Selected envelope: at-rest/intermediate.

## Warnings
- at-rest or intermediate pressure may govern because the support system is stiff and movement is limited.
