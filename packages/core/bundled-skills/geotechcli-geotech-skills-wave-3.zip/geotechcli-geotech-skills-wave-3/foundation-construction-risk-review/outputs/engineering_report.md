# Foundation Construction Risk Review

## Summary
Review foundation construction hazards, sequencing constraints, groundwater exposure, and delivery risks before committing to the concept.

## Key metrics
- highest risk rating: high
- risk count: 3

## Engineering workflow
- Review groundwater, excavation interface, sequencing, and pile logistics risks.
- Highest construction risk rating: high.

## Warnings
- groundwater management: water table is close to the basement excavation level.
- deep excavation interface: foundation construction depends on a deep temporary works sequence.

## Structured details
### risk register
- {'rating': 'high', 'topic': 'groundwater management', 'detail': 'water table is close to the basement excavation level.'}
- {'rating': 'medium', 'topic': 'pile logistics', 'detail': 'long piles may constrain sequence and spoil handling.'}
- {'rating': 'high', 'topic': 'deep excavation interface', 'detail': 'foundation construction depends on a deep temporary works sequence.'}
