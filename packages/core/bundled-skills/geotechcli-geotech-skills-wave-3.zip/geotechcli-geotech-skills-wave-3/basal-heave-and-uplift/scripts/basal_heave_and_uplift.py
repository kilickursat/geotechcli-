#!/usr/bin/env python3
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path

PROFILE_PATH = Path(__file__).resolve().parent.parent / 'references' / 'skill-profile.json'
PROFILE = json.loads(PROFILE_PATH.read_text())


def load_json(path: Path):
    return json.loads(path.read_text())


def load_csv(path: Path):
    rows = []
    if not path.exists():
        return rows
    with path.open('r', encoding='utf-8', newline='') as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            clean = {}
            for key, value in row.items():
                value = '' if value is None else value.strip()
                try:
                    if value == '':
                        clean[key] = value
                    else:
                        clean[key] = float(value)
                except ValueError:
                    clean[key] = value
            rows.append(clean)
    return rows


def tan_deg(value: float) -> float:
    return math.tan(math.radians(value))


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def select_stratum(strata, depth: float):
    for stratum in strata:
        if stratum['from_m'] <= depth <= stratum['to_m']:
            return stratum
    if strata:
        return strata[-1]
    raise ValueError('no strata available')


def terzaghi_factors(phi_deg: float):
    phi = math.radians(max(phi_deg, 0.01))
    nq = math.exp(math.pi * math.tan(phi)) * math.tan(math.pi / 4 + phi / 2) ** 2
    nc = (nq - 1) / math.tan(phi)
    ngamma = 2 * (nq + 1) * math.tan(phi)
    return nc, nq, ngamma


def foundation_bearing_capacity(stratum, foundation_scheme):
    b = float(foundation_scheme.get('equivalent_footing_width_m', 2.5))
    d = float(foundation_scheme.get('planned_foundation_depth_m', 1.5))
    gamma = float(stratum.get('unit_weight_kn_m3', 18.0))
    c = float(stratum.get('su_kpa', 0.0)) * 0.25
    phi = float(stratum.get('phi_deg', 30.0))
    nc, nq, ng = terzaghi_factors(phi)
    q = gamma * d
    qult = c * nc + q * nq + 0.5 * gamma * b * ng
    qall = qult / 3.0
    applied = float(foundation_scheme.get('service_load_kpa', 150.0))
    reserve = qall / max(applied, 1.0)
    return {
        'width_m': round(b, 3),
        'depth_m': round(d, 3),
        'phi_deg': round(phi, 2),
        'cohesion_for_screen_kpa': round(c, 2),
        'q_ultimate_kpa': round(qult, 1),
        'q_allowable_kpa': round(qall, 1),
        'applied_service_pressure_kpa': round(applied, 1),
        'bearing_reserve_ratio': round(reserve, 2),
    }


def settlement_screen(stratum, foundation_scheme):
    q = float(foundation_scheme.get('service_load_kpa', 150.0))
    b = float(foundation_scheme.get('equivalent_footing_width_m', 2.5))
    es_mpa = max(float(stratum.get('Es_mpa', 10.0)), 1.0)
    embedment = float(foundation_scheme.get('planned_foundation_depth_m', 1.5))
    influence = 0.8 + 0.04 * clamp(embedment, 0.0, 6.0)
    immediate_mm = q * b / (es_mpa * 1000.0) * influence * 1000.0
    cc = float(stratum.get('Cc', 0.08))
    e0 = max(float(stratum.get('e0', 0.7)), 0.2)
    thickness = max(float(stratum.get('to_m', 0.0)) - float(stratum.get('from_m', 0.0)), 0.5)
    consolidation_mm = cc / (1.0 + e0) * thickness * math.log10((80.0 + q) / 80.0) * 1000.0
    total = immediate_mm + consolidation_mm
    allowable = float(foundation_scheme.get('allowable_total_settlement_mm', 50.0))
    return {
        'immediate_settlement_mm': round(immediate_mm, 1),
        'consolidation_settlement_mm': round(consolidation_mm, 1),
        'predicted_total_settlement_mm': round(total, 1),
        'allowable_total_settlement_mm': round(allowable, 1),
        'settlement_utilization_ratio': round(total / max(allowable, 1.0), 2),
    }


def pile_group_screen(ground_model, foundation_scheme):
    spacing = float(foundation_scheme.get('pile_spacing_m', 3.0))
    diameter = float(foundation_scheme.get('pile_diameter_m', 0.9))
    length = float(foundation_scheme.get('pile_length_m', 20.0))
    rows = int(foundation_scheme.get('group_size', {}).get('rows', 3))
    cols = int(foundation_scheme.get('group_size', {}).get('cols', 3))
    sd = spacing / max(diameter, 0.1)
    efficiency = clamp(0.62 + 0.08 * min(sd, 5.0), 0.65, 0.98)
    soft_zone = float(foundation_scheme.get('negative_skin_friction_zone_m', 4.0))
    upper = select_stratum(ground_model['strata'], soft_zone / 2.0)
    unit_negative = max(float(upper.get('su_kpa', 20.0)) * 0.22, 8.0)
    drag_per_pile = math.pi * diameter * soft_zone * unit_negative
    drag_group = drag_per_pile * rows * cols
    column_load = float(foundation_scheme.get('column_load_kN', 2500.0))
    group_capacity = efficiency * rows * cols * max(column_load / max(rows * cols, 1) * 1.6, 1.0)
    return {
        'spacing_over_diameter': round(sd, 2),
        'group_efficiency': round(efficiency, 2),
        'dragload_per_pile_kN': round(drag_per_pile, 1),
        'total_dragload_kN': round(drag_group, 1),
        'effective_group_resistance_kN': round(group_capacity, 1),
        'downdrag_ratio': round(drag_group / max(group_capacity, 1.0), 2),
        'pile_length_m': round(length, 1),
        'pile_count': rows * cols,
    }


def retaining_envelope(ground_model, excavation_config):
    depth = float(excavation_config.get('excavation_depth_m', 8.0))
    surcharge = float(excavation_config.get('surcharge_kPa', 0.0))
    gw = float(excavation_config.get('water_table_depth_m', 99.0))
    stratum = select_stratum(ground_model['strata'], depth / 2.0)
    phi = float(stratum.get('phi_deg', 30.0))
    gamma = float(stratum.get('unit_weight_kn_m3', 18.0))
    movement_class = str(excavation_config.get('movement_class', 'free')).lower()
    ka = math.tan(math.radians(45 - phi / 2.0)) ** 2
    k0 = 1.0 - math.sin(math.radians(phi))
    kp = math.tan(math.radians(45 + phi / 2.0)) ** 2
    if 'stiff' in movement_class or 'supported' in movement_class:
        selected = 'at-rest/intermediate'
        k_use = max((ka + k0) / 2.0, ka)
    elif 'yielding' in movement_class or 'cantilever' in movement_class:
        selected = 'active'
        k_use = ka
    else:
        selected = 'active'
        k_use = ka
    dry_height = min(depth, gw)
    wet_height = max(depth - gw, 0.0)
    effective_force = 0.5 * k_use * gamma * dry_height ** 2
    effective_force += k_use * gamma * dry_height * wet_height + 0.5 * k_use * (gamma - 9.81) * wet_height ** 2
    surcharge_force = k_use * surcharge * depth
    water_force = 0.5 * 9.81 * wet_height ** 2
    total = effective_force + surcharge_force + water_force
    return {
        'selected_envelope': selected,
        'ka': round(ka, 3),
        'k0': round(k0, 3),
        'kp': round(kp, 3),
        'design_k': round(k_use, 3),
        'effective_soil_force_kN_per_m': round(effective_force, 1),
        'surcharge_force_kN_per_m': round(surcharge_force, 1),
        'water_force_kN_per_m': round(water_force, 1),
        'total_lateral_force_kN_per_m': round(total, 1),
    }


def basal_heave_check(ground_model, excavation_config):
    depth = float(excavation_config.get('excavation_depth_m', 8.0))
    su = float(excavation_config.get('formation_soil_su_kPa', 35.0))
    surcharge = float(excavation_config.get('surcharge_kPa', 0.0))
    gamma = float(excavation_config.get('formation_unit_weight_kn_m3', 18.0))
    uplift_head = float(excavation_config.get('uplift_head_m', 0.0))
    heave_fs = 5.14 * su / max(gamma * depth + surcharge, 1.0)
    slab = float(excavation_config.get('basement_slab_thickness_m', 0.6))
    resisting = slab * 24.0 + gamma * 1.0
    uplift_pressure = 9.81 * uplift_head
    uplift_fs = resisting / max(uplift_pressure, 1.0)
    return {
        'basal_heave_fs': round(heave_fs, 2),
        'uplift_fs': round(uplift_fs, 2),
        'governing_base_fs': round(min(heave_fs, uplift_fs), 2),
        'formation_su_kPa': round(su, 1),
        'uplift_head_m': round(uplift_head, 2),
    }


def dewatering_screen(ground_model, excavation_config, monitoring_rows):
    drawdown = float(excavation_config.get('drawdown_target_m', 0.0))
    depth = float(excavation_config.get('excavation_depth_m', 0.0))
    stratum = select_stratum(ground_model['strata'], max(depth / 2.0, 0.5))
    k = max(float(stratum.get('permeability_m_s', 1e-7)), 1e-10)
    sensitivity = str(excavation_config.get('adjacent_asset_sensitivity', 'medium')).lower()
    drawdown_factor = drawdown * (2.0 if sensitivity == 'high' else 1.0)
    inflow_index = k * max(drawdown, 0.1) * max(depth, 1.0) * 86400.0
    observed = max([float(row.get('piezometric_drawdown_m', 0.0)) for row in monitoring_rows] + [0.0])
    if inflow_index > 20 or drawdown_factor > 8:
        risk = 'high'
    elif inflow_index > 5 or drawdown_factor > 4:
        risk = 'medium'
    else:
        risk = 'low'
    return {
        'drawdown_target_m': round(drawdown, 2),
        'observed_drawdown_m': round(observed, 2),
        'permeability_m_s': k,
        'inflow_index_m3_per_day_per_m': round(inflow_index, 2),
        'drawdown_risk_class': risk,
    }


def monitoring_state(monitoring_rows):
    latest = monitoring_rows[-1] if monitoring_rows else {}
    settlement = float(latest.get('settlement_mm', 0.0))
    wall = float(latest.get('wall_deflection_mm', 0.0))
    drawdown = float(latest.get('piezometric_drawdown_m', 0.0))
    strut = float(latest.get('strut_load_kN', 0.0))
    amber = settlement > 12 or wall > 20 or drawdown > 3.0 or strut > 900
    red = settlement > 18 or wall > 28 or drawdown > 4.5 or strut > 1100
    state = 'red' if red else 'amber' if amber else 'green'
    return {
        'latest_settlement_mm': round(settlement, 1),
        'latest_wall_deflection_mm': round(wall, 1),
        'latest_drawdown_m': round(drawdown, 2),
        'latest_support_load_kN': round(strut, 1),
        'overall_trigger_state': state,
    }


def shallow_option_screen(ground_model, foundation_scheme):
    founding = select_stratum(ground_model['strata'], float(foundation_scheme.get('planned_foundation_depth_m', 1.5)))
    bearing = foundation_bearing_capacity(founding, foundation_scheme)
    settlement = settlement_screen(founding, foundation_scheme)
    preferred = 'shallow_foundation' if bearing['bearing_reserve_ratio'] >= 1.2 and settlement['settlement_utilization_ratio'] <= 0.8 else 'piled_or_piled_raft'
    warnings = []
    if bearing['bearing_reserve_ratio'] < 1.0:
        warnings.append('applied service pressure exceeds screened allowable bearing pressure.')
    if settlement['settlement_utilization_ratio'] > 1.0:
        warnings.append('predicted settlement exceeds the project serviceability limit.')
    if ground_model.get('groundwater', {}).get('depth_m', 99.0) < float(foundation_scheme.get('planned_foundation_depth_m', 1.5)) + 1.0:
        warnings.append('groundwater is close to founding level and may complicate excavation and blinding operations.')
    metrics = {**bearing, **settlement, 'preferred_system': preferred}
    return metrics, warnings, [
        f"Screen founding stratum at {foundation_scheme.get('planned_foundation_depth_m', 1.5)} m depth.",
        'Compare bearing reserve against service pressure and serviceability movement limit.',
        f"Preferred concept after screening: {preferred.replace('_', ' ')}."
    ]


def settlement_strategy(ground_model, foundation_scheme):
    founding = select_stratum(ground_model['strata'], float(foundation_scheme.get('planned_foundation_depth_m', 1.5)))
    settlement = settlement_screen(founding, foundation_scheme)
    ratio = settlement['settlement_utilization_ratio']
    if ratio > 1.0:
        strategy = 'switch concept or improve ground before proceeding'
    elif ratio > 0.75:
        strategy = 'keep concept only with stiffness confirmation and observational monitoring'
    else:
        strategy = 'serviceability margin acceptable with routine monitoring'
    warnings = []
    if founding.get('Cc', 0.0) > 0.2:
        warnings.append('compressible founding stratum suggests consolidation-sensitive performance.')
    if ratio > 0.8:
        warnings.append('movement demand is close to the allowable settlement limit.')
    metrics = {**settlement, 'serviceability_strategy': strategy}
    return metrics, warnings, [
        'Estimate immediate and consolidation-driven settlement demand.',
        'Compare movement demand to the project serviceability limit.',
        f"Serviceability strategy: {strategy}."
    ]


def raft_piled_raft_screen(ground_model, foundation_scheme):
    founding = select_stratum(ground_model['strata'], float(foundation_scheme.get('planned_foundation_depth_m', 1.5)))
    raft_settlement = settlement_screen(founding, foundation_scheme)
    pile = pile_group_screen(ground_model, foundation_scheme)
    reduction = clamp(0.35 + 0.08 * min(pile['spacing_over_diameter'], 4.0), 0.35, 0.7)
    piled_raft_settlement = raft_settlement['predicted_total_settlement_mm'] * (1.0 - reduction)
    if piled_raft_settlement < raft_settlement['allowable_total_settlement_mm'] * 0.8:
        preferred = 'piled_raft'
    elif raft_settlement['settlement_utilization_ratio'] <= 0.8:
        preferred = 'raft'
    else:
        preferred = 'pile_group'
    warnings = []
    if preferred != 'raft' and pile['downdrag_ratio'] > 0.15:
        warnings.append('downdrag may erode the assumed piled-raft benefit and needs project-specific verification.')
    metrics = {
        'raft_predicted_total_settlement_mm': raft_settlement['predicted_total_settlement_mm'],
        'piled_raft_predicted_total_settlement_mm': round(piled_raft_settlement, 1),
        'assumed_load_share_to_piles_percent': round(reduction * 100, 1),
        'preferred_system': preferred,
        'group_efficiency': pile['group_efficiency'],
    }
    return metrics, warnings, [
        'Compare raft settlement against a piled-raft settlement reduction assumption.',
        'Use group spacing to infer plausible pile load sharing.',
        f"Preferred concept after screening: {preferred.replace('_', ' ')}."
    ]


def foundation_construction_risk(ground_model, foundation_scheme, excavation_config):
    risks = []
    groundwater = ground_model.get('groundwater', {}).get('depth_m', 99.0)
    basement = float(foundation_scheme.get('basement_depth_m', 0.0))
    if groundwater < basement + 1.0:
        risks.append(('high', 'groundwater management', 'water table is close to the basement excavation level.'))
    if float(foundation_scheme.get('pile_length_m', 0.0)) > 22.0:
        risks.append(('medium', 'pile logistics', 'long piles may constrain sequence and spoil handling.'))
    if float(excavation_config.get('excavation_depth_m', 0.0)) > 10.0:
        risks.append(('high', 'deep excavation interface', 'foundation construction depends on a deep temporary works sequence.'))
    if not risks:
        risks.append(('medium', 'general coordination', 'coordinate founding level, inspection hold points, and waterproofing interfaces.'))
    highest = 'low'
    for rating, _, _ in risks:
        if rating == 'high':
            highest = 'high'
            break
        if rating == 'medium':
            highest = 'medium'
    metrics = {
        'highest_risk_rating': highest,
        'risk_count': len(risks),
        'risk_register': [{'rating': r, 'topic': t, 'detail': d} for r, t, d in risks],
    }
    warnings = [f"{topic}: {detail}" for _, topic, detail in risks if _ == 'high']
    return metrics, warnings, [
        'Review groundwater, excavation interface, sequencing, and pile logistics risks.',
        f"Highest construction risk rating: {highest}."
    ]


def bearing_settlement_audit(ground_model, foundation_scheme):
    founding = select_stratum(ground_model['strata'], float(foundation_scheme.get('planned_foundation_depth_m', 1.5)))
    bearing = foundation_bearing_capacity(founding, foundation_scheme)
    settlement = settlement_screen(founding, foundation_scheme)
    findings = []
    status = 'pass'
    if bearing['bearing_reserve_ratio'] < 1.1:
        findings.append('bearing reserve is slim for the current service load.')
        status = 'warning'
    if settlement['settlement_utilization_ratio'] > 0.85:
        findings.append('settlement is governing or nearly governing the concept.')
        status = 'warning'
    if ground_model.get('groundwater', {}).get('depth_m', 99.0) < float(foundation_scheme.get('planned_foundation_depth_m', 1.5)):
        findings.append('groundwater correction should be checked explicitly in the formal bearing calculation.')
        status = 'warning'
    if not findings:
        findings.append('bearing and settlement assumptions look internally consistent at screening level.')
    metrics = {
        'audit_status': status,
        'bearing_reserve_ratio': bearing['bearing_reserve_ratio'],
        'settlement_utilization_ratio': settlement['settlement_utilization_ratio'],
        'audit_findings': findings,
    }
    return metrics, findings if status != 'pass' else [], [
        'Cross-check founding level, bearing reserve, settlement demand, and groundwater assumptions.',
        f"Audit status: {status}."
    ]


def retaining_design(ground_model, excavation_config):
    env = retaining_envelope(ground_model, excavation_config)
    embedment = float(excavation_config.get('wall_embedment_m', 0.0))
    depth = float(excavation_config.get('excavation_depth_m', 1.0))
    ratio = embedment / max(depth, 0.5)
    if depth <= 6:
        system = 'cantilever_or_light_propped_wall'
    elif depth <= 12:
        system = 'propped_secant_or_diaphragm_wall'
    else:
        system = 'multi-level_propped_or_anchored_diaphragm_wall'
    warnings = []
    if ratio < 0.55:
        warnings.append('embedment-to-excavation ratio is low for a stiff retained cut.')
    metrics = {**env, 'embedment_ratio': round(ratio, 2), 'recommended_wall_system': system}
    return metrics, warnings, [
        'Estimate design lateral force and combine it with wall restraint assumptions.',
        f"Recommend {system.replace('_', ' ')} at screening level."
    ]


def pressure_envelope(ground_model, excavation_config):
    env = retaining_envelope(ground_model, excavation_config)
    warnings = []
    if env['selected_envelope'] != 'active' and float(excavation_config.get('excavation_depth_m', 0.0)) > 8.0:
        warnings.append('at-rest or intermediate pressure may govern because the support system is stiff and movement is limited.')
    return env, warnings, [
        'Select an earth-pressure envelope consistent with wall movement and support stiffness.',
        f"Selected envelope: {env['selected_envelope']}."
    ]


def staged_excavation_review(ground_model, excavation_config):
    stages = []
    support_levels = excavation_config.get('support_levels_m', [])
    depth = float(excavation_config.get('excavation_depth_m', 0.0))
    current = 0.0
    for index, level in enumerate(support_levels + [depth], start=1):
        exposure = float(level) - current
        status = 'warning' if exposure > 4.5 else 'pass'
        stages.append({'stage': index, 'from_m': round(current, 2), 'to_m': round(float(level), 2), 'unsupported_exposure_m': round(exposure, 2), 'status': status})
        current = float(level)
    warnings = [f"stage {stage['stage']} has unsupported exposure of {stage['unsupported_exposure_m']} m" for stage in stages if stage['status'] == 'warning']
    metrics = {'sequence_status': 'warning' if warnings else 'pass', 'stages': stages, 'support_level_count': len(support_levels)}
    return metrics, warnings, [
        'Review stage-by-stage excavation exposure between support installations.',
        f"Sequence status: {metrics['sequence_status']}."
    ]


def basal_heave_uplift(ground_model, excavation_config):
    checks = basal_heave_check(ground_model, excavation_config)
    warnings = []
    if checks['basal_heave_fs'] < 1.5:
        warnings.append('basal heave safety margin is low at screening level.')
    if checks['uplift_fs'] < 1.2:
        warnings.append('uplift resistance is low and pressure relief or heavier base restraint may be required.')
    return checks, warnings, [
        'Separate undrained basal heave and hydraulic uplift checks.',
        f"Governing base factor of safety: {checks['governing_base_fs']}."
    ]


def dewatering_excavation(ground_model, excavation_config, monitoring_rows):
    screen = dewatering_screen(ground_model, excavation_config, monitoring_rows)
    warnings = []
    if screen['drawdown_risk_class'] != 'low':
        warnings.append('drawdown control should be tied to off-site settlement and recharge review.')
    return screen, warnings, [
        'Estimate inflow intensity and off-site drawdown sensitivity.',
        f"Drawdown risk class: {screen['drawdown_risk_class']}."
    ]


def temporary_works_control(monitoring_rows):
    state = monitoring_state(monitoring_rows)
    action = 'continue_with_routine_review'
    if state['overall_trigger_state'] == 'amber':
        action = 'increase_monitoring_and_hold_next_stage_until_review'
    elif state['overall_trigger_state'] == 'red':
        action = 'stop_next_stage_and_execute_response_plan'
    warnings = [] if state['overall_trigger_state'] == 'green' else [f"temporary works trigger state is {state['overall_trigger_state']}"]
    metrics = {**state, 'recommended_action': action}
    return metrics, warnings, [
        'Translate monitoring data into trigger states and explicit actions.',
        f"Overall trigger state: {state['overall_trigger_state']}."
    ]


def run_mode(mode, ground_model, foundation_scheme, excavation_config, monitoring_rows):
    if mode == 'shallow_screen':
        return shallow_option_screen(ground_model, foundation_scheme)
    if mode == 'settlement_strategy':
        return settlement_strategy(ground_model, foundation_scheme)
    if mode == 'raft_piled_raft':
        return raft_piled_raft_screen(ground_model, foundation_scheme)
    if mode == 'pile_group':
        return pile_group_screen(ground_model, foundation_scheme), [], ['Screen pile-group efficiency and downdrag.']
    if mode == 'foundation_construction_risk':
        return foundation_construction_risk(ground_model, foundation_scheme, excavation_config)
    if mode == 'bearing_settlement_audit':
        return bearing_settlement_audit(ground_model, foundation_scheme)
    if mode == 'retaining_design':
        return retaining_design(ground_model, excavation_config)
    if mode == 'pressure_envelope':
        return pressure_envelope(ground_model, excavation_config)
    if mode == 'staged_excavation_review':
        return staged_excavation_review(ground_model, excavation_config)
    if mode == 'basal_heave_uplift':
        return basal_heave_uplift(ground_model, excavation_config)
    if mode == 'dewatering_excavation':
        return dewatering_excavation(ground_model, excavation_config, monitoring_rows)
    if mode == 'temporary_works_control':
        return temporary_works_control(monitoring_rows)
    raise ValueError(f'unsupported mode: {mode}')


def build_report(metrics, warnings, steps):
    lines = [
        f"# {PROFILE['display_name']}",
        '',
        '## Summary',
        PROFILE['summary'].capitalize(),
        '',
        '## Key metrics',
    ]
    for key, value in metrics.items():
        if isinstance(value, list):
            continue
        if isinstance(value, dict):
            continue
        lines.append(f"- {key.replace('_', ' ')}: {value}")
    lines.extend(['', '## Engineering workflow'])
    for step in steps:
        lines.append(f"- {step}")
    lines.extend(['', '## Warnings'])
    if warnings:
        for warning in warnings:
            lines.append(f"- {warning}")
    else:
        lines.append('- no blocking warnings in the standalone screening run.')
    list_metrics = {k: v for k, v in metrics.items() if isinstance(v, list)}
    dict_metrics = {k: v for k, v in metrics.items() if isinstance(v, dict)}
    if list_metrics or dict_metrics:
        lines.extend(['', '## Structured details'])
        if list_metrics:
            for key, value in list_metrics.items():
                lines.append(f"### {key.replace('_', ' ')}")
                for item in value:
                    lines.append(f"- {item}")
        if dict_metrics:
            for key, value in dict_metrics.items():
                lines.append(f"### {key.replace('_', ' ')}")
                lines.append('```json')
                lines.append(json.dumps(value, indent=2))
                lines.append('```')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default=str(Path(__file__).resolve().parent.parent / 'assets' / 'example-inputs'))
    parser.add_argument('--output-dir', default=str(Path(__file__).resolve().parent.parent / 'outputs'))
    args = parser.parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ground_model = load_json(input_dir / 'ground_model.json')
    foundation_scheme = load_json(input_dir / 'foundation_scheme.json') if (input_dir / 'foundation_scheme.json').exists() else {}
    excavation_config = load_json(input_dir / 'excavation_support_config.json') if (input_dir / 'excavation_support_config.json').exists() else {}
    monitoring_rows = load_csv(input_dir / 'monitoring.csv')

    metrics, warnings, steps = run_mode(PROFILE['mode'], ground_model, foundation_scheme, excavation_config, monitoring_rows)
    handoff = {
        'skill': PROFILE['name'],
        'mode': PROFILE['mode'],
        'summary': PROFILE['summary'],
        'metrics': metrics,
        'warnings': warnings,
        'assumptions': [
            'standalone skill output is a production-oriented screening or review layer.',
            'project-specific design code checks and numerical models remain necessary where flagged.'
        ],
        'recommended_next_tools': PROFILE.get('recommended_next_tools', []),
    }
    artifact_map = {
        'skill': PROFILE['name'],
        'artifacts': {
            'ground-model': 'reuse existing project ground-model dataset where available',
            'analysis-plan': f"attach {PROFILE['name']} workflow output to the analysis-plan or reviewer layer",
            'results': 'store computed metrics and structured details in results or option-matrix artifacts',
            'review-checklist': 'store warnings and audit notes where this skill is used as a reviewer',
            'final-report': 'append engineering_report.md summary to the final report only after review'
        }
    }

    (output_dir / 'swarm_handoff.json').write_text(json.dumps(handoff, indent=2))
    (output_dir / 'engineering_report.md').write_text(build_report(metrics, warnings, steps))
    (output_dir / 'case_file_artifact_map.json').write_text(json.dumps(artifact_map, indent=2))
    print(json.dumps({'status': 'ok', 'skill': PROFILE['name'], 'output_dir': str(output_dir)}, indent=2))


if __name__ == '__main__':
    main()
