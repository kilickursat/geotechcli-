# Universal design basis

Use a universal, non-country-specific framing.

- Foundations and settlement: Terzaghi, Meyerhof, Schmertmann, API/FHWA/Eurocode-style preliminary practice
- Retaining and excavation support: Rankine/Coulomb/Jaky concepts, staged support logic, basal stability screening, groundwater control review
- Observational method: staged monitoring, trigger levels, hold points, and pre-agreed response actions

This bundle is intended for production-oriented screening, option comparison, audit, and observational control. It should clearly state when a specialist numerical model or project-specific code check is still required.
