# Output contract

Every run must write these three files:

1. `swarm_handoff.json`
   - concise, structured handoff for an orchestration or swarm layer
2. `engineering_report.md`
   - human-readable engineering note with key findings, assumptions, warnings, and actions
3. `case_file_artifact_map.json`
   - deterministic mapping of what should be saved into project or case-file artifacts

The outputs should stay production-oriented and reviewable. They are not final signed design deliverables.
