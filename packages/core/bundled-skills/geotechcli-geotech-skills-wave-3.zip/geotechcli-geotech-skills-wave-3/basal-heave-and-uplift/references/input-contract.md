# Shared input contract

Use these local files when the skill runs in standalone mode.

- `ground_model.json`
  - strata, groundwater depth, unit weight, phi, su, stiffness, permeability, compressibility indicators
- `foundation_scheme.json`
  - loads, allowable settlements, basement depth, candidate foundation concepts, pile geometry, raft geometry
- `excavation_support_config.json`
  - excavation depth, wall type, embedment, support levels, surcharge, drawdown target, movement class, adjacent sensitivity
- `monitoring.csv`
  - settlement, wall deflection, drawdown, and support-load observations used for trigger review or construction control

Skills may use only the subset they need, but they should not silently invent missing files. Missing inputs must be carried into warnings, assumptions, and the swarm handoff.
