# geotechCLI repo integration notes

When promoting this standalone skill into geotechCLI itself, follow the existing contribution flow:

1. implement the deterministic calculation or evaluator in `packages/core/src/geo/`
2. register it in `packages/core/src/agents/tools.ts`
3. add guardrails in `packages/core/src/agents/guardrails.ts`
4. expose it to the swarm tool list in `packages/core/src/agents/swarm.ts`
5. add tests in `packages/core/tests/`
6. add an optional CLI surface in `packages/cli/src/commands/`

Keep tools deterministic and let the skill provide orchestration, assumptions discipline, and review structure.
