# Basal Heave And Uplift

## Summary
Screen undrained basal heave and hydraulic uplift risks for excavations, slabs, and base formation levels.

## Key metrics
- basal heave fs: 0.98
- uplift fs: 0.54
- governing base fs: 0.54
- formation su kPa: 45.0
- uplift head m: 8.0

## Engineering workflow
- Separate undrained basal heave and hydraulic uplift checks.
- Governing base factor of safety: 0.54.

## Warnings
- basal heave safety margin is low at screening level.
- uplift resistance is low and pressure relief or heavier base restraint may be required.
