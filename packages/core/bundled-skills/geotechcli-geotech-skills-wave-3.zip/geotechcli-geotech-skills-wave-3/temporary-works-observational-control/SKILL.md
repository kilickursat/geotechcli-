---
name: temporary-works-observational-control
description: turn excavation and retaining temporary works into a trigger-action-monitoring workflow with explicit green, amber, and red controls. use when the task is in geotechnical engineering and needs a repeatable retaining-excavation workflow. use when the task is to build observational control for temporary works, define trigger levels, or connect monitoring data to excavation-stage actions. this skill is for standalone packaged execution with local files and should produce swarm handoff json, engineering markdown, and case-file artifact mapping.
---

# Temporary Works Observational Control

## Overview

Use this skill to make the agent more reliable in retaining excavation work. The skill wraps a deterministic standalone tool, a strict local-file contract, and a repeatable engineering output pattern.

## Workflow

1. Confirm that the required local files exist. Read the shared contract in `references/input-contract.md`.
2. Identify the governing founding, excavation, groundwater, and serviceability conditions from the input files.
3. Run the standalone tool script.
4. Review `swarm_handoff.json`, `engineering_report.md`, and `case_file_artifact_map.json`.
5. If the result is marginal or warning-heavy, route the output to a reviewer or follow-on skill instead of treating it as final design.

## What this skill is trying to answer

- translate excavation monitoring into green, amber, and red actions for settlement, wall deflection, drawdown, and support load.
- make hold points, response owners, and recommended actions explicit.
- produce an operational control sheet that can be reused in daily site review.

## Tooling

Run the deterministic script like this:

```bash
python scripts/temporary_works_observational_control.py --input-dir <path/to/input-dir> --output-dir <path/to/output-dir>
```

The default bundled input directory is `assets/example-inputs/` and the default output directory is `outputs/`.

## Inputs

- Use `ground_model.json` as the geotechnical baseline.
- Use `foundation_scheme.json` for foundation-driven tasks.
- Use `excavation_support_config.json` for retaining and excavation tasks.
- Use `monitoring.csv` when trigger logic, observational control, or sequence review matters.

Read the exact contract in `references/input-contract.md`.

## Output contract

Always keep the three-output pattern.

- `swarm_handoff.json` for machine-readable orchestration
- `engineering_report.md` for the engineering note
- `case_file_artifact_map.json` for deterministic storage mapping

Read the details in `references/output-contract.md`.

## Design basis

Keep the skill universal and production-oriented. Use the overview in `references/design-basis.md` and explicitly state when project-specific code checks or specialist numerical models are still required.

## Repo integration

If this standalone skill is later promoted into geotechCLI itself, use `references/repo-integration.md` to convert the logic into `packages/core/src/geo/`, register tools, add guardrails, expose swarm access, and add tests.
