# Temporary Works Observational Control

## Summary
Turn excavation and retaining temporary works into a trigger-action-monitoring workflow with explicit green, amber, and red controls.

## Key metrics
- latest settlement mm: 16.0
- latest wall deflection mm: 24.0
- latest drawdown m: 3.8
- latest support load kN: 980.0
- overall trigger state: amber
- recommended action: increase_monitoring_and_hold_next_stage_until_review

## Engineering workflow
- Translate monitoring data into trigger states and explicit actions.
- Overall trigger state: amber.

## Warnings
- temporary works trigger state is amber
