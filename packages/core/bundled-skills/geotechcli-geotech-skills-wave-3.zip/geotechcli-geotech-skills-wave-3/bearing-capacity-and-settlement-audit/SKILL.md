---
name: bearing-capacity-and-settlement-audit
description: audit whether bearing and settlement assumptions are mutually consistent and whether the chosen foundation concept is defensible. use when the task is in geotechnical engineering and needs a repeatable foundations workflow. use when the task is to check consistency between bearing capacity and settlement calculations, audit assumptions before review, or challenge whether the foundation concept is over- or under-conservative. this skill is for standalone packaged execution with local files and should produce swarm handoff json, engineering markdown, and case-file artifact mapping.
---

# Bearing Capacity And Settlement Audit

## Overview

Use this skill to make the agent more reliable in foundations work. The skill wraps a deterministic standalone tool, a strict local-file contract, and a repeatable engineering output pattern.

## Workflow

1. Confirm that the required local files exist. Read the shared contract in `references/input-contract.md`.
2. Identify the governing founding, excavation, groundwater, and serviceability conditions from the input files.
3. Run the standalone tool script.
4. Review `swarm_handoff.json`, `engineering_report.md`, and `case_file_artifact_map.json`.
5. If the result is marginal or warning-heavy, route the output to a reviewer or follow-on skill instead of treating it as final design.

## What this skill is trying to answer

- cross-check governing stratum, water table, founding level, stiffness, and load assumptions.
- flag when bearing looks acceptable but settlement likely governs, or vice versa.
- produce audit findings that can be handed directly to a reviewer or case-file layer.

## Tooling

Run the deterministic script like this:

```bash
python scripts/bearing_capacity_and_settlement_audit.py --input-dir <path/to/input-dir> --output-dir <path/to/output-dir>
```

The default bundled input directory is `assets/example-inputs/` and the default output directory is `outputs/`.

## Inputs

- Use `ground_model.json` as the geotechnical baseline.
- Use `foundation_scheme.json` for foundation-driven tasks.
- Use `excavation_support_config.json` for retaining and excavation tasks.
- Use `monitoring.csv` when trigger logic, observational control, or sequence review matters.

Read the exact contract in `references/input-contract.md`.

## Output contract

Always keep the three-output pattern.

- `swarm_handoff.json` for machine-readable orchestration
- `engineering_report.md` for the engineering note
- `case_file_artifact_map.json` for deterministic storage mapping

Read the details in `references/output-contract.md`.

## Design basis

Keep the skill universal and production-oriented. Use the overview in `references/design-basis.md` and explicitly state when project-specific code checks or specialist numerical models are still required.

## Repo integration

If this standalone skill is later promoted into geotechCLI itself, use `references/repo-integration.md` to convert the logic into `packages/core/src/geo/`, register tools, add guardrails, expose swarm access, and add tests.
