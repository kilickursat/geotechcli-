# Bearing Capacity And Settlement Audit

## Summary
Audit whether bearing and settlement assumptions are mutually consistent and whether the chosen foundation concept is defensible.

## Key metrics
- audit status: warning
- bearing reserve ratio: 1.25
- settlement utilization ratio: 12.17

## Engineering workflow
- Cross-check founding level, bearing reserve, settlement demand, and groundwater assumptions.
- Audit status: warning.

## Warnings
- settlement is governing or nearly governing the concept.
- groundwater correction should be checked explicitly in the formal bearing calculation.

## Structured details
### audit findings
- settlement is governing or nearly governing the concept.
- groundwater correction should be checked explicitly in the formal bearing calculation.
