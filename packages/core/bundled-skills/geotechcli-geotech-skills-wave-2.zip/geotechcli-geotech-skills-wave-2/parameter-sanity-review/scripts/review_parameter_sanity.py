#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, num, artifact_bundle, write_bundle

SKILL = 'parameter-sanity-review'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    issues = []
    warnings = []

    for layer in strata(data['ground_model']):
        phi = num(layer.get('phi_deg'))
        cu = num(layer.get('cu_kpa'))
        gamma = num(layer.get('gamma_kN_m3'))
        k = num(layer.get('permeability_m_s'))
        name = layer.get('unit_name')
        if phi is not None and (phi < 0 or phi > 45):
            issues.append(f'{name} has phi outside the plausible soil range')
        if cu is not None and cu < 0:
            issues.append(f'{name} has negative undrained shear strength')
        if gamma is not None and not (14 <= gamma <= 24):
            warnings.append(f'{name} has unit weight outside typical soil range')
        if k is not None and k > 1e-2:
            warnings.append(f'{name} has extremely high permeability and may reflect unit or typing error')

    results = data['results']
    bc = results.get('bearing_capacity', {})
    if num(bc.get('factor_of_safety')) is not None and (num(bc.get('factor_of_safety')) or 0.0) <= 1.0:
        issues.append('bearing capacity factor of safety is not credible for design use')
    settlement = results.get('settlement', {})
    if num(settlement.get('estimated_total_mm')) is not None and (num(settlement.get('estimated_total_mm')) or 0.0) < 0:
        issues.append('settlement result is negative')
    liq = results.get('liquefaction', {})
    if num(liq.get('min_fs')) is not None and (num(liq.get('min_fs')) or 0.0) < 0:
        issues.append('liquefaction factor of safety is negative')

    verdict = 'APPROVED' if not issues else 'REJECTED'
    confidence = int(max(35, min(92, 88 - 10 * len(issues) - 4 * len(warnings))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'parameter sanity review completed',
        'confidence': confidence,
        'verdict': verdict,
        'results': {'issues': issues, 'warnings': warnings},
        'required_next_steps': ['fix hard blockers before downstream reviewer approval'] if issues else ['continue with reviewer audit while tracking soft anomalies'],
    }

    lines = ['# Parameter Sanity Review', '', '## Verdict', '', f'- {verdict}', f'- Confidence: {confidence}']
    if issues:
        lines.extend(['', '## Hard blockers', ''])
        lines.extend([f'- {item}' for item in issues])
    if warnings:
        lines.extend(['', '## Warnings', ''])
        lines.extend([f'- {item}' for item in warnings])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'parameter sanity review completed', {'confidence': confidence, 'verdict': verdict}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'verdict': verdict}, indent=2))

if __name__ == '__main__':
    main()
