#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, text, num, artifact_bundle, write_bundle

SKILL = 'evidence-to-casefile-curator'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    evidence = []
    for layer in strata(data['ground_model']):
        evidence.append({'class': 'Observed', 'label': f"{text(layer.get('unit_name'))} from {layer.get('from_m')} m to {layer.get('to_m')} m", 'source': 'ground_model.json'})
    if num(data['groundwater'].get('groundwater_depth_m')) is not None:
        evidence.append({'class': 'Observed', 'label': f"groundwater depth {data['groundwater'].get('groundwater_depth_m')} m", 'source': 'groundwater_conditions.json'})
    for name, result in data['results'].items():
        evidence.append({'class': 'Computed', 'label': name.replace('_', ' '), 'source': 'deterministic_results.json', 'summary': json.dumps(result)[:160]})
    if data['hazard']:
        evidence.append({'class': 'Normative', 'label': 'hazard profile used in reviewer logic', 'source': 'hazard_profile.json'})

    confidence = int(max(45, min(95, 76 + len(evidence))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'evidence bundle curated for case-file use',
        'confidence': confidence,
        'results': {'evidence_records': evidence, 'evidence_count': len(evidence)},
        'required_next_steps': ['map the evidence records into case-file persistence or report citations'],
    }

    lines = ['# Evidence To Casefile Curator', '', '## Evidence records', '']
    lines.extend([f"- {item['class']}: {item['label']} (source: {item['source']})" for item in evidence])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'evidence bundle curated', {'confidence': confidence, 'evidence_count': len(evidence)}, 'engineering_report.md', 'swarm_handoff.json', evidence=True)
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'evidence_count': len(evidence)}, indent=2))

if __name__ == '__main__':
    main()
