# Repo integration contract

## Standalone executable tool

- script: `scripts/curate_casefile_evidence.py`
- suggested standalone tool name: `curate_casefile_evidence_bundle`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/review/evidence_to_casefile_curator.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "curate the evidence and artifact bundle for the project case file"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
