#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, num, artifact_bundle, write_bundle

SKILL = 'design-basis-and-calculation-coverage'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    context = data['project_context']
    results = data['results']

    required = {
        'settlement_limit_mm': context.get('settlement_limit_mm'),
        'excavation_depth_m': context.get('excavation_depth_m'),
        'temporary_factor_of_safety_min': context.get('temporary_factor_of_safety_min'),
        'permanent_factor_of_safety_min': context.get('permanent_factor_of_safety_min'),
        'groundwater_depth_m': data['groundwater'].get('groundwater_depth_m'),
        'seismic_pga_g': data['hazard'].get('seismic_pga_g'),
    }
    missing_basis = [key for key, value in required.items() if value in (None, '', [])]

    expected_results = ['bearing_capacity', 'settlement', 'excavation_dewatering', 'liquefaction']
    missing_results = [key for key in expected_results if key not in results]

    coverage_score = max(0, 100 - 10 * len(missing_basis) - 10 * len(missing_results))
    verdict = 'CONDITIONAL' if missing_basis or missing_results else 'APPROVED'
    if len(missing_basis) + len(missing_results) >= 4:
        verdict = 'REJECTED'

    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'design basis and calculation coverage audit completed',
        'confidence': max(35, min(92, coverage_score)),
        'verdict': verdict,
        'results': {
            'missing_design_basis_items': missing_basis,
            'missing_calculation_outputs': missing_results,
            'coverage_score': coverage_score,
        },
        'required_next_steps': ['close missing basis items and missing calculations before final recommendation'],
    }

    lines = ['# Design Basis And Calculation Coverage Audit', '', '## Verdict', '', f'- {verdict}', f'- Coverage score: {coverage_score}']
    lines.extend(['', '## Missing design-basis items', ''])
    lines.extend([f'- {item}' for item in missing_basis] or ['- none'])
    lines.extend(['', '## Missing calculation outputs', ''])
    lines.extend([f'- {item}' for item in missing_results] or ['- none'])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'design basis and calculation coverage audit completed', {'coverage_score': coverage_score, 'verdict': verdict}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'verdict': verdict}, indent=2))

if __name__ == '__main__':
    main()
