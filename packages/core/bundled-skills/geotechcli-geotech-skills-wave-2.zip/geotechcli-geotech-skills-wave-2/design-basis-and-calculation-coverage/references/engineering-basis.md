    # Engineering basis

    This skill is intentionally universal rather than country-specific.

    ## Governing posture

    - use deterministic-first engineering logic
    - preserve uncertainty instead of hiding it
    - produce reviewer-friendly structured outputs
    - support later promotion into repo-native geotechCLI tools

    ## Skill-specific basis

    - a robust agent should know not only what the calculations say but also which calculations are still missing.
- flag omissions in serviceability, groundwater, seismic, staging, and monitoring basis early.

    ## Limits

    - this skill supports robust preliminary design and review thinking, not final project-specific certification
    - downstream deterministic calculations, project standards selection, and licensed engineering review may still be required
