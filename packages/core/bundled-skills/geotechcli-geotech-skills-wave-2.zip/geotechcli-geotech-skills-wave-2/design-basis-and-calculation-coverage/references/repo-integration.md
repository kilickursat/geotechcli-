# Repo integration contract

## Standalone executable tool

- script: `scripts/audit_design_basis.py`
- suggested standalone tool name: `audit_design_basis_and_calculation_coverage`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/review/design_basis_and_calculation_coverage.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "audit design basis completeness and calculation coverage"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
