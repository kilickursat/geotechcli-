#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, num, artifact_bundle, write_bundle

SKILL = 'standards-and-safety-factor-audit'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    context = data['project_context']
    results = data['results']
    issues = []
    warnings = []
    checks = []

    min_temp_fos = num(context.get('temporary_factor_of_safety_min'), 1.3) or 1.3
    min_perm_fos = num(context.get('permanent_factor_of_safety_min'), 1.5) or 1.5
    settlement_limit = num(context.get('settlement_limit_mm'), 25) or 25

    temp_exc = num((results.get('temporary_excavation_stability') or {}).get('factor_of_safety'))
    checks.append({'name': 'temporary excavation stability', 'status': 'pass' if temp_exc is not None and temp_exc >= min_temp_fos else 'warning', 'detail': f'fos = {temp_exc}, screening minimum = {min_temp_fos}'})
    if temp_exc is not None and temp_exc < min_temp_fos:
        warnings.append('temporary excavation stability falls below screening minimum')

    piping = num((results.get('excavation_dewatering') or {}).get('piping_fos'))
    checks.append({'name': 'piping safety factor', 'status': 'pass' if piping is not None and piping >= min_temp_fos else 'warning', 'detail': f'fos = {piping}, screening minimum = {min_temp_fos}'})
    if piping is not None and piping < min_temp_fos:
        warnings.append('piping factor of safety falls below the screening minimum')

    bearing = num((results.get('bearing_capacity') or {}).get('factor_of_safety'))
    checks.append({'name': 'bearing capacity safety factor', 'status': 'pass' if bearing is not None and bearing >= min_perm_fos else 'warning', 'detail': f'fos = {bearing}, screening minimum = {min_perm_fos}'})
    if bearing is not None and bearing < min_perm_fos:
        warnings.append('bearing factor of safety is below the screening minimum')

    liq_fs = num((results.get('liquefaction') or {}).get('min_fs'))
    checks.append({'name': 'liquefaction trigger margin', 'status': 'fail' if liq_fs is not None and liq_fs < 1.0 else 'pass', 'detail': f'min fs = {liq_fs}, screening minimum = 1.0'})
    if liq_fs is not None and liq_fs < 1.0:
        issues.append('liquefaction screening indicates triggering remains possible')

    settlement = num((results.get('settlement') or {}).get('estimated_total_mm'))
    checks.append({'name': 'settlement serviceability', 'status': 'warning' if settlement is not None and settlement > settlement_limit else 'pass', 'detail': f'settlement = {settlement} mm, screening limit = {settlement_limit} mm'})
    if settlement is not None and settlement > settlement_limit:
        warnings.append('screened settlement exceeds the project serviceability target')

    verdict = 'REJECTED' if issues else ('CONDITIONAL' if warnings else 'APPROVED')
    confidence = int(max(35, min(90, 84 - 10 * len(issues) - 5 * len(warnings))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'standards and safety factor audit completed',
        'confidence': confidence,
        'verdict': verdict,
        'results': {'checks': checks, 'issues': issues, 'warnings': warnings},
        'required_next_steps': ['resolve rejected items before approval'] if verdict == 'REJECTED' else ['close conditional items or carry them into the reviewer narrative'],
    }

    lines = ['# Standards And Safety Factor Audit', '', '## Verdict', '', f'- {verdict}', f'- Confidence: {confidence}', '', '## Checks', '']
    lines.extend([f"- {item['name']}: {item['status']} — {item['detail']}" for item in checks])
    if issues:
        lines.extend(['', '## Rejected items', ''])
        lines.extend([f'- {item}' for item in issues])
    if warnings:
        lines.extend(['', '## Conditional items', ''])
        lines.extend([f'- {item}' for item in warnings])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'standards and safety factor audit completed', {'confidence': confidence, 'verdict': verdict}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'verdict': verdict}, indent=2))

if __name__ == '__main__':
    main()
