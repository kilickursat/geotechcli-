    # Engineering basis

    This skill is intentionally universal rather than country-specific.

    ## Governing posture

    - use deterministic-first engineering logic
    - preserve uncertainty instead of hiding it
    - produce reviewer-friendly structured outputs
    - support later promotion into repo-native geotechCLI tools

    ## Skill-specific basis

    - use universal screening thresholds only; do not present the audit as a project-specific code-compliance certificate.
- separate acceptance, conditional acceptance, and rejection clearly so the swarm reviewer can act on the result.

    ## Limits

    - this skill supports robust preliminary design and review thinking, not final project-specific certification
    - downstream deterministic calculations, project standards selection, and licensed engineering review may still be required
