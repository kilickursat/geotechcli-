# Repo integration contract

## Standalone executable tool

- script: `scripts/audit_standards_safety.py`
- suggested standalone tool name: `audit_standards_and_safety_factors`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/review/standards_and_safety_factor_audit.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "audit standards alignment and safety factors for the current results"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
