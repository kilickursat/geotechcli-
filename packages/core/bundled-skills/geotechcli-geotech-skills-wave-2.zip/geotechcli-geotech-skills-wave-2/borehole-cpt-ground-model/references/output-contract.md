# Standard output contract

Each skill produces three files in the requested output directory.

## 1. `swarm_handoff.json`

Machine-readable summary for downstream orchestration.

Expected top-level keys:
- `skill`
- `status`
- `summary`
- `confidence`
- `results`
- `required_next_steps`

Reviewer-oriented skills may also include:
- `verdict`
- `issues`
- `warnings`
- `actions`

## 2. `engineering_report.md`

Human-readable engineering note with:
- status or verdict
- key findings
- risk or uncertainty statements
- recommended next actions

## 3. `case_file_artifact_map.json`

Case-file-ready artifact guidance with:
- `skill`
- `screening_basis`
- `artifacts`
- `summary`
- `results_headline`

These outputs are intentionally aligned with geotechCLI's artifact and case-file direction so the standalone skills can be promoted later without changing their output shape.
