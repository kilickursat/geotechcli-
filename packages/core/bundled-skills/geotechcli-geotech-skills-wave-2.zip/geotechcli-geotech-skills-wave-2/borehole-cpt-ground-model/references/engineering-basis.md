    # Engineering basis

    This skill is intentionally universal rather than country-specific.

    ## Governing posture

    - use deterministic-first engineering logic
    - preserve uncertainty instead of hiding it
    - produce reviewer-friendly structured outputs
    - support later promotion into repo-native geotechCLI tools

    ## Skill-specific basis

    - correlate borehole intervals and cpt trends conservatively; prefer repeated boundaries and repeatable trends over isolated anomalies.
- carry lateral variability and ambiguous unit boundaries forward as uncertainty instead of forcing a false clean model.

    ## Limits

    - this skill supports robust preliminary design and review thinking, not final project-specific certification
    - downstream deterministic calculations, project standards selection, and licensed engineering review may still be required
