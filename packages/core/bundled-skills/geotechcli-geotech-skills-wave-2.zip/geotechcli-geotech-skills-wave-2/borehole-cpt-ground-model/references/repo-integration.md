# Repo integration contract

## Standalone executable tool

- script: `scripts/build_ground_model.py`
- suggested standalone tool name: `synthesize_borehole_cpt_ground_model`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/site/borehole_cpt_ground_model.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "build a conceptual ground model from boreholes and cpt data"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
