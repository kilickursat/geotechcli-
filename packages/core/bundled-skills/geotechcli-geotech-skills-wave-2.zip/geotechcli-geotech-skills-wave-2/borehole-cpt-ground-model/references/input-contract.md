# Shared input contract

These wave-2 skills use a common file-based contract so they can be combined in a parent workspace or promoted into repo-native geotechCLI workflows later.

## Core files

- `ground_model.json`
  - conceptual stratigraphy and preliminary parameters by layer
  - expected keys include `stratigraphy`, `from_m`, `to_m`, `unit_name`, `uscs_symbol`, `gamma_kN_m3`, `phi_deg`, `cu_kpa`, `permeability_m_s`, `spt_n60`, and optional stiffness or compressibility fields
- `project_context.json`
  - project type, excavation depth, adjacency sensitivity, serviceability targets, monitoring thresholds, and workflow notes
- `boreholes.csv`
  - interval-level borehole rows with `borehole_id`, `depth_from_m`, `depth_to_m`, unit identifiers, descriptions, and optional SPT values
- `cpt_soundings.csv`
  - depth-level CPT rows with `sounding_id`, `depth_m`, `qc_mpa`, `fs_kpa`, `rf_pct`, and interpreted soil behavior where available
- `lab_results.csv`
  - laboratory rows with `test_type`, index and strength fields, and optional compressibility fields
- `groundwater_conditions.json`
  - groundwater depth, seasonal high, confined head, artesian screening, and drawdown sensitivity
- `hazard_profile.json`
  - seismic and geomorphic hazard context used for liquefaction and reviewer workflows
- `deterministic_results.json`
  - stored outputs from geotechcli or equivalent deterministic calculations used by reviewer skills
- `instrumentation.csv`
  - monitoring data with current value, amber trigger, red trigger, and trend notes

## Guidance

- Skills should never assume every file is perfectly populated.
- Missing files or fields should reduce confidence and become explicit assumptions, warnings, or blockers.
- Use the same contract when promoting these skills into repo-native agent or CLI workflows.

## Priority files for this skill

- `ground_model.json`
- `project_context.json`
- `boreholes.csv`
- `cpt_soundings.csv`
- `lab_results.csv`
- `groundwater_conditions.json`
- `hazard_profile.json`
- `deterministic_results.json`
- `instrumentation.csv`
