#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from collections import Counter
from common_io import load_shared_inputs, strata, cpt_rows_in_layer, borehole_rows_for_unit, num, text, average, artifact_bundle, write_bundle

SKILL = 'borehole-cpt-ground-model'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    ground_model = data['ground_model']
    boreholes = data['boreholes']
    cpt = data['cpt']
    groundwater = data['groundwater']

    units = []
    warnings = []
    for layer in strata(ground_model):
        unit_name = text(layer.get('unit_name'), 'unknown unit')
        bh_rows = borehole_rows_for_unit(boreholes, unit_name)
        cpt_rows = cpt_rows_in_layer(cpt, layer)
        borehole_count = len({text(row.get('borehole_id'), 'BH-UNK') for row in bh_rows})
        avg_qc = average([num(row.get('qc_mpa')) for row in cpt_rows if num(row.get('qc_mpa')) is not None], 0.0)
        continuity = round(min(1.0, borehole_count / 3.0), 2)
        units.append({
            'layer_id': layer.get('layer_id'),
            'from_m': num(layer.get('from_m'), 0.0),
            'to_m': num(layer.get('to_m'), 0.0),
            'unit_name': unit_name,
            'uscs_symbol': layer.get('uscs_symbol'),
            'borehole_count': borehole_count,
            'avg_cpt_qc_mpa': round(avg_qc, 2),
            'continuity_index': continuity,
            'working_parameters': {
                'gamma_kN_m3': num(layer.get('gamma_kN_m3')),
                'phi_deg': num(layer.get('phi_deg')),
                'cu_kpa': num(layer.get('cu_kpa')),
                'permeability_m_s': num(layer.get('permeability_m_s')),
            },
        })
        if continuity < 0.67:
            warnings.append(f'lateral continuity for {unit_name} is only moderate or weak')
        if borehole_count == 0:
            warnings.append(f'{unit_name} is present in the conceptual model but not clearly supported by borehole rows')

    qc_values = [num(row.get('qc_mpa')) for row in cpt if num(row.get('qc_mpa')) is not None]
    dominant_units = [unit['unit_name'] for unit in units]
    groundwater_depth = num(groundwater.get('groundwater_depth_m'))
    confidence = int(max(45, min(92, 86 - 4 * len(warnings) + (4 if qc_values else -6) + (4 if groundwater_depth is not None else -8))))

    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'conceptual ground model synthesized from borehole and cpt evidence',
        'confidence': confidence,
        'results': {
            'ground_model_units': units,
            'dominant_units': dominant_units,
            'avg_site_qc_mpa': round(average([value for value in qc_values if value is not None], 0.0), 2),
            'groundwater_depth_m': groundwater_depth,
            'warnings': warnings,
        },
        'required_next_steps': [
            'review weak continuity or unsupported boundaries before detailed zoning',
            'carry uncertain unit boundaries into the assumptions and uncertainty registers',
        ],
    }

    report_lines = ['# Borehole CPT Ground Model Report', '', '## Ground model summary', '']
    report_lines.append(f'- Confidence: {confidence}')
    report_lines.append(f'- Groundwater depth: {groundwater_depth} m')
    report_lines.append('')
    report_lines.append('## Correlated units')
    report_lines.append('')
    for unit in units:
        report_lines.append(f"- {unit['unit_name']}: {unit['from_m']} m to {unit['to_m']} m, boreholes supporting unit = {unit['borehole_count']}, avg CPT qc = {unit['avg_cpt_qc_mpa']} MPa, continuity index = {unit['continuity_index']}")
    if warnings:
        report_lines.extend(['', '## Warnings', ''])
        report_lines.extend([f'- {warning}' for warning in warnings])
    report_lines.extend(['', '## Recommended next steps', '', '- review boundary uncertainty before deterministic zoning', '- use the working parameters as preliminary values only'])
    report = '\n'.join(report_lines) + '\n'

    artifact = artifact_bundle(SKILL, 'conceptual ground model synthesized', {'confidence': confidence, 'unit_count': len(units)}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'confidence': confidence}, indent=2))

if __name__ == '__main__':
    main()
