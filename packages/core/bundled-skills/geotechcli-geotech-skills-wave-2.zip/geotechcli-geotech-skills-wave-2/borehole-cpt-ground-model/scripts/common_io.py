#!/usr/bin/env python3
import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Optional


def load_json(path: Path, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not path.exists():
        return default or {}
    return json.loads(path.read_text(encoding='utf-8'))


def load_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))


def num(value: Any, default: Optional[float] = None) -> Optional[float]:
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return default
    try:
        return float(text)
    except ValueError:
        return default


def text(value: Any, default: str = '') -> str:
    if value is None:
        return default
    result = str(value).strip()
    return result if result else default


def boolish(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {'1', 'true', 'yes', 'y', 'on'}


def clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def average(values: List[float], default: float = 0.0) -> float:
    cleaned = [value for value in values if value is not None]
    return sum(cleaned) / len(cleaned) if cleaned else default


def load_shared_inputs(input_dir: Path) -> Dict[str, Any]:
    return {
        'ground_model': load_json(input_dir / 'ground_model.json'),
        'project_context': load_json(input_dir / 'project_context.json'),
        'boreholes': load_csv(input_dir / 'boreholes.csv'),
        'cpt': load_csv(input_dir / 'cpt_soundings.csv'),
        'labs': load_csv(input_dir / 'lab_results.csv'),
        'groundwater': load_json(input_dir / 'groundwater_conditions.json'),
        'hazard': load_json(input_dir / 'hazard_profile.json'),
        'results': load_json(input_dir / 'deterministic_results.json'),
        'instrumentation': load_csv(input_dir / 'instrumentation.csv'),
    }


def strata(ground_model: Dict[str, Any]) -> List[Dict[str, Any]]:
    items = ground_model.get('stratigraphy', []) or []
    return [item for item in items if isinstance(item, dict)]


def layer_mid(layer: Dict[str, Any]) -> float:
    frm = num(layer.get('from_m'), 0.0) or 0.0
    to = num(layer.get('to_m'), frm) or frm
    return (frm + to) / 2.0


def cpt_rows_in_layer(rows: List[Dict[str, str]], layer: Dict[str, Any]) -> List[Dict[str, str]]:
    frm = num(layer.get('from_m'), 0.0) or 0.0
    to = num(layer.get('to_m'), frm) or frm
    output = []
    for row in rows:
        depth = num(row.get('depth_m'))
        if depth is None:
            continue
        if frm <= depth < to:
            output.append(row)
    return output


def borehole_rows_for_unit(rows: List[Dict[str, str]], unit_name: str) -> List[Dict[str, str]]:
    target = text(unit_name).lower()
    return [row for row in rows if text(row.get('unit_name') or row.get('description')).lower() == target]


def classify_permeability(k: Optional[float]) -> str:
    if k is None:
        return 'unknown'
    if k <= 1e-9:
        return 'very low'
    if k <= 1e-7:
        return 'low'
    if k <= 1e-5:
        return 'moderate'
    if k <= 1e-3:
        return 'high'
    return 'very high'


def artifact_bundle(skill_name: str, summary: str, headline: Dict[str, Any], report_path: str, handoff_path: str, option_matrix: bool = False, data_quality: bool = False, evidence: bool = False) -> Dict[str, Any]:
    artifacts = []
    if data_quality:
        artifacts.append({'artifactType': 'data-quality', 'title': f'{skill_name} data quality', 'path': handoff_path, 'status': 'generated'})
    artifacts.extend([
        {'artifactType': 'analysis-plan', 'title': f'{skill_name} analysis plan', 'status': 'generated'},
        {'artifactType': 'results', 'title': f'{skill_name} results', 'path': handoff_path, 'status': 'generated'},
    ])
    if option_matrix:
        artifacts.append({'artifactType': 'option-matrix', 'title': f'{skill_name} option matrix', 'path': handoff_path, 'status': 'generated'})
    if evidence:
        artifacts.append({'artifactType': 'evidence', 'title': f'{skill_name} evidence bundle', 'path': handoff_path, 'status': 'generated'})
    artifacts.extend([
        {'artifactType': 'review-checklist', 'title': f'{skill_name} review checklist', 'status': 'manual-review-required'},
        {'artifactType': 'acceptance-status', 'title': f'{skill_name} acceptance status', 'verdict': 'needs-review'},
        {'artifactType': 'final-report', 'title': f'{skill_name} report', 'path': report_path, 'status': 'generated'},
    ])
    return {
        'skill': skill_name,
        'screening_basis': 'universal international screening basis with deterministic-first geotechnical workflows',
        'artifacts': artifacts,
        'summary': summary,
        'results_headline': headline,
    }


def write_bundle(output_dir: Path, handoff: Dict[str, Any], report: str, artifact_map: Dict[str, Any]) -> Dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    handoff_path = output_dir / 'swarm_handoff.json'
    report_path = output_dir / 'engineering_report.md'
    artifact_path = output_dir / 'case_file_artifact_map.json'
    handoff_path.write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    report_path.write_text(report, encoding='utf-8')
    artifact_path.write_text(json.dumps(artifact_map, indent=2), encoding='utf-8')
    return {
        'swarm_handoff': str(handoff_path),
        'engineering_report': str(report_path),
        'case_file_artifact_map': str(artifact_path),
    }
