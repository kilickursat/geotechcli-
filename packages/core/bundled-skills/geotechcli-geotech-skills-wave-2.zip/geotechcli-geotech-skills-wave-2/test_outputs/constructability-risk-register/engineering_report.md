# Constructability Risk Register

## Risks

- deep excavation below seasonal high groundwater (severity: high; mitigation: stage dewatering and confirm uplift control)
- adjacent sensitivity may tighten movement and drawdown tolerance (severity: high; mitigation: upgrade monitoring and contingency planning)
- very weak material may reduce working platform or temporary support reliability (severity: high; mitigation: check access, support sequencing, and ground improvement needs)
- obstructions may disrupt drilling or piling operations (severity: medium; mitigation: allow obstruction management in method statements)
- seismic demand may affect sequencing and temporary works conservatism (severity: medium; mitigation: confirm seismic basis for governing temporary or serviceability cases)
