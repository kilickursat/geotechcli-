# Instrumentation Trigger And Action Review

## Verdict

- CONDITIONAL
- Confidence: 80

## Instrument status

- S-01 (settlement at north boundary): 18.0 mm -> amber
- S-02 (settlement at core zone): 11.0 mm -> green
- P-01 (piezometer_drawdown at sand aquifer): 2.3 m -> amber
- I-01 (inclinometer at east wall): 19.0 mm -> amber-trend
- L-01 (load_cell at strut 2): 82.0 % -> green

## Actions

- increase review frequency and confirm contingency actions for S-01
- increase review frequency and confirm contingency actions for P-01
- increase review frequency and confirm contingency actions for I-01
