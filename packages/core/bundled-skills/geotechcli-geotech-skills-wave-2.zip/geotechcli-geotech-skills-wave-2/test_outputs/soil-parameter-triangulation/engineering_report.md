# Soil Parameter Triangulation Report

## Layer parameter sets

- fill: phi = 28.0, cu = None, gamma = 18.0, avg CPT qc = 2.1 MPa, confidence = 62
- soft silty clay: phi = 20.0, cu = 31.0, gamma = 17.23, avg CPT qc = 0.93 MPa, confidence = 80
- medium dense sand: phi = 33.0, cu = None, gamma = 18.95, avg CPT qc = 7.45 MPa, confidence = 80
- dense gravelly sand: phi = 38.0, cu = None, gamma = 20.4, avg CPT qc = 16.5 MPa, confidence = 80

## Warnings

- fill has no lab row inside its depth window

## Recommended next steps

- record selected values in the assumptions register
- check whether lower-bound values control design
