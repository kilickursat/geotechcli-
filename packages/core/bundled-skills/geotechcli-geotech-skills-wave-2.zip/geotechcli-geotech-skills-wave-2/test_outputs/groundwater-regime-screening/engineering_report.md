# Groundwater Regime Screening Report

## Summary

- Groundwater regime: shallow groundwater
- Groundwater depth: 3.2 m
- Seasonal high: 1.8 m
- Peak permeability regime: high
- Dewatering complexity: high
- Uplift risk: high

## Warnings

- seasonal high groundwater is above excavation formation level
- high permeability horizon may drive large inflow or drawdown demand
- confined head suggests uplift or artesian sensitivity

## Recommended next steps

- confirm seasonal variation and confined head before final excavation strategy
- align groundwater assumptions with seepage and observational control workflows
