# Standards And Safety Factor Audit

## Verdict

- REJECTED
- Confidence: 64

## Checks

- temporary excavation stability: warning — fos = 1.18, screening minimum = 1.3
- piping safety factor: pass — fos = 1.7, screening minimum = 1.3
- bearing capacity safety factor: pass — fos = 3.0, screening minimum = 1.5
- liquefaction trigger margin: fail — min fs = 0.95, screening minimum = 1.0
- settlement serviceability: warning — settlement = 32.0 mm, screening limit = 25.0 mm

## Rejected items

- liquefaction screening indicates triggering remains possible

## Conditional items

- temporary excavation stability falls below screening minimum
- screened settlement exceeds the project serviceability target
