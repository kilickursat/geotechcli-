# Site Investigation Data Quality Report

## Status

- Parse status: clean
- Confidence: 90

## Key checks

- ground model present: pass — 4 stratigraphy layers
- borehole coverage: pass — 12 borehole interval rows
- cpt coverage: pass — 7 cpt rows
- laboratory coverage: pass — lab test types = ['atterberg', 'density', 'direct_shear', 'oedometer', 'triaxial']
- groundwater definition: pass — groundwater depth = 3.2
- hazard definition: pass — seismic pga = 0.22

## Recommended next steps

- dataset is ready for preliminary deterministic workflows
