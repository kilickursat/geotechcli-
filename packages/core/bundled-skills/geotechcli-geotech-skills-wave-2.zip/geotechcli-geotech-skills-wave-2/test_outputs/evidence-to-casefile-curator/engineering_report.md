# Evidence To Casefile Curator

## Evidence records

- Observed: fill from 0.0 m to 1.5 m (source: ground_model.json)
- Observed: soft silty clay from 1.5 m to 8.0 m (source: ground_model.json)
- Observed: medium dense sand from 8.0 m to 15.0 m (source: ground_model.json)
- Observed: dense gravelly sand from 15.0 m to 24.0 m (source: ground_model.json)
- Observed: groundwater depth 3.2 m (source: groundwater_conditions.json)
- Computed: bearing capacity (source: deterministic_results.json)
- Computed: settlement (source: deterministic_results.json)
- Computed: pile group (source: deterministic_results.json)
- Computed: excavation dewatering (source: deterministic_results.json)
- Computed: liquefaction (source: deterministic_results.json)
- Computed: temporary excavation stability (source: deterministic_results.json)
- Computed: retaining wall (source: deterministic_results.json)
- Normative: hazard profile used in reviewer logic (source: hazard_profile.json)
