# Geological Uncertainty Register

## Ranked uncertainties

- localized cobble or obstruction risk appears in borehole descriptions (impact: medium; reduction path: allow for obstruction handling in construction planning)
- very weak near-surface material may be spatially variable (impact: high; reduction path: tighten near-surface investigation and serviceability assumptions)

## Recommended next steps

- carry high-impact uncertainty into reviewer and observational-method workflows
