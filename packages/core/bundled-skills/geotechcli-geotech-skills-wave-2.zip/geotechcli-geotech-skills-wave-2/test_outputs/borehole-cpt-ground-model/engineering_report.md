# Borehole CPT Ground Model Report

## Ground model summary

- Confidence: 92
- Groundwater depth: 3.2 m

## Correlated units

- fill: 0.0 m to 1.5 m, boreholes supporting unit = 3, avg CPT qc = 2.1 MPa, continuity index = 1.0
- soft silty clay: 1.5 m to 8.0 m, boreholes supporting unit = 3, avg CPT qc = 0.93 MPa, continuity index = 1.0
- medium dense sand: 8.0 m to 15.0 m, boreholes supporting unit = 3, avg CPT qc = 7.45 MPa, continuity index = 1.0
- dense gravelly sand: 15.0 m to 24.0 m, boreholes supporting unit = 3, avg CPT qc = 16.5 MPa, continuity index = 1.0

## Recommended next steps

- review boundary uncertainty before deterministic zoning
- use the working parameters as preliminary values only
