# Repo integration contract

## Standalone executable tool

- script: `scripts/audit_site_investigation.py`
- suggested standalone tool name: `audit_site_investigation_data_quality`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/site/site_investigation_data_quality.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "audit site investigation completeness and confidence for this project"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
