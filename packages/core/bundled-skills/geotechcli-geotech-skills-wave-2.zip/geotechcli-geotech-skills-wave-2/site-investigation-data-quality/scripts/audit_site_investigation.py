#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, num, artifact_bundle, write_bundle

SKILL = 'site-investigation-data-quality'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    checks = []
    issues = []
    warnings = []

    boreholes = data['boreholes']
    cpt = data['cpt']
    labs = data['labs']
    groundwater = data['groundwater']
    hazard = data['hazard']
    layers = strata(data['ground_model'])

    checks.append({'name': 'ground model present', 'status': 'pass' if layers else 'fail', 'detail': f'{len(layers)} stratigraphy layers'})
    if not layers:
        issues.append('ground model is missing or empty')

    checks.append({'name': 'borehole coverage', 'status': 'pass' if len(boreholes) >= 8 else 'warning', 'detail': f'{len(boreholes)} borehole interval rows'})
    if len(boreholes) < 8:
        warnings.append('borehole coverage is limited for robust zoning')

    checks.append({'name': 'cpt coverage', 'status': 'pass' if len(cpt) >= 6 else 'warning', 'detail': f'{len(cpt)} cpt rows'})
    if len(cpt) < 6:
        warnings.append('cpt coverage is limited for trend confirmation')

    lab_types = sorted({str(row.get('test_type', '')).strip().lower() for row in labs if row.get('test_type')})
    lab_ok = 'atterberg' in lab_types and 'triaxial' in lab_types
    checks.append({'name': 'laboratory coverage', 'status': 'pass' if lab_ok else 'warning', 'detail': f'lab test types = {lab_types}'})
    if not lab_ok:
        warnings.append('laboratory coverage is incomplete for robust parameter selection')

    groundwater_depth = num(groundwater.get('groundwater_depth_m'))
    checks.append({'name': 'groundwater definition', 'status': 'pass' if groundwater_depth is not None else 'fail', 'detail': f'groundwater depth = {groundwater_depth}'})
    if groundwater_depth is None:
        issues.append('groundwater definition is missing')

    pga = num(hazard.get('seismic_pga_g'))
    checks.append({'name': 'hazard definition', 'status': 'pass' if pga is not None else 'warning', 'detail': f'seismic pga = {pga}'})
    if pga is None:
        warnings.append('hazard definition is incomplete for liquefaction review')

    blocker_count = len([item for item in checks if item['status'] == 'fail'])
    confidence = int(max(25, min(95, 90 - 10 * blocker_count - 4 * len(warnings))))
    parse_status = 'blocked' if blocker_count else ('partial' if warnings else 'clean')
    next_steps = []
    if blocker_count:
        next_steps.append('close blocking data gaps before deterministic design decisions')
    if len(boreholes) < 8:
        next_steps.append('justify zoning confidence or increase borehole density')
    if len(cpt) < 6:
        next_steps.append('add CPT or equivalent trend data where lateral variability matters')
    if not lab_ok:
        next_steps.append('obtain missing laboratory index or strength testing')
    if pga is None:
        next_steps.append('define seismic demand for liquefaction or reviewer workflows')
    if not next_steps:
        next_steps.append('dataset is ready for preliminary deterministic workflows')

    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'site investigation data quality audit completed',
        'confidence': confidence,
        'parse_status': parse_status,
        'results': {'checks': checks, 'issues': issues, 'warnings': warnings},
        'required_next_steps': next_steps,
    }

    lines = ['# Site Investigation Data Quality Report', '', '## Status', '']
    lines.append(f'- Parse status: {parse_status}')
    lines.append(f'- Confidence: {confidence}')
    lines.extend(['', '## Key checks', ''])
    lines.extend([f"- {item['name']}: {item['status']} — {item['detail']}" for item in checks])
    if issues:
        lines.extend(['', '## Issues', ''])
        lines.extend([f'- {issue}' for issue in issues])
    if warnings:
        lines.extend(['', '## Warnings', ''])
        lines.extend([f'- {warning}' for warning in warnings])
    lines.extend(['', '## Recommended next steps', ''])
    lines.extend([f'- {step}' for step in next_steps])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'site investigation data quality audit completed', {'parse_status': parse_status, 'confidence': confidence}, 'engineering_report.md', 'swarm_handoff.json', data_quality=True)
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'parse_status': parse_status}, indent=2))

if __name__ == '__main__':
    main()
