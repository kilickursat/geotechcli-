---
name: site-investigation-data-quality
description: screen completeness, consistency, and decision-readiness of site investigation data before deterministic design workflows run. use when chatgpt needs use when chatgpt needs to audit boreholes, cpt, labs, groundwater, and hazard inputs; assign parse status and confidence; identify blockers; or create a structured handoff before design or reviewer skills continue
---

# Site Investigation Data Quality

## Overview

Run a deterministic-first geotechnical workflow for `site-investigation-data-quality` using the shared file contract. Use the bundled script to produce a swarm handoff, an engineering note, and a case-file-ready artifact map without relying on external services.

## Workflow

1. Confirm that the input files relevant to this workflow are present and review `references/input-contract.md`.
2. Run `scripts/audit_site_investigation.py` with `--input-dir` and `--output-dir`.
3. Read `swarm_handoff.json` first and use it as the machine-readable output for orchestration, downstream tools, or case-file promotion.
4. Read `engineering_report.md` next and surface the dominant engineering meaning, blockers, uncertainties, and recommended actions.
5. Read `case_file_artifact_map.json` last and use it to map outputs into geotechCLI case-file artifacts.
6. Escalate uncertainty instead of overcommitting whenever the evidence is thin, inconsistent, or outside screening scope.

## Required inputs

Read `references/input-contract.md` before running the script.

## Standard outputs

Read `references/output-contract.md` before presenting results.

## Tool scripts

- `scripts/audit_site_investigation.py`
- `scripts/common_io.py`

## Engineering rules

- Treat this skill as a production-oriented screening and review workflow, not a final contractual design approval.
- Reject automatic certainty when required data are missing or conflict materially.
- Keep the distinction between observed data, derived parameters, assumptions, and reviewer judgment explicit.
- Carry forward blocking uncertainty and list the next deterministic or investigative step needed.

## Engineering basis

Read `references/engineering-basis.md` for the domain basis and limits.

## Repo integration

Read `references/repo-integration.md` when promoting this standalone skill into repo-native geotechCLI tools, guardrails, swarm access, and CLI surfaces.
