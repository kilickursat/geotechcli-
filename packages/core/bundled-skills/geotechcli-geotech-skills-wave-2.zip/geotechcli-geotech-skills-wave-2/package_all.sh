#!/usr/bin/env bash
set -euo pipefail
for skill in borehole-cpt-ground-model site-investigation-data-quality soil-parameter-triangulation groundwater-regime-screening geotechnical-assumptions-register geological-uncertainty-register parameter-sanity-review standards-and-safety-factor-audit constructability-risk-register design-basis-and-calculation-coverage evidence-to-casefile-curator instrumentation-trigger-and-action-review; do
  python3 /home/oai/skills/skill-creator/scripts/package_skill.py /mnt/data/geotechcli-geotech-skills-wave-2/$skill /mnt/data/geotechcli-geotech-skills-wave-2/dist/$skill
done
