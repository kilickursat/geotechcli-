#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, num, text, artifact_bundle, write_bundle

SKILL = 'geotechnical-assumptions-register'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    assumptions = []
    context = data['project_context']
    groundwater = data['groundwater']

    if num(groundwater.get('groundwater_depth_m')) is None:
        assumptions.append({'category': 'groundwater', 'statement': 'assume groundwater depth from previous records until confirmed', 'impact': 'high', 'basis': 'missing measured groundwater level'})
    if not data['labs']:
        assumptions.append({'category': 'soil-parameter', 'statement': 'use preliminary ground-model strength and compressibility values', 'impact': 'high', 'basis': 'laboratory testing absent'})
    if not data['cpt']:
        assumptions.append({'category': 'soil-parameter', 'statement': 'use boreholes only for lateral trend interpretation', 'impact': 'medium', 'basis': 'cpt trend data absent'})

    for layer in strata(data['ground_model']):
        if num(layer.get('phi_deg')) is None and num(layer.get('cu_kpa')) is None:
            assumptions.append({'category': 'soil-parameter', 'statement': f"assume preliminary strength values for {text(layer.get('unit_name'), 'unnamed layer')}", 'impact': 'high', 'basis': 'no explicit phi or cu value stored'})
        if num(layer.get('permeability_m_s')) is None:
            assumptions.append({'category': 'groundwater', 'statement': f"assume permeability class for {text(layer.get('unit_name'), 'unnamed layer')}", 'impact': 'medium', 'basis': 'no permeability stored'})

    if num(context.get('settlement_limit_mm')) is None:
        assumptions.append({'category': 'load', 'statement': 'assume preliminary settlement acceptance criterion', 'impact': 'medium', 'basis': 'serviceability target absent'})
    if num(context.get('excavation_depth_m')) is None:
        assumptions.append({'category': 'geometry', 'statement': 'assume preliminary excavation or basement depth for temporary works screening', 'impact': 'medium', 'basis': 'excavation depth absent'})

    confidence = int(max(45, min(88, 84 - 5 * len(assumptions))))
    critical = [item['statement'] for item in assumptions if item['impact'] == 'high']
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'geotechnical assumptions register built',
        'confidence': confidence,
        'results': {'assumptions': assumptions, 'critical_assumptions': critical},
        'required_next_steps': ['review and accept, modify, or retire assumptions before final design recommendations'],
    }

    lines = ['# Geotechnical Assumptions Register', '', '## Assumptions', '']
    if assumptions:
        lines.extend([f"- {item['statement']} (impact: {item['impact']}; basis: {item['basis']})" for item in assumptions])
    else:
        lines.append('- No major assumptions were auto-generated from the sample input set.')
    if critical:
        lines.extend(['', '## Critical assumptions', ''])
        lines.extend([f'- {item}' for item in critical])
    lines.extend(['', '## Recommended next steps', '', '- convert accepted assumptions into project memory and reviewer checklists'])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'geotechnical assumptions register built', {'confidence': confidence, 'assumption_count': len(assumptions)}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'confidence': confidence}, indent=2))

if __name__ == '__main__':
    main()
