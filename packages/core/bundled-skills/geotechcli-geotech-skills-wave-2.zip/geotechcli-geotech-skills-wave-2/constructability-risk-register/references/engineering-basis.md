    # Engineering basis

    This skill is intentionally universal rather than country-specific.

    ## Governing posture

    - use deterministic-first engineering logic
    - preserve uncertainty instead of hiding it
    - produce reviewer-friendly structured outputs
    - support later promotion into repo-native geotechCLI tools

    ## Skill-specific basis

    - treat constructability as an engineering constraint equal to capacity and serviceability at early stage.
- focus on execution risk drivers that can change the preferred option, not generic project-management statements.

    ## Limits

    - this skill supports robust preliminary design and review thinking, not final project-specific certification
    - downstream deterministic calculations, project standards selection, and licensed engineering review may still be required
