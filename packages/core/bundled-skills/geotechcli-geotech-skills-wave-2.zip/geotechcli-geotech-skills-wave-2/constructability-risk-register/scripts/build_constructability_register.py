#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, num, text, artifact_bundle, write_bundle

SKILL = 'constructability-risk-register'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    context = data['project_context']
    groundwater = data['groundwater']
    risks = []

    if num(context.get('excavation_depth_m')) and (num(context.get('excavation_depth_m')) or 0.0) > 10 and num(groundwater.get('seasonal_high_depth_m')) is not None and (num(groundwater.get('seasonal_high_depth_m')) or 999) < (num(context.get('excavation_depth_m')) or 0.0):
        risks.append({'risk': 'deep excavation below seasonal high groundwater', 'severity': 'high', 'mitigation': 'stage dewatering and confirm uplift control'})
    if text(context.get('adjacent_sensitivity')).lower() == 'high':
        risks.append({'risk': 'adjacent sensitivity may tighten movement and drawdown tolerance', 'severity': 'high', 'mitigation': 'upgrade monitoring and contingency planning'})
    if any((num(layer.get('spt_n60'), 99) or 99) < 5 for layer in strata(data['ground_model'])):
        risks.append({'risk': 'very weak material may reduce working platform or temporary support reliability', 'severity': 'high', 'mitigation': 'check access, support sequencing, and ground improvement needs'})
    if any('cobbles' in text(row.get('description')).lower() for row in data['boreholes']):
        risks.append({'risk': 'obstructions may disrupt drilling or piling operations', 'severity': 'medium', 'mitigation': 'allow obstruction management in method statements'})
    if num((data['hazard'] or {}).get('seismic_pga_g'), 0.0) and (num((data['hazard'] or {}).get('seismic_pga_g'), 0.0) or 0.0) >= 0.2:
        risks.append({'risk': 'seismic demand may affect sequencing and temporary works conservatism', 'severity': 'medium', 'mitigation': 'confirm seismic basis for governing temporary or serviceability cases'})

    confidence = int(max(45, min(90, 82 - 4 * len(risks))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'constructability risk register completed',
        'confidence': confidence,
        'results': {'risks': risks},
        'required_next_steps': ['connect high-severity risks to staging, monitoring, and contingency planning'],
    }

    lines = ['# Constructability Risk Register', '', '## Risks', '']
    if risks:
        lines.extend([f"- {item['risk']} (severity: {item['severity']}; mitigation: {item['mitigation']})" for item in risks])
    else:
        lines.append('- No major constructability risk was auto-detected from the sample inputs.')
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'constructability risk register completed', {'confidence': confidence, 'risk_count': len(risks)}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'confidence': confidence}, indent=2))

if __name__ == '__main__':
    main()
