#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, num, text, artifact_bundle, write_bundle

SKILL = 'geological-uncertainty-register'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    layers = strata(data['ground_model'])
    boreholes = data['boreholes']
    groundwater = data['groundwater']

    uncertainties = []
    if len({text(row.get('unit_name') or row.get('description')) for row in boreholes}) > len(layers) + 1:
        uncertainties.append({'issue': 'borehole descriptions suggest more variability than the conceptual model shows', 'impact': 'high', 'reduction_path': 'refine zoning and revisit unit boundaries'})
    if any('cobbles' in text(row.get('description')).lower() for row in boreholes):
        uncertainties.append({'issue': 'localized cobble or obstruction risk appears in borehole descriptions', 'impact': 'medium', 'reduction_path': 'allow for obstruction handling in construction planning'})
    seasonal_high = num(groundwater.get('seasonal_high_depth_m'))
    if seasonal_high is None:
        uncertainties.append({'issue': 'seasonal groundwater range is uncertain', 'impact': 'high', 'reduction_path': 'confirm seasonal groundwater variation'})
    if any(num(layer.get('spt_n60'), 0.0) is not None and (num(layer.get('spt_n60'), 0.0) or 0.0) < 5 for layer in layers):
        uncertainties.append({'issue': 'very weak near-surface material may be spatially variable', 'impact': 'high', 'reduction_path': 'tighten near-surface investigation and serviceability assumptions'})

    confidence = int(max(40, min(90, 82 - 7 * len(uncertainties))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'geological uncertainty register completed',
        'confidence': confidence,
        'results': {'uncertainties': uncertainties},
        'required_next_steps': ['connect high-impact uncertainties to monitoring, assumptions, or investigation actions'],
    }

    lines = ['# Geological Uncertainty Register', '', '## Ranked uncertainties', '']
    if uncertainties:
        lines.extend([f"- {item['issue']} (impact: {item['impact']}; reduction path: {item['reduction_path']})" for item in uncertainties])
    else:
        lines.append('- No major geological uncertainty was auto-detected from the sample input set.')
    lines.extend(['', '## Recommended next steps', '', '- carry high-impact uncertainty into reviewer and observational-method workflows'])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'geological uncertainty register completed', {'confidence': confidence, 'uncertainty_count': len(uncertainties)}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'confidence': confidence}, indent=2))

if __name__ == '__main__':
    main()
