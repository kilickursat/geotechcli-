# Repo integration contract

## Standalone executable tool

- script: `scripts/build_uncertainty_register.py`
- suggested standalone tool name: `build_geological_uncertainty_register`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/site/geological_uncertainty_register.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "build the geological uncertainty register for this site"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
