    # Engineering basis

    This skill is intentionally universal rather than country-specific.

    ## Governing posture

    - use deterministic-first engineering logic
    - preserve uncertainty instead of hiding it
    - produce reviewer-friendly structured outputs
    - support later promotion into repo-native geotechCLI tools

    ## Skill-specific basis

    - uncertainty should be explicit, ranked, and connected to design consequence rather than hidden inside narrative prose.
- distinguish uncertainty that can be reduced by more investigation from uncertainty that must be managed by observational control or conservative design.

    ## Limits

    - this skill supports robust preliminary design and review thinking, not final project-specific certification
    - downstream deterministic calculations, project standards selection, and licensed engineering review may still be required
