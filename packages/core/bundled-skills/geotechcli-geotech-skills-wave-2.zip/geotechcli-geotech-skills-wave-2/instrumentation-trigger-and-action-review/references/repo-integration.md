# Repo integration contract

## Standalone executable tool

- script: `scripts/review_instrumentation_triggers.py`
- suggested standalone tool name: `review_instrumentation_triggers_and_actions`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/review/instrumentation_trigger_and_action_review.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "review instrumentation triggers and recommended actions"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
