    # Engineering basis

    This skill is intentionally universal rather than country-specific.

    ## Governing posture

    - use deterministic-first engineering logic
    - preserve uncertainty instead of hiding it
    - produce reviewer-friendly structured outputs
    - support later promotion into repo-native geotechCLI tools

    ## Skill-specific basis

    - triggers are action thresholds, not just plotting lines.
- escalate when current trends indicate likely threshold exceedance within the next review interval even if the latest value is still below the hard limit.

    ## Limits

    - this skill supports robust preliminary design and review thinking, not final project-specific certification
    - downstream deterministic calculations, project standards selection, and licensed engineering review may still be required
