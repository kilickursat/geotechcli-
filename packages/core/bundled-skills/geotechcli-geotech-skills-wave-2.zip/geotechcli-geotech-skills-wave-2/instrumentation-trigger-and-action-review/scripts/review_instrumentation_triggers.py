#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, num, text, artifact_bundle, write_bundle

SKILL = 'instrumentation-trigger-and-action-review'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    instruments = []
    actions = []
    for row in data['instrumentation']:
        value = num(row.get('value'))
        amber = num(row.get('amber'))
        red = num(row.get('red'))
        trend = text(row.get('trend'), 'unknown')
        status = 'green'
        if value is not None and red is not None and value >= red:
            status = 'red'
        elif value is not None and amber is not None and value >= amber:
            status = 'amber'
        elif trend == 'rising' and value is not None and amber is not None and value >= 0.9 * amber:
            status = 'amber-trend'
        instruments.append({
            'instrument': row.get('instrument'),
            'type': row.get('type'),
            'location': row.get('location'),
            'value': value,
            'unit': row.get('unit'),
            'status': status,
            'trend': trend,
        })
        if status == 'red':
            actions.append(f"immediate engineering review for {row.get('instrument')} at {row.get('location')}")
        elif status in {'amber', 'amber-trend'}:
            actions.append(f"increase review frequency and confirm contingency actions for {row.get('instrument')}")

    verdict = 'REJECTED' if any(item['status'] == 'red' for item in instruments) else ('CONDITIONAL' if actions else 'APPROVED')
    confidence = int(max(45, min(92, 86 - 5 * len([item for item in instruments if item['status'] == 'red']) - 2 * len([item for item in instruments if item['status'] in {'amber', 'amber-trend'}]))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'instrumentation trigger review completed',
        'confidence': confidence,
        'verdict': verdict,
        'results': {'instrument_status': instruments, 'actions': actions},
        'required_next_steps': ['apply observational-method actions and update the reviewer narrative'],
    }

    lines = ['# Instrumentation Trigger And Action Review', '', '## Verdict', '', f'- {verdict}', f'- Confidence: {confidence}', '', '## Instrument status', '']
    lines.extend([f"- {item['instrument']} ({item['type']} at {item['location']}): {item['value']} {item['unit']} -> {item['status']}" for item in instruments])
    if actions:
        lines.extend(['', '## Actions', ''])
        lines.extend([f'- {action}' for action in actions])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'instrumentation trigger review completed', {'confidence': confidence, 'verdict': verdict}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'verdict': verdict}, indent=2))

if __name__ == '__main__':
    main()
