#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, cpt_rows_in_layer, num, average, artifact_bundle, write_bundle

SKILL = 'soil-parameter-triangulation'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    labs = data['labs']
    cpt = data['cpt']
    parameter_sets = []
    warnings = []

    for layer in strata(data['ground_model']):
        frm = num(layer.get('from_m'), 0.0) or 0.0
        to = num(layer.get('to_m'), frm) or frm
        lab_rows = [row for row in labs if frm <= (num(row.get('depth_m'), -999) or -999) < to]
        cpt_rows = cpt_rows_in_layer(cpt, layer)
        phi_candidates = [num(layer.get('phi_deg'))] + [num(row.get('phi_deg')) for row in lab_rows]
        cu_candidates = [num(layer.get('cu_kpa'))] + [num(row.get('cu_kpa')) for row in lab_rows]
        gamma_candidates = [num(layer.get('gamma_kN_m3'))] + [num(row.get('gamma_kN_m3')) for row in lab_rows]
        qc_values = [num(row.get('qc_mpa')) for row in cpt_rows if num(row.get('qc_mpa')) is not None]
        phi_values = [value for value in phi_candidates if value is not None]
        cu_values = [value for value in cu_candidates if value is not None]
        gamma_values = [value for value in gamma_candidates if value is not None]
        recommended_phi = min(phi_values) if phi_values else None
        recommended_cu = min(cu_values) if cu_values else None
        recommended_gamma = average(gamma_values, 18.0) if gamma_values else None
        avg_qc = average([value for value in qc_values if value is not None], 0.0)
        layer_confidence = 80
        if len(lab_rows) == 0:
            layer_confidence -= 18
            warnings.append(f"{layer.get('unit_name')} has no lab row inside its depth window")
        if len(cpt_rows) == 0:
            layer_confidence -= 8
        if phi_values and max(phi_values) - min(phi_values) > 5:
            layer_confidence -= 10
            warnings.append(f"{layer.get('unit_name')} has wide phi spread")
        if cu_values and max(cu_values) - min(cu_values) > 20:
            layer_confidence -= 10
            warnings.append(f"{layer.get('unit_name')} has wide cu spread")
        parameter_sets.append({
            'layer_id': layer.get('layer_id'),
            'unit_name': layer.get('unit_name'),
            'depth_window_m': [frm, to],
            'recommended_parameters': {
                'phi_deg': recommended_phi,
                'cu_kpa': recommended_cu,
                'gamma_kN_m3': round(recommended_gamma, 2) if recommended_gamma is not None else None,
                'avg_cpt_qc_mpa': round(avg_qc, 2),
            },
            'evidence_counts': {'lab_rows': len(lab_rows), 'cpt_rows': len(cpt_rows)},
            'confidence': max(35, layer_confidence),
        })

    confidence = int(max(40, min(92, average([item['confidence'] for item in parameter_sets], 55))))
    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'soil parameter triangulation completed',
        'confidence': confidence,
        'results': {'layer_parameter_sets': parameter_sets, 'warnings': warnings},
        'required_next_steps': ['promote chosen values into explicit design assumptions before capacity or settlement checks'],
    }

    lines = ['# Soil Parameter Triangulation Report', '', '## Layer parameter sets', '']
    for item in parameter_sets:
        params = item['recommended_parameters']
        lines.append(f"- {item['unit_name']}: phi = {params['phi_deg']}, cu = {params['cu_kpa']}, gamma = {params['gamma_kN_m3']}, avg CPT qc = {params['avg_cpt_qc_mpa']} MPa, confidence = {item['confidence']}")
    if warnings:
        lines.extend(['', '## Warnings', ''])
        lines.extend([f'- {warning}' for warning in sorted(set(warnings))])
    lines.extend(['', '## Recommended next steps', '', '- record selected values in the assumptions register', '- check whether lower-bound values control design'])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'soil parameter triangulation completed', {'confidence': confidence, 'layer_count': len(parameter_sets)}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'confidence': confidence}, indent=2))

if __name__ == '__main__':
    main()
