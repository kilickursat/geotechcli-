# Repo integration contract

## Standalone executable tool

- script: `scripts/triangulate_parameters.py`
- suggested standalone tool name: `triangulate_soil_design_parameters`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/site/soil_parameter_triangulation.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "triangulate preliminary design parameters by soil layer"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
