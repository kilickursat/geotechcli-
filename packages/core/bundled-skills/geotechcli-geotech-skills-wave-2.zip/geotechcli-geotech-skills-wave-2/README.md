# geotechcli geotechnical skills wave 2

This workspace contains the next library expansion after the tunnel bundle.
It focuses on two high-leverage packs:

- pack a: site investigation and ground model
- pack g: reviewer and wisdom skills

Included skills:

- `borehole-cpt-ground-model`
- `site-investigation-data-quality`
- `soil-parameter-triangulation`
- `groundwater-regime-screening`
- `geotechnical-assumptions-register`
- `geological-uncertainty-register`
- `parameter-sanity-review`
- `standards-and-safety-factor-audit`
- `constructability-risk-register`
- `design-basis-and-calculation-coverage`
- `evidence-to-casefile-curator`
- `instrumentation-trigger-and-action-review`

Package each skill individually from `dist/<skill-name>/skill.zip`.
