# wave 2 integration todo

1. choose which standalone scripts should become repo-native deterministic tools first
2. add matching tool registry entries in `packages/core/src/agents/tools.ts`
3. add reviewer and parameter guardrails in `packages/core/src/agents/guardrails.ts`
4. extend swarm role allowlists in `packages/core/src/agents/swarm.ts`
5. add direct cli surfaces for the highest-value workflows
6. connect accepted outputs to the case-file and evidence persistence layers
7. add regression tests for data-quality and reviewer rejection cases
