# Repo integration contract

## Standalone executable tool

- script: `scripts/screen_groundwater.py`
- suggested standalone tool name: `screen_groundwater_regime`

## Proposed geotechCLI repo integration

- core module: `packages/core/src/geo/site/groundwater_regime_screening.ts`
- tool registry entry: `packages/core/src/agents/tools.ts`
- guardrails: `packages/core/src/agents/guardrails.ts`
- swarm access: `packages/core/src/agents/swarm.ts`
- cli surface: `geotech agent "screen the groundwater regime and dewatering exposure"`

## Suggested output shape

- `summary`
- `confidence`
- `results`
- `warnings`
- `requiredNextSteps`

## Suggested tests

- deterministic logic regression in `packages/core/tests/core.test.ts`
- swarm policy or allowlist checks in `packages/core/tests/swarm-policy.test.ts`
- reviewer regression if the skill gates agent conclusions
