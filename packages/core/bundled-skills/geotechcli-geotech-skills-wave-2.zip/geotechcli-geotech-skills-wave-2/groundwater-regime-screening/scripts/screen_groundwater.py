#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common_io import load_shared_inputs, strata, num, classify_permeability, artifact_bundle, write_bundle

SKILL = 'groundwater-regime-screening'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default='.')
    parser.add_argument('--output-dir', default='./output')
    args = parser.parse_args()

    data = load_shared_inputs(Path(args.input_dir))
    groundwater = data['groundwater']
    context = data['project_context']
    layers = strata(data['ground_model'])

    gw_depth = num(groundwater.get('groundwater_depth_m'))
    seasonal_high = num(groundwater.get('seasonal_high_depth_m'))
    confined_head = num(groundwater.get('confined_head_m'), 0.0) or 0.0
    excavation_depth = num(context.get('excavation_depth_m'))
    max_k = max([num(layer.get('permeability_m_s'), 0.0) or 0.0 for layer in layers] or [0.0])
    regime = 'uncertain'
    if gw_depth is not None:
        regime = 'shallow groundwater' if gw_depth <= 5.0 else 'moderate to deep groundwater'
    dewatering_complexity = 'high' if max_k >= 1e-4 or (seasonal_high is not None and excavation_depth is not None and seasonal_high < excavation_depth) else 'moderate'
    uplift_risk = 'high' if confined_head > 0.5 and excavation_depth is not None and excavation_depth > 8 else 'moderate' if confined_head > 0 else 'low'
    warnings = []
    if gw_depth is None:
        warnings.append('groundwater depth is not defined')
    if seasonal_high is not None and excavation_depth is not None and seasonal_high < excavation_depth:
        warnings.append('seasonal high groundwater is above excavation formation level')
    if max_k >= 1e-4:
        warnings.append('high permeability horizon may drive large inflow or drawdown demand')
    if confined_head > 0.5:
        warnings.append('confined head suggests uplift or artesian sensitivity')
    confidence = int(max(40, min(90, 84 - 6 * len(warnings) + (4 if gw_depth is not None else -10))))

    handoff = {
        'skill': SKILL,
        'status': 'ok',
        'summary': 'groundwater regime screening completed',
        'confidence': confidence,
        'results': {
            'groundwater_regime': regime,
            'groundwater_depth_m': gw_depth,
            'seasonal_high_depth_m': seasonal_high,
            'peak_permeability_regime': classify_permeability(max_k),
            'dewatering_complexity': dewatering_complexity,
            'uplift_risk': uplift_risk,
            'warnings': warnings,
        },
        'required_next_steps': ['carry groundwater and drawdown assumptions into excavation, seepage, and foundation workflows'],
    }

    lines = ['# Groundwater Regime Screening Report', '', '## Summary', '']
    lines.append(f'- Groundwater regime: {regime}')
    lines.append(f'- Groundwater depth: {gw_depth} m')
    lines.append(f'- Seasonal high: {seasonal_high} m')
    lines.append(f'- Peak permeability regime: {classify_permeability(max_k)}')
    lines.append(f'- Dewatering complexity: {dewatering_complexity}')
    lines.append(f'- Uplift risk: {uplift_risk}')
    if warnings:
        lines.extend(['', '## Warnings', ''])
        lines.extend([f'- {warning}' for warning in warnings])
    lines.extend(['', '## Recommended next steps', '', '- confirm seasonal variation and confined head before final excavation strategy', '- align groundwater assumptions with seepage and observational control workflows'])
    report = '\n'.join(lines) + '\n'

    artifact = artifact_bundle(SKILL, 'groundwater regime screening completed', {'confidence': confidence, 'dewatering_complexity': dewatering_complexity}, 'engineering_report.md', 'swarm_handoff.json')
    paths = write_bundle(Path(args.output_dir), handoff, report, artifact)
    print(json.dumps({'status': 'ok', 'outputs': paths, 'confidence': confidence}, indent=2))

if __name__ == '__main__':
    main()
