---
name: geotech-gbr-analyzer
description: analyze geotechnical baseline reports and related geotechnical documents for underground, trenchless, foundation, marine, and other construction projects. use when a user uploads pdf, docx, xlsx, xls, csv, or pasted text and wants a concise summary, highlights and takeaways, contractual baseline interpretation, gbr-vs-gdr separation, differing site condition exposure, or geotechnical risk analysis. also use for shield and hard-rock tbm projects to identify the likely tbm family, summarize relevant tbm specs, and estimate support pressure, penetration rate, and advance rate only when the uploaded evidence is sufficient and uncertainties are stated explicitly.
---

# Geotech GBR Analyzer

Use this skill to read, interpret, and assess geotechnical baseline reports and related project documents. Treat the GBR as the contractual baseline, not as a generic geological summary. Tie every material conclusion to evidence in the uploaded files.

## Workflow decision tree

1. Identify the requested outcome.
   - **Summary or briefing** -> follow the summary workflow.
   - **GBR or contract review** -> follow the baseline assessment workflow.
   - **Risk analysis** -> follow the risk workflow.
   - **Shield or hard-rock TBM project** -> also follow the TBM workflow.

2. Identify the construction context before analyzing risk.
   - Examples: shield TBM, hard-rock TBM, NATM/SEM, drill-and-blast, shafts, HDD or microtunneling, cut-and-cover, deep foundations, marine works, or other geotechnical construction.
   - Do **not** force a TBM framing onto non-TBM projects.

3. Identify the source set and each document's role.
   - GBR -> contractual baseline.
   - GDR, boring logs, lab data, spreadsheets -> factual data sources.
   - Contract clauses, specs, and special provisions -> entitlement and risk-allocation context.
   - Drawings and alignment tables -> spatial context, chainage, cover, interfaces, and geometry.

## Core rules

- Anchor every significant conclusion to evidence from the uploaded files.
- Cite evidence with file name plus page, section, table, sheet, chainage, station, borehole, or cell range whenever available.
- Distinguish clearly between:
  - observed data,
  - interpreted ground model,
  - contractual baseline, and
  - your own inference.
- Prefer explicit baseline statements over implied interpretations from logs.
- Call out conflicts between files instead of smoothing them over.
- State uncertainty openly. If critical data is missing, say what is missing and how it affects confidence.
- Avoid false precision. Use sensible ranges and rounded values for estimates.
- Never present desk estimates as design approval, operating instructions, or guaranteed production.

## File intake workflow

1. Read every provided source that matters to the question, including pdf, docx, xlsx, xls, csv, and pasted text.
2. Build a quick mental source map:
   - file name,
   - document type,
   - role in the contract or technical record,
   - relevant sections or tabs,
   - any obvious limitations.
3. Extract the items that drive interpretation:
   - baseline statements,
   - ground and groundwater conditions,
   - alignment or location references,
   - construction method,
   - monitoring or measurability thresholds,
   - contractual language on differing site conditions and payment.
4. Reconcile the documents. If the GBR, GDR, and logs point in different directions, report the contradiction explicitly.

For detailed review criteria, use [references/review-framework.md](references/review-framework.md).
For non-TBM construction contexts and risk lenses, use [references/construction-contexts.md](references/construction-contexts.md).
For TBM selection and performance-estimation guidance, use [references/tbm-estimation-guide.md](references/tbm-estimation-guide.md).

## Summary workflow

Use this when the user asks for a summary, briefing note, highlights, or key takeaways.

Focus on:
- what the document says the foreseen conditions are,
- what matters most to construction,
- the main risk drivers,
- the most important ambiguities or gaps,
- the likely commercial consequences if the baseline is weak.

Keep the summary concise but evidence-based. Prefer a decision-useful summary over a chapter-by-chapter paraphrase.

## Baseline assessment workflow

Use this when the user asks whether a GBR is strong, balanced, clear, measurable, or claim-resistant.

Evaluate whether the document:
- contains clear, measurable, and location-specific baseline statements,
- allocates risk in a way that can actually be applied during construction,
- stays distinct from the raw data in the GDR and logs,
- covers soil, rock, groundwater, and behavior relevant to the method of construction,
- links baseline conditions to construction impact,
- is internally consistent across the baseline text, drawings, logs, and contract clauses.

When a baseline is vague, explain why it is weak and suggest how it could be rewritten in a measurable form.

## Risk workflow

Build the risk analysis around the actual construction method and site conditions.

For each material risk, describe:
- the hazard or uncertainty,
- why it matters,
- the evidence supporting it,
- the likely construction or commercial consequence,
- whether the risk allocation appears clear or ambiguous,
- leading indicators or missing data,
- your confidence level.

Tailor the risks to the method. Example topics include groundwater inflow, settlement, mixed face, squeezing, swelling, faults, karst, obstruction, cobbles and boulders, gas, contamination, abrasivity, support-class variability, wall leakage, base heave, frac-out, or alignment-control issues.

## TBM workflow

Use this only when the project clearly involves shield TBM or hard-rock TBM tunnelling, or when the user explicitly asks for TBM interpretation.

1. Confirm the tunnel context.
   - diameter,
   - cover,
   - alignment,
   - geology by reach,
   - groundwater regime,
   - segmental or other lining,
   - stated machine concept if provided.

2. Identify the likely TBM family and explain why.
   - EPB,
   - slurry shield,
   - open or gripper,
   - single shield,
   - double shield,
   - mixed-ground or hybrid configuration.

3. Summarize the relevant TBM specs mentioned in the source set.
   - diameter,
   - cutterhead and opening ratio,
   - thrust,
   - torque,
   - installed power,
   - pressure-control system,
   - screw conveyor or slurry circuit,
   - ring length,
   - backup and logistics constraints.

4. Estimate only what the evidence can support.
   - **Support pressure:** only for closed-face shield TBMs and only when cover, groundwater, and face-stability context are available. Report a pressure window or range, not a false-precision single value.
   - **Penetration rate:** mainly for hard-rock TBMs or cases with adequate rock-mass and machine information.
   - **Advance rate:** only after considering penetration or cycle rate, utilization, segment erection, interventions, maintenance, muck handling, and logistics.

5. If the data is insufficient, say so directly.
   - Downgrade to qualitative guidance or scenario ranges instead of inventing numbers.
   - State assumptions and confidence explicitly.

Use [references/tbm-estimation-guide.md](references/tbm-estimation-guide.md) for the evidence checklist and estimation rules.

## Default output structure

Use this structure unless the user asks for a different format.

# [Project or document analysis title]

## Executive summary
Give a short decision-useful overview of the main findings.

## Key highlights and takeaways
List the highest-value technical and contractual takeaways.

## Source basis
Identify the files and sections that drive the analysis.

## GBR and baseline assessment
Summarize the baseline, note strong and weak statements, and explain any GBR-versus-GDR issues.

## Geotechnical and construction risk analysis
Present the key risks, consequences, evidence, and confidence.

## TBM section
Include this section only when relevant.

### Likely TBM family and rationale
### Key TBM specs from the documents
### Support pressure estimate
### Penetration rate estimate
### Advance rate estimate
### Assumptions, uncertainty, and missing data

## Red flags and ambiguities
Highlight contradictions, missing thresholds, vague wording, or weak risk-allocation language.

## Recommended next data or questions
List the few additional items that would improve confidence most.

## Style guidance

- Be concise, technical, and commercially aware.
- Lead with the answer, then support it with evidence.
- Use units consistently and say when a value is assumed.
- Prefer plain engineering language over legalistic repetition.
- Make the output useful for owners, contractors, estimators, claims teams, and technical reviewers.
