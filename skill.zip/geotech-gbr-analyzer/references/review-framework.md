# GBR review framework

## 1. Separate the document roles

Use this framework whenever a source set includes a GBR and related geotechnical documents.

- **GBR**: contractual baseline that defines the foreseen conditions for bidding and differing-site-condition analysis.
- **GDR and logs**: factual data sources, not the contractual baseline unless the contract says otherwise.
- **Contract clauses and specs**: entitlement language, payment rules, measurement rules, and integration with the GBR.
- **Drawings and alignment data**: location, geometry, chainage, cover, interfaces, and sometimes construction staging.

Do not let descriptive logs or isolated data points silently replace an explicit baseline statement.

## 2. Evaluate the GBR through these lenses

### Clarity and measurability
Ask:
- Is the statement specific?
- Is it tied to a location, reach, chainage, or zone?
- Is there a measurable threshold or observable test during construction?
- Would two reasonable readers interpret it the same way?

### Risk allocation
Ask:
- Does the statement make it clear what is foreseen and what falls outside the baseline?
- Is the trigger for commercial relief observable and practical?
- Do the contract clauses support the stated allocation, or undermine it?

### Project specificity
Ask:
- Is the baseline tailored to this alignment, method, and sequence?
- Does it address the actual construction challenges of the project?
- Does it read like a copy-paste from another job?

### Separation from the GDR
Ask:
- Is the document relying on raw data or boring logs instead of making an explicit baseline statement?
- Are isolated data points being treated as the baseline without interpretation?

### Coverage of relevant ground behavior
Ask:
- Does the baseline cover soil, rock, groundwater, and behavior that matters to construction?
- Does it address transitions, variability, and adverse mechanisms that affect means and methods?

### Constructability linkage
Ask:
- Does the baseline say what matters to the chosen construction method?
- Are the statements meaningful for support class, face pressure, excavation stability, inflow, wear, settlement, or production?

### Internal consistency
Ask:
- Do the baseline text, drawings, logs, tables, and contract clauses agree?
- Are chainage ranges, units, and terminology consistent?

## 3. Common red flags

Treat these as warnings that a GBR may be claim-prone or hard to apply:

- vague words such as "variable," "occasional," "local," or "possible" without thresholds,
- no chainage or zone definition,
- no measurement rule for checking whether the baseline has been exceeded,
- optimistic baselines that ignore known adverse data,
- excessively pessimistic baselines that simply dump owner risk onto bidders,
- mixing raw data summaries with baseline language,
- failure to link groundwater behavior to the construction method,
- contradictory statements between narrative text and logs or tables,
- baselines that cannot realistically be monitored in the field,
- terms left undefined even though they affect entitlement.

## 4. Evidence tagging pattern

Format major findings in this order whenever practical:

**Finding** -> what the baseline says or fails to say.

**Why it matters** -> construction or commercial impact.

**Evidence** -> file, page, section, chainage, borehole, table, or cell range.

**Confidence** -> high, medium, or low, based on the source quality and consistency.

## 5. Rewrite vague baselines into measurable statements

Use these templates when suggesting improvements.

### Groundwater inflow
Instead of: "some groundwater inflow may occur"

Prefer: "for chainage [start] to [end], baseline steady-state inflow to the excavation or face is assumed not to exceed [threshold and units] over any [length or time window], excluding [defined exceptions]."

### Mixed-face conditions
Instead of: "mixed face may be encountered"

Prefer: "for chainage [start] to [end], baseline mixed-face conditions are assumed to affect up to [percentage] of the face over advance lengths of up to [distance], based on [supporting interpretation]."

### Obstructions, cobbles, or boulders
Instead of: "obstructions may be present"

Prefer: "within [zone], baseline obstructions include [size or type range] at a frequency not exceeding [rate per length, area, or volume]."

### Rock strength or abrasivity
Instead of: "hard abrasive rock is expected"

Prefer: "for chainage [start] to [end], baseline intact rock strength, abrasivity indicators, and expected variability are [state the relevant range and metric], with local excursions up to [defined limit] considered within baseline."

### Settlement or deformation sensitivity
Instead of: "sensitive structures exist nearby"

Prefer: "within [zone], baseline construction must account for adjacent assets at offsets of [range] with allowable movement criteria of [state criteria if contractually defined]."

Use placeholders when the source files do not support a specific number. Do not invent threshold values.
