# Construction contexts and risk lenses

Use this guide to keep the analysis aligned with the actual construction method. Do not over-focus on TBMs when the project is something else.

## Shield TBM in soft ground
Typical concerns:
- face stability,
- groundwater pressure and inflow,
- settlement and volume loss,
- mixed face,
- clogging or conditioning,
- cobbles and boulders,
- wear and interventions,
- ring-build and logistics constraints.

Baseline topics that matter:
- fines content, plasticity, and permeability,
- groundwater head and variability,
- mixed-face percentages by reach,
- obstruction frequency,
- settlement sensitivity of adjacent assets,
- conditioning assumptions.

## Hard-rock TBM
Typical concerns:
- UCS variability,
- jointing and blockiness,
- squeezing or overstress,
- faulted zones,
- water inflow,
- abrasivity and cutter wear,
- jamming or shield drag,
- utilization losses from maintenance or ground treatment.

Baseline topics that matter:
- rock-mass classes by reach,
- fault and shear zone frequency,
- abrasivity indicators,
- expected support needs,
- groundwater regime,
- convergence or deformation potential.

## NATM or SEM
Typical concerns:
- stand-up time,
- deformation and settlement,
- groundwater inflow,
- pre-support needs,
- support-class variability,
- portal or shallow-cover instability.

Baseline topics that matter:
- excavation classes,
- expected deformation levels,
- support timing,
- groundwater behavior,
- trigger zones and monitoring thresholds.

## Drill and blast tunnel
Typical concerns:
- overbreak,
- blast damage,
- vibration limits,
- water inflow,
- gas,
- support-class variability,
- unstable wedges or fault zones.

Baseline topics that matter:
- rock class distribution,
- discontinuity sets,
- groundwater expectations,
- support categories,
- restrictions near structures or utilities.

## Shafts and launch or reception structures
Typical concerns:
- wall leakage,
- groundwater cut-off performance,
- base heave,
- obstruction,
- sinking tolerance,
- adjacent-asset impacts.

Baseline topics that matter:
- permeability and head,
- obstruction frequency,
- soil strength and deformation,
- uplift risk,
- support and temporary works assumptions.

## HDD or microtunneling
Typical concerns:
- frac-out,
- stuck pipe,
- steering and alignment control,
- slurry losses,
- cobbles, boulders, or man-made obstruction,
- annular pressure management.

Baseline topics that matter:
- grain size and cobble content,
- strength and abrasivity,
- groundwater and permeability,
- alignment curvature,
- entry and exit constraints,
- slurry-loss potential.

## Cut-and-cover or deep excavation
Typical concerns:
- wall deflection,
- base heave,
- groundwater control,
- utility conflicts,
- adjacent-structure movements,
- staging effects.

Baseline topics that matter:
- soil profile and strength,
- groundwater regime,
- movement sensitivity,
- temporary support assumptions,
- interface with utilities and nearby foundations.

## Deep foundations or marine geotechnical works
Typical concerns:
- obstruction,
- karst or cavities,
- soft toe,
- slurry or drilling stability,
- seepage,
- concrete quality risks,
- scour or marine variability.

Baseline topics that matter:
- toe conditions,
- obstruction and cavity frequency,
- groundwater or tidal effects,
- drilling support assumptions,
- variability by location.

## Output reminder

For non-TBM projects, keep the report focused on the actual method. The best analysis explains which ground and groundwater behaviors matter most for that construction approach and why the baseline is or is not usable.
