# TBM estimation guide

Use this guide only for shield or hard-rock TBM projects. Treat all calculations as preliminary desk-level estimates derived from the uploaded information.

## 1. Confirm the machine family before estimating performance

Use the source files to infer the most likely TBM family.

### EPB
Most plausible when the project is in soft ground where a conditioned soil paste can support the face and control settlement.

Look for:
- urban settlement sensitivity,
- fine-grained or mixed soils with manageable permeability,
- screw conveyor spoil extraction,
- conditioning agents.

### Slurry shield
Most plausible when groundwater pressure, permeability, coarse ground, or large diameter make slurry support preferable.

Look for:
- high groundwater head,
- coarse sands or gravels,
- slurry circuit and separation plant,
- marine or river crossings,
- pressure-control emphasis.

### Open or gripper TBM
Most plausible in competent, stable rock where an open machine can bore without closed-face support.

Look for:
- stable rock masses,
- limited need for a full shield,
- rock support installed behind the cutterhead,
- gripper reaction against the rock.

### Single shield or double shield TBM
Most plausible in rock where lining or shield protection is needed.

Look for:
- segmental or immediate lining,
- fractured or variable rock,
- long tunnel drives,
- discussion of boring during ring build in double-shield contexts.

### Mixed-ground or hybrid arrangement
Most plausible when the alignment crosses repeated transitions between soil and rock or includes highly variable face conditions.

## 2. Check whether the source set is sufficient

Confidence increases when the source set includes most of the following:

- tunnel diameter,
- cover and profile,
- alignment by reach,
- geology and groundwater by reach,
- grain size or soil behavior for soft ground,
- UCS, rock-mass quality, and jointing for rock,
- abrasivity indicators,
- obstruction or boulder frequency,
- planned lining and ring length,
- stated TBM specs or similar precedent,
- logistics and utilization constraints.

If several of these are missing, give scenario ranges or a qualitative explanation instead of a single-number estimate.

## 3. Support pressure estimation for closed-face shield TBMs

Only estimate support pressure for EPB, slurry, or other closed-face machines.

### Working rule
Report a **pressure window** or **range**, not a single exact operating setpoint.

Explain the controlling factors:
- cover depth,
- groundwater head,
- soil unit weights,
- permeability,
- face stability,
- blowout or heave risk,
- settlement sensitivity,
- mixed-face effects.

### What to say
- identify the lower side of the range as the face-stability and inflow-control limit,
- identify the upper side of the range as the blowout, heave, or excess-settlement limit,
- note whether the evidence is adequate to quantify the window.

If the files do not contain enough information for a numeric window, explain qualitatively which factors push the pressure higher or lower.

Do not provide operational instructions or imply that the estimate replaces contractor procedures.

## 4. Penetration rate estimation

Use this mainly for hard-rock TBMs or for projects where machine and rock information are rich enough to support a quantitative estimate.

Relate penetration to:
- machine thrust and torque,
- cutter configuration,
- intact strength,
- brittleness,
- jointing and confinement,
- abrasivity and cutter wear,
- local faulted or squeezing zones.

Keep these distinctions clear:
- **instantaneous penetration** is not the same as daily advance,
- weak rock does not always mean faster progress if support or instability dominates,
- highly abrasive or blocky rock can lower production even when penetration looks acceptable.

If the data is thin, provide a scenario range with assumptions, or explain why a reliable estimate is not possible.

## 5. Advance rate estimation

Estimate advance rate only after considering the full production system.

Consider:
- penetration or cycle rate,
- utilization,
- ring-build time,
- ground treatment or interventions,
- maintenance and cutter changes,
- muck handling,
- segment supply,
- survey and logistics,
- restrictions near structures, shafts, or sensitive reaches.

Useful distinction:
- **penetration rate** describes boring performance,
- **advance rate** describes achieved project progress.

For shield TBMs, rings per day or meters per day may be more decision-useful than an abstract penetration figure.

## 6. Confidence labels

Use this scale:

- **High**: most critical geometric, ground, groundwater, and machine inputs are present and internally consistent.
- **Medium**: some important inputs are missing, but the remaining evidence supports a bounded estimate.
- **Low**: the source set is mostly narrative or incomplete; provide only broad ranges or qualitative guidance.

## 7. Recommended wording when data is weak

Use wording like:

- "the uploaded files support a qualitative machine-selection view, but not a defensible numeric advance-rate estimate because [missing inputs]."
- "a closed-face machine is likely required, but the support-pressure window cannot be narrowed confidently without [missing inputs]."
- "the estimate below is a desk-level scenario range, not an operating setpoint or guarantee of production."
