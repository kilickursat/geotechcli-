#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

def rj(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def rc(p):
    rows=[]
    with open(p, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            clean={}
            for k,v in row.items():
                v=v.strip()
                try:
                    clean[k]=float(v) if '.' in v else int(v)
                except Exception:
                    clean[k]=v
            rows.append(clean)
    return rows

def mean(vals):
    vals=[v for v in vals if isinstance(v,(int,float))]
    return sum(vals)/len(vals) if vals else 0

def write_outputs(out, handoff, report, artifact):
    out.mkdir(parents=True, exist_ok=True)
    (out/'swarm_handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    (out/'engineering_report.md').write_text(report, encoding='utf-8')
    (out/'case_file_artifact_map.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--output-dir', required=True)
    args=ap.parse_args()
    inp=Path(args.input_dir)
    out=Path(args.output_dir)
    gm=rj(inp/'ground_model.json')
    cfg=rj(inp/'tunnel_rock_config.json')
    mon=rc(inp/'monitoring.csv')

    rmr=gm.get('rmr',0); q=gm.get('q_value',0); gsi=gm.get('gsi',0)
    divergence='high' if (rmr>=50 and q<1) or (rmr<35 and q>=4) else 'moderate' if abs((rmr/20)-q)>2 else 'low'
    dominant='fair-to-poor conventional tunnelling ground' if divergence!='low' else 'fair conventional tunnelling ground'
    confidence=55 if divergence=='high' else 70 if divergence=='moderate' else 82
    handoff={'skill':'tunnel-classification-fusion','status':'review','dominant_classification':dominant,'divergence':divergence,'confidence_percent':confidence}
    report = '\n'.join([
        '# Tunnel Classification Fusion','',
        f'- Dominant class: {dominant}',
        f'- Divergence: {divergence}',
        f'- Confidence: {confidence}%',
        f'- RMR: {rmr}',
        f'- Q: {q}',
        f'- GSI: {gsi}',''
    ])
    artifact={'artifacts':[{'kind':'tunnel-classification-fusion','title':'classification fusion','path':'engineering_report.md'}]}
    write_outputs(out, handoff, report, artifact)


if __name__=='__main__':
    main()
