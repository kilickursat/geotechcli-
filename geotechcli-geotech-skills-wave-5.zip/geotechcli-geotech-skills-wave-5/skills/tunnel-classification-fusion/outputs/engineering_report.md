# Tunnel Classification Fusion

- Dominant class: fair conventional tunnelling ground
- Divergence: low
- Confidence: 82%
- RMR: 48
- Q: 2.4
- GSI: 42
