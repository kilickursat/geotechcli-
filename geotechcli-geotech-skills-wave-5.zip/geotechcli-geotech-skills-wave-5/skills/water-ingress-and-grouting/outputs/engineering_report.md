# Water Ingress And Grouting

- Severity: high
- Water head: 55 m
- Predicted inflow: 75 lpm/10 m
- Observed peak inflow: 96 lpm

## Screening strategy
- probe drilling and inflow confirmation ahead of face
- use staged probe drilling with pre-excavation grouting
- define stop-work trigger for sudden inflow escalation
