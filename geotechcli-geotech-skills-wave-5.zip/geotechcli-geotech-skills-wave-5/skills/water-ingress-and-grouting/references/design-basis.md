# Design basis

This skill is a production-oriented screening and review workflow for water ingress and grouting. Do not treat it as a substitute for project-specific numerical modelling, structural checks, or final code-governed design.
