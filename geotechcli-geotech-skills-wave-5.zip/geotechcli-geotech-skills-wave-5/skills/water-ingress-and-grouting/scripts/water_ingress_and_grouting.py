#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

def rj(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def rc(p):
    rows=[]
    with open(p, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            clean={}
            for k,v in row.items():
                v=v.strip()
                try:
                    clean[k]=float(v) if '.' in v else int(v)
                except Exception:
                    clean[k]=v
            rows.append(clean)
    return rows

def mean(vals):
    vals=[v for v in vals if isinstance(v,(int,float))]
    return sum(vals)/len(vals) if vals else 0

def write_outputs(out, handoff, report, artifact):
    out.mkdir(parents=True, exist_ok=True)
    (out/'swarm_handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    (out/'engineering_report.md').write_text(report, encoding='utf-8')
    (out/'case_file_artifact_map.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--output-dir', required=True)
    args=ap.parse_args()
    inp=Path(args.input_dir)
    out=Path(args.output_dir)
    gm=rj(inp/'ground_model.json')
    cfg=rj(inp/'tunnel_rock_config.json')
    mon=rc(inp/'monitoring.csv')

    head=cfg.get('water_head_m',0); inflow=cfg.get('predicted_inflow_lpm_per_10m',0); perm=gm.get('permeability_m_per_s',0); obs=max([r.get('inflow_lpm',0) for r in mon] or [0])
    severity='low'
    if head>30 or inflow>50 or obs>70: severity='moderate'
    if head>50 or inflow>80 or obs>90 or perm>1e-5: severity='high'
    strategy=['probe drilling and inflow confirmation ahead of face']
    if severity=='moderate': strategy += ['prepare local pre-excavation grouting','review drainage and pumping contingency']
    if severity=='high': strategy += ['use staged probe drilling with pre-excavation grouting','define stop-work trigger for sudden inflow escalation']
    handoff={'skill':'water-ingress-and-grouting','status':'warning' if severity=='high' else 'review','ingress_severity':severity,'observed_peak_inflow_lpm':obs,'strategy':strategy}
    report = '\n'.join(['# Water Ingress And Grouting','',f'- Severity: {severity}',f'- Water head: {head} m',f'- Predicted inflow: {inflow} lpm/10 m',f'- Observed peak inflow: {obs} lpm','','## Screening strategy',*([f'- {s}' for s in strategy]),''])
    artifact={'artifacts':[{'kind':'water-ingress-screening','title':'water ingress and grouting','path':'engineering_report.md'}]}
    write_outputs(out, handoff, report, artifact)


if __name__=='__main__':
    main()
