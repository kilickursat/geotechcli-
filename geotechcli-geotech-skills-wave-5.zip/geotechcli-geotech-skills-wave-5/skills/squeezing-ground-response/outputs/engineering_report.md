# Squeezing Ground Response

- Squeezing risk: moderate
- Average convergence: 24.7 mm
- Overburden: 210 m
- UCS: 28 MPa

## Recommended measures
- continue controlled monitoring
