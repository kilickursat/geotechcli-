#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

def rj(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def rc(p):
    rows=[]
    with open(p, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            clean={}
            for k,v in row.items():
                v=v.strip()
                try:
                    clean[k]=float(v) if '.' in v else int(v)
                except Exception:
                    clean[k]=v
            rows.append(clean)
    return rows

def mean(vals):
    vals=[v for v in vals if isinstance(v,(int,float))]
    return sum(vals)/len(vals) if vals else 0

def write_outputs(out, handoff, report, artifact):
    out.mkdir(parents=True, exist_ok=True)
    (out/'swarm_handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    (out/'engineering_report.md').write_text(report, encoding='utf-8')
    (out/'case_file_artifact_map.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--output-dir', required=True)
    args=ap.parse_args()
    inp=Path(args.input_dir)
    out=Path(args.output_dir)
    gm=rj(inp/'ground_model.json')
    cfg=rj(inp/'tunnel_rock_config.json')
    mon=rc(inp/'monitoring.csv')

    ucs=gm.get('ucs_mpa',0); gsi=gm.get('gsi',0); over=cfg.get('overburden_m',0); conv=mean([r.get('wall_convergence_mm',0) for r in mon])
    index=(1 if ucs<25 else 0)+(1 if gsi<40 else 0)+(1 if over>200 else 0)+(1 if conv>25 else 0)
    risk=['low','moderate','high','very-high'][min(index,3)]
    measures=['reduce advance step and bench lag','close invert earlier','consider yielding support'] if risk in {'high','very-high'} else ['continue controlled monitoring']
    handoff={'skill':'squeezing-ground-response','status':'warning' if risk in {'high','very-high'} else 'review','squeezing_risk':risk,'average_convergence_mm':round(conv,1),'recommended_measures':measures}
    report = '\n'.join(['# Squeezing Ground Response','',f'- Squeezing risk: {risk}',f'- Average convergence: {conv:.1f} mm',f'- Overburden: {over} m',f'- UCS: {ucs} MPa','','## Recommended measures',*([f'- {m}' for m in measures]),''])
    artifact={'artifacts':[{'kind':'squeezing-ground-screening','title':'squeezing response','path':'engineering_report.md'}]}
    write_outputs(out, handoff, report, artifact)


if __name__=='__main__':
    main()
