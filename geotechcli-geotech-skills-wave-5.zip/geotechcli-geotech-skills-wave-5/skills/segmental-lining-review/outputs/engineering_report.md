# Segmental Lining Review

- Status: warning
- Observed maximum joint opening: 6.5 mm
- Review limit: 6 mm
- Build quality: fair
- Visible cracks: 1

## Issues
- joint opening exceeds nominal review limit

## Actions
- continue ring-by-ring visual and dimensional review
- review gasket seating and bolt tightening record
- check ring build quality and local leakage observations
