#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

def rj(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def rc(p):
    rows=[]
    with open(p, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            clean={}
            for k,v in row.items():
                v=v.strip()
                try:
                    clean[k]=float(v) if '.' in v else int(v)
                except Exception:
                    clean[k]=v
            rows.append(clean)
    return rows

def mean(vals):
    vals=[v for v in vals if isinstance(v,(int,float))]
    return sum(vals)/len(vals) if vals else 0

def write_outputs(out, handoff, report, artifact):
    out.mkdir(parents=True, exist_ok=True)
    (out/'swarm_handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    (out/'engineering_report.md').write_text(report, encoding='utf-8')
    (out/'case_file_artifact_map.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--output-dir', required=True)
    args=ap.parse_args()
    inp=Path(args.input_dir)
    out=Path(args.output_dir)
    gm=rj(inp/'ground_model.json')
    cfg=rj(inp/'tunnel_rock_config.json')
    mon=rc(inp/'monitoring.csv')

    seg=cfg.get('segmental_lining',{}); limit=seg.get('joint_opening_limit_mm',6); observed=max([r.get('segment_joint_opening_mm',0) for r in mon] or [0]); cracks=seg.get('observed_cracks',0); quality=seg.get('build_quality','unknown'); head=cfg.get('water_head_m',0); dhead=seg.get('water_head_design_m',0)
    status='acceptable'; issues=[]
    if observed>limit: status='warning'; issues.append('joint opening exceeds nominal review limit')
    if cracks>=2 or quality=='poor': status='warning'; issues.append('build quality or visible cracking requires closer review')
    if head>dhead: status='hold-point'; issues.append('water head exceeds nominal design review value')
    actions=['continue ring-by-ring visual and dimensional review']
    if status!='acceptable': actions += ['review gasket seating and bolt tightening record','check ring build quality and local leakage observations']
    handoff={'skill':'segmental-lining-review','status':status,'observed_joint_opening_mm':observed,'issues':issues,'actions':actions}
    issues_lines = [f'- {i}' for i in issues] if issues else ['- no critical review issues in the example run']
    report = '\n'.join(['# Segmental Lining Review','',f'- Status: {status}',f'- Observed maximum joint opening: {observed:.1f} mm',f'- Review limit: {limit} mm',f'- Build quality: {quality}',f'- Visible cracks: {cracks}','', '## Issues', *issues_lines, '', '## Actions', *([f'- {a}' for a in actions]), ''])
    artifact={'artifacts':[{'kind':'segmental-lining-review','title':'segmental lining review','path':'engineering_report.md'}]}
    write_outputs(out, handoff, report, artifact)


if __name__=='__main__':
    main()
