# Rockburst Screening

- Rockburst risk: very-high
- Stress to UCS ratio: 0.64
- Brittleness index: 0.58
- Spalling observed: yes

## Actions
- maintain mapping of fresh stress damage
- review destress strategy
- tighten exclusion and support installation controls
