#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

def rj(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def rc(p):
    rows=[]
    with open(p, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            clean={}
            for k,v in row.items():
                v=v.strip()
                try:
                    clean[k]=float(v) if '.' in v else int(v)
                except Exception:
                    clean[k]=v
            rows.append(clean)
    return rows

def mean(vals):
    vals=[v for v in vals if isinstance(v,(int,float))]
    return sum(vals)/len(vals) if vals else 0

def write_outputs(out, handoff, report, artifact):
    out.mkdir(parents=True, exist_ok=True)
    (out/'swarm_handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    (out/'engineering_report.md').write_text(report, encoding='utf-8')
    (out/'case_file_artifact_map.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--output-dir', required=True)
    args=ap.parse_args()
    inp=Path(args.input_dir)
    out=Path(args.output_dir)
    gm=rj(inp/'ground_model.json')
    cfg=rj(inp/'tunnel_rock_config.json')
    mon=rc(inp/'monitoring.csv')

    ucs=max(gm.get('ucs_mpa',1),1); sigma1=cfg.get('in_situ_sigma1_mpa',0); brittleness=cfg.get('brittleness_index',0); spall=max([r.get('spalling_flag',0) for r in mon] or [0]); ratio=sigma1/ucs
    risk='low' if ratio<0.25 and brittleness<0.5 and not spall else 'moderate' if ratio<0.4 else 'high' if ratio<0.6 else 'very-high'
    if spall and risk=='moderate': risk='high'
    actions=['maintain mapping of fresh stress damage']
    if risk in {'high','very-high'}: actions += ['review destress strategy','tighten exclusion and support installation controls']
    handoff={'skill':'rockburst-screening','status':'warning' if risk in {'high','very-high'} else 'review','rockburst_risk':risk,'stress_to_strength_ratio':round(ratio,2),'actions':actions}
    report = '\n'.join(['# Rockburst Screening','',f'- Rockburst risk: {risk}',f'- Stress to UCS ratio: {ratio:.2f}',f'- Brittleness index: {brittleness}',f"- Spalling observed: {'yes' if spall else 'no'}",'', '## Actions', *([f'- {a}' for a in actions]), ''])
    artifact={'artifacts':[{'kind':'rockburst-screening','title':'rockburst screening','path':'engineering_report.md'}]}
    write_outputs(out, handoff, report, artifact)


if __name__=='__main__':
    main()
