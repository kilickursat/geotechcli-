# Wave 5 TODO

Promote the strongest evaluators into geotechCLI core, register tools, add guardrails, expose swarm access, and add tests.
