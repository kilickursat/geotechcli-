# geotechCLI geotechnical skills - wave 5

This workspace contains the Wave 5 standalone skill bundle for conventional tunnelling, rock engineering, water ingress, deformation response, and segmental lining review.
