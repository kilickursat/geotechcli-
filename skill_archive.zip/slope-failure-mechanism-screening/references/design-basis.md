# Universal design basis

Use a universal, non-country-specific framing.

- Slopes and embankments: Bishop or Janbu-style screening logic, staged construction review, rainfall and drawdown escalation, and observational method trigger management
- Consolidation and preload: surcharge, pvd, and vacuum acceleration concepts using screening-level settlement and degree-of-consolidation checks
- Ground improvement: vibro replacement, deep soil mixing, jet grouting, permeation grouting, compaction grouting, preload, and vacuum consolidation suitability screening
- QA and review: explicit acceptance checks, missing-data notes, and conservative warnings when treatment performance is not yet evidenced

This bundle is intended for production-oriented screening, option comparison, audit, and observational control. It should clearly state when a specialist numerical model, laboratory validation, field trial, or project-specific code check is still required.
