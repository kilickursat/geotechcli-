# Repo integration guidance

When promoting any of these standalone skills into geotechCLI itself, follow the repo contribution pattern.

1. Add the deterministic logic under `packages/core/src/geo/`.
2. Register matching tools in `packages/core/src/agents/tools.ts`.
3. Add guardrails in `packages/core/src/agents/guardrails.ts`.
4. Add swarm allowlist access in `packages/core/src/agents/swarm.ts`.
5. Add tests in `packages/core/tests/`.
6. Add or extend CLI commands under `packages/cli/src/commands/` when the workflow deserves a direct surface.
7. Persist reusable outputs into project memory and case-file artifacts instead of creating a separate state layer.

The current repo already includes slope stability, consolidation and settlement, retaining, seepage, project memory, deliverable tools, and case-file persistence, so new Wave 4 logic should extend those areas rather than duplicate them.
