# Input contract

This Wave 4 bundle uses a universal local-file contract for slopes, embankments, and ground improvement.

Default files under `assets/example-inputs/`:

- `ground_model.json`
  - shared baseline ground model
  - strata, groundwater depth, strength and stiffness placeholders, permeability, fines, and particle-size hints where relevant

- `slope_scheme.json`
  - slope geometry, surcharge, groundwater and rainfall thresholds, drawdown triggers, and instrumentation limits

- `embankment_scheme.json`
  - staged fill heights, hold durations, preload surcharge, pvd spacing, and consolidation objectives

- `ground_improvement_scheme.json`
  - treatment depth, performance objective, target strengths, stone-column spacing and diameter, binder targets, groutability hints, vacuum and preload parameters

- `monitoring.csv`
  - rainfall, drawdown, pore-pressure or piezometer change, inclinometer movement, crest settlement, toe movement, crack width, consolidation progress, and qa/qc indicators

Not every skill uses every file. The standalone script must tolerate unused files and only consume what is relevant to the current mode.
