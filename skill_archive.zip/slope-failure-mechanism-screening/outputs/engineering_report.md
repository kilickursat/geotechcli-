# Slope Failure Mechanism Screening

## Summary
Screen likely slope failure mechanisms using geometry, groundwater, rainfall sensitivity, and stratigraphic contrasts.

## Key metrics
- likely mechanism: deep_rotational
- mechanism confidence percent: 82
- governing stratum: Soft high plasticity clay
- strength contrast ratio: 1.51
- slope height m: 18.0
- slope angle deg: 34.0
- groundwater depth m: 2.5

## Engineering workflow
- screen geometry, groundwater, rainfall sensitivity, and stratigraphic contrast.
- likely screened mechanism: deep rotational.
- treat the mechanism call as a workflow decision aid, not a substitute for formal stability modelling.

## Warnings
- recent rainfall exceeds the screening 72h trigger and may alter the likely mechanism.
- groundwater is shallow relative to the slope height and should be included explicitly in formal checks.
