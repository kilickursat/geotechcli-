#!/usr/bin/env python3
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path

PROFILE_PATH = Path(__file__).resolve().parent.parent / 'references' / 'skill-profile.json'
PROFILE = json.loads(PROFILE_PATH.read_text())


def load_json(path: Path):
    return json.loads(path.read_text())


def load_csv(path: Path):
    rows = []
    if not path.exists():
        return rows
    with path.open('r', encoding='utf-8', newline='') as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            clean = {}
            for key, value in row.items():
                value = '' if value is None else value.strip()
                try:
                    clean[key] = '' if value == '' else float(value)
                except ValueError:
                    clean[key] = value
            rows.append(clean)
    return rows


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def tan_deg(value: float) -> float:
    return math.tan(math.radians(value))


def strength_index(stratum):
    phi = float(stratum.get('phi_deg', 25.0))
    su = float(stratum.get('su_kpa', 0.0))
    es = float(stratum.get('Es_mpa', 10.0))
    return phi + su / 6.0 + es / 3.0


def select_stratum(strata, depth: float):
    for stratum in strata:
        if float(stratum['from_m']) <= depth <= float(stratum['to_m']):
            return stratum
    if strata:
        return strata[-1]
    raise ValueError('no strata available')


def weakest_stratum(strata, max_depth: float):
    candidates = [s for s in strata if float(s['from_m']) < max_depth]
    if not candidates:
        return select_stratum(strata, max_depth / 2.0)
    return min(candidates, key=strength_index)


def latest_row(rows):
    return rows[-1] if rows else {}


def screened_slope_fos(ground_model, slope_scheme):
    H = float(slope_scheme.get('slope_height_m', 12.0))
    beta_deg = float(slope_scheme.get('slope_angle_deg', 30.0))
    beta = math.radians(max(beta_deg, 1.0))
    surcharge = float(slope_scheme.get('crest_surcharge_kPa', 0.0))
    kh = float(slope_scheme.get('seismic_coefficient', 0.0))
    gw = float(slope_scheme.get('water_table_depth_m', ground_model.get('groundwater', {}).get('depth_m', 99.0)))
    stratum = weakest_stratum(ground_model['strata'], max(H, 1.0))
    gamma = float(stratum.get('unit_weight_kn_m3', 18.0))
    phi = float(stratum.get('phi_deg', 24.0))
    su = float(stratum.get('su_kpa', 20.0))
    cohesion = max(float(stratum.get('cohesion_kPa', 0.0)), 0.2 * su)
    water_factor = 1.0 if gw > H else 0.72 if gw > H / 2.0 else 0.55
    seismic_factor = 1.0 + 2.0 * kh
    surcharge_factor = 1.0 + surcharge / max(gamma * H, 1.0)
    driving = gamma * H * math.sin(beta) * math.cos(beta) * surcharge_factor * seismic_factor
    resisting = cohesion + gamma * H * (math.cos(beta) ** 2) * water_factor * tan_deg(phi)
    fos = resisting / max(driving, 1.0)
    return {
        'governing_stratum': stratum.get('material', 'unknown'),
        'phi_deg': round(phi, 1),
        'screened_cohesion_kPa': round(cohesion, 1),
        'governing_screened_fos': round(fos, 2),
        'water_factor': round(water_factor, 2),
        'seismic_factor': round(seismic_factor, 2),
        'surcharge_factor': round(surcharge_factor, 2),
    }


def slope_mechanism(ground_model, slope_scheme, monitoring_rows):
    H = float(slope_scheme.get('slope_height_m', 12.0))
    beta = float(slope_scheme.get('slope_angle_deg', 30.0))
    gw = float(slope_scheme.get('water_table_depth_m', ground_model.get('groundwater', {}).get('depth_m', 99.0)))
    rain72 = float(latest_row(monitoring_rows).get('rainfall_72h_mm', 0.0))
    weak = weakest_stratum(ground_model['strata'], max(H, 1.0))
    strong = max(ground_model['strata'], key=strength_index)
    contrast = clamp(strength_index(strong) / max(strength_index(weak), 1.0), 1.0, 4.5)
    if gw <= H / 2.0 and beta >= 30 and float(weak.get('su_kpa', 0.0)) < 35:
        mechanism = 'deep_rotational'
        confidence = 82
    elif float(weak.get('permeability_m_s', 1e-7)) > 1e-5 and gw <= H and rain72 > 120:
        mechanism = 'seepage_or_surface_erosion'
        confidence = 74
    elif contrast > 2.1 and beta > 36:
        mechanism = 'compound_or_translational'
        confidence = 71
    else:
        mechanism = 'global_circular_screened_case'
        confidence = 65
    warnings = []
    if rain72 > float(slope_scheme.get('rainfall_trigger_72h_mm', 140.0)):
        warnings.append('recent rainfall exceeds the screening 72h trigger and may alter the likely mechanism.')
    if gw <= H / 2.0:
        warnings.append('groundwater is shallow relative to the slope height and should be included explicitly in formal checks.')
    metrics = {
        'likely_mechanism': mechanism,
        'mechanism_confidence_percent': confidence,
        'governing_stratum': weak.get('material', 'unknown'),
        'strength_contrast_ratio': round(contrast, 2),
        'slope_height_m': round(H, 2),
        'slope_angle_deg': round(beta, 1),
        'groundwater_depth_m': round(gw, 2),
    }
    steps = [
        'screen geometry, groundwater, rainfall sensitivity, and stratigraphic contrast.',
        f"likely screened mechanism: {mechanism.replace('_', ' ')}.",
        'treat the mechanism call as a workflow decision aid, not a substitute for formal stability modelling.',
    ]
    return metrics, warnings, steps


def slope_review(ground_model, slope_scheme):
    fos = screened_slope_fos(ground_model, slope_scheme)
    beta = float(slope_scheme.get('slope_angle_deg', 30.0))
    H = float(slope_scheme.get('slope_height_m', 12.0))
    gw = float(slope_scheme.get('water_table_depth_m', ground_model.get('groundwater', {}).get('depth_m', 99.0)))
    value = fos['governing_screened_fos']
    if value >= 1.35:
        status = 'acceptable'
    elif value >= 1.15:
        status = 'marginal'
    else:
        status = 'poor'
    remedies = []
    if gw <= H / 2.0:
        remedies.append('improve crest and sub-surface drainage before committing to geometry changes.')
    if beta > 34:
        remedies.append('flatten the slope or add benching to reduce the driving component.')
    if value < 1.15 and H > 10:
        remedies.append('consider a toe berm, buttress fill, or structural reinforcement.')
    if not remedies:
        remedies.append('maintain routine monitoring and confirm the screening assumptions with project-specific checks.')
    metrics = {
        **fos,
        'stability_status': status,
        'primary_remediation': remedies[0],
        'recommended_remedies': remedies,
    }
    warnings = []
    if status != 'acceptable':
        warnings.append('screened factor of safety is not comfortably above a preliminary service margin.')
    if gw <= H / 2.0:
        warnings.append('water control is likely to be a major driver of remediation choice.')
    steps = [
        'screen the governing factor of safety using a simplified slope review relationship.',
        f"classify the preliminary stability state as {status}.",
        'recommend drainage, geometry, or reinforcement as follow-on actions rather than treating the screening result as final design.',
    ]
    return metrics, warnings, steps


def rainfall_drawdown_review(slope_scheme, monitoring_rows):
    latest = latest_row(monitoring_rows)
    rain24 = float(latest.get('rainfall_24h_mm', 0.0))
    rain72 = float(latest.get('rainfall_72h_mm', 0.0))
    drawdown = float(latest.get('drawdown_m', 0.0))
    incl = float(latest.get('inclinometer_mm', 0.0))
    rain24_lim = float(slope_scheme.get('rainfall_trigger_24h_mm', 70.0))
    rain72_lim = float(slope_scheme.get('rainfall_trigger_72h_mm', 140.0))
    draw_lim = float(slope_scheme.get('drawdown_trigger_m', 2.5))
    incl_lim = float(slope_scheme.get('inclinometer_trigger_mm', 15.0))
    ratios = {
        'rainfall_24h_ratio': round(rain24 / max(rain24_lim, 1.0), 2),
        'rainfall_72h_ratio': round(rain72 / max(rain72_lim, 1.0), 2),
        'drawdown_ratio': round(drawdown / max(draw_lim, 0.1), 2),
        'inclinometer_ratio': round(incl / max(incl_lim, 0.1), 2),
    }
    max_ratio = max(ratios.values())
    if max_ratio >= 1.2:
        state = 'red'
        action = 'hold work, inspect drainage and pore-pressure state, and escalate geotechnical review.'
    elif max_ratio >= 0.9:
        state = 'amber'
        action = 'increase inspection and monitoring frequency and review work sequencing before proceeding.'
    else:
        state = 'green'
        action = 'continue with routine review and standard monitoring.'
    warnings = [] if state == 'green' else [f'trigger state is {state} and requires explicit action.']
    metrics = {
        **ratios,
        'overall_trigger_state': state,
        'recommended_action': action,
        'governing_ratio': round(max_ratio, 2),
    }
    steps = [
        'compare rainfall, drawdown, and movement against predefined trigger limits.',
        f"overall trigger state: {state}.",
        'treat the result as an observational-method control output, not a design capacity calculation.',
    ]
    return metrics, warnings, steps


def embankment_stage_review(ground_model, embankment_scheme):
    stages = [float(v) for v in embankment_scheme.get('construction_stages_m', [])]
    holds = [float(v) for v in embankment_scheme.get('stage_hold_days', [])]
    if not stages:
        stages = [float(embankment_scheme.get('embankment_height_m', 5.0))]
    foundation = weakest_stratum(ground_model['strata'], float(embankment_scheme.get('foundation_soft_clay_thickness_m', 6.0)))
    su0 = max(float(foundation.get('su_kpa', 20.0)), 5.0)
    gamma_fill = 19.0
    surcharge = float(embankment_scheme.get('design_surcharge_kPa', 0.0))
    cc = max(float(foundation.get('Cc', 0.2)), 0.05)
    e0 = max(float(foundation.get('e0', 0.9)), 0.2)
    thickness = float(embankment_scheme.get('foundation_soft_clay_thickness_m', max(float(foundation.get('to_m', 6.0)) - float(foundation.get('from_m', 0.0)), 1.0)))
    sigma0 = 80.0
    cumulative_hold = 0.0
    stage_records = []
    governing = 99.0
    cumulative_settlement = 0.0
    for index, stage_height in enumerate(stages, start=1):
        hold = holds[index - 1] if index - 1 < len(holds) else holds[-1] if holds else 14.0
        cumulative_hold += max(hold, 0.0)
        su = su0 * (1.0 + 0.12 * math.log1p(cumulative_hold))
        stress = gamma_fill * stage_height + surcharge
        fos = 5.14 * su / max(stress, 1.0)
        settlement = cc / (1.0 + e0) * thickness * math.log10((sigma0 + stress) / sigma0) * 1000.0
        cumulative_settlement = max(cumulative_settlement, settlement)
        status = 'pass' if fos >= 1.35 else 'warning' if fos >= 1.15 else 'hold'
        stage_records.append({
            'stage': index,
            'height_m': round(stage_height, 2),
            'hold_days': round(hold, 1),
            'screened_fos': round(fos, 2),
            'predicted_total_settlement_mm': round(settlement, 1),
            'status': status,
        })
        governing = min(governing, fos)
    overall = 'hold' if any(r['status'] == 'hold' for r in stage_records) else 'warning' if any(r['status'] == 'warning' for r in stage_records) else 'pass'
    warnings = [f"stage {r['stage']} is in hold status at screening level." for r in stage_records if r['status'] == 'hold']
    metrics = {
        'governing_stage_fos': round(governing, 2),
        'maximum_stage_settlement_mm': round(cumulative_settlement, 1),
        'overall_stage_status': overall,
        'stage_register': stage_records,
    }
    steps = [
        'review each embankment stage against short-term undrained stability and settlement growth.',
        f"overall staged construction status: {overall}.",
        'use the result to place hold points or preload continuation in the construction sequence.',
    ]
    return metrics, warnings, steps


def preload_control(ground_model, embankment_scheme, monitoring_rows):
    foundation = weakest_stratum(ground_model['strata'], float(embankment_scheme.get('foundation_soft_clay_thickness_m', 6.0)))
    cc = max(float(foundation.get('Cc', 0.25)), 0.05)
    e0 = max(float(foundation.get('e0', 1.0)), 0.2)
    thickness = float(embankment_scheme.get('foundation_soft_clay_thickness_m', max(float(foundation.get('to_m', 6.0)) - float(foundation.get('from_m', 0.0)), 1.0)))
    cv = max(float(foundation.get('Cv_m2_day', 0.18)), 0.01)
    preload_h = float(embankment_scheme.get('preload_surcharge_height_m', 1.0))
    vacuum = float(embankment_scheme.get('vacuum_equivalent_surcharge_kPa', 0.0))
    spacing = max(float(embankment_scheme.get('pvd_spacing_m', 1.5)), 0.5)
    target_u = clamp(float(embankment_scheme.get('target_degree_of_consolidation_pct', 90.0)) / 100.0, 0.5, 0.98)
    delta_sigma = preload_h * 18.0 + vacuum
    sigma0 = 80.0
    predicted = cc / (1.0 + e0) * thickness * math.log10((sigma0 + delta_sigma) / sigma0) * 1000.0
    de = 1.05 * spacing
    time_with_drains = (de ** 2 / cv) * max(math.log(1.0 / (1.0 - target_u)) / 8.0, 0.1)
    time_without_drains = (thickness ** 2 / cv) * max(math.log(1.0 / (1.0 - target_u)) / 2.0, 0.3)
    latest_u = float(latest_row(monitoring_rows).get('degree_of_consolidation_pct', 0.0))
    if latest_u >= target_u * 100.0:
        action = 'check settlement rate and confirm preload removal readiness.'
    elif latest_u >= target_u * 80.0:
        action = 'continue preload and maintain monitoring until the target degree of consolidation is reached.'
    else:
        action = 'maintain preload and review drain performance, surcharge duration, or vacuum level.'
    warnings = []
    if time_with_drains > 180:
        warnings.append('screened time to target consolidation is long and may challenge the project schedule.')
    metrics = {
        'predicted_preload_settlement_mm': round(predicted, 1),
        'estimated_time_to_target_u_days': round(time_with_drains, 1),
        'baseline_time_without_drains_days': round(time_without_drains, 1),
        'observed_degree_of_consolidation_pct': round(latest_u, 1),
        'predicted_target_time_days': round(time_with_drains, 1),
        'recommended_action': action,
    }
    steps = [
        'estimate preload settlement and accelerated time to the target degree of consolidation.',
        'compare observed consolidation progress against the target.',
        f"recommended preload control action: {action}",
    ]
    return metrics, warnings, steps


def slope_instrumentation(monitoring_rows, slope_scheme):
    latest = latest_row(monitoring_rows)
    crest = float(latest.get('crest_settlement_mm', 0.0))
    toe = float(latest.get('toe_movement_mm', 0.0))
    crack = float(latest.get('crack_width_mm', 0.0))
    piezo = float(latest.get('piezometric_rise_m', 0.0))
    incl = float(latest.get('inclinometer_mm', 0.0))
    limits = {
        'crest': max(float(slope_scheme.get('crest_settlement_trigger_mm', 25.0)), 1.0),
        'toe': max(float(slope_scheme.get('toe_movement_trigger_mm', 12.0)), 1.0),
        'crack': max(float(slope_scheme.get('crack_trigger_mm', 5.0)), 0.5),
        'piezo': max(float(slope_scheme.get('piezometer_trigger_m', 1.5)), 0.1),
        'incl': max(float(slope_scheme.get('inclinometer_trigger_mm', 15.0)), 1.0),
    }
    ratios = {
        'crest_settlement_ratio': round(crest / limits['crest'], 2),
        'toe_movement_ratio': round(toe / limits['toe'], 2),
        'crack_ratio': round(crack / limits['crack'], 2),
        'piezometer_ratio': round(piezo / limits['piezo'], 2),
        'inclinometer_ratio': round(incl / limits['incl'], 2),
    }
    max_ratio = max(ratios.values())
    if max_ratio >= 1.2:
        state = 'red'
        action = 'stop the next work step, inspect the slope, and execute the response plan.'
    elif max_ratio >= 0.9:
        state = 'amber'
        action = 'increase monitoring frequency and review the geometry, drainage, and sequence before continuing.'
    else:
        state = 'green'
        action = 'continue routine monitoring.'
    warnings = [] if state == 'green' else [f'instrumentation trigger state is {state}.']
    metrics = {
        **ratios,
        'overall_trigger_state': state,
        'recommended_action': action,
        'governing_ratio': round(max_ratio, 2),
    }
    steps = [
        'compare instrumentation movements and pore-pressure response to trigger limits.',
        f"overall trigger state: {state}.",
        'treat the result as a field decision aid for the observational method.',
    ]
    return metrics, warnings, steps


def ground_improvement_scores(ground_model, scheme):
    weak = weakest_stratum(ground_model['strata'], float(scheme.get('improvement_depth_m', 8.0)))
    fines = float(weak.get('fines_percent', 35.0))
    phi = float(weak.get('phi_deg', 25.0))
    su = float(weak.get('su_kpa', 20.0))
    k = float(weak.get('permeability_m_s', 1e-7))
    depth = float(scheme.get('improvement_depth_m', 8.0))
    objective = str(scheme.get('performance_objective', 'settlement_reduction')).lower()
    settlement_objective = 'settlement' in objective
    strength_objective = 'strength' in objective or float(scheme.get('target_su_kPa', 0.0)) > su + 10
    scores = {
        'stone_columns': 25 + (20 if fines <= 20 else 5) + (15 if depth <= 15 else 0) + (15 if settlement_objective else 0),
        'dsm': 30 + (25 if fines >= 25 else 10) + (20 if strength_objective else 5) + (10 if depth <= 20 else 0),
        'jet_grouting': 28 + (18 if depth <= 18 else 10) + (15 if strength_objective else 8) + (12 if ground_model.get('groundwater', {}).get('depth_m', 99.0) <= depth else 5),
        'preload_pvd': 26 + (25 if fines >= 40 else 10) + (18 if settlement_objective else 6) + (12 if depth <= 12 else 5),
        'permeation_grouting': 22 + (25 if fines <= 15 else 0) + (20 if k >= 1e-5 else 0) + (10 if not strength_objective else 4),
        'compaction_grouting': 18 + (18 if phi >= 30 and fines <= 25 else 5) + (12 if settlement_objective else 8) + (10 if depth <= 10 else 4),
    }
    return {k: int(clamp(v, 0, 100)) for k, v in scores.items()}


def gi_option_screen(ground_model, scheme):
    scores = ground_improvement_scores(ground_model, scheme)
    ranking = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    preferred, preferred_score = ranking[0]
    shortlist = [{'option': name, 'score': score} for name, score in ranking]
    warnings = []
    if preferred_score < 55:
        warnings.append('no single ground improvement option is strongly supported by the screening inputs.')
    metrics = {
        'preferred_option': preferred,
        'preferred_option_score': preferred_score,
        'option_shortlist': shortlist,
    }
    steps = [
        'screen broad ground improvement families against soil type, depth, groundwater, and objective.',
        f"preferred option after screening: {preferred.replace('_', ' ')}.",
        'keep at least one alternative alive when the score spread is narrow or warning-heavy.',
    ]
    return metrics, warnings, steps


def stone_columns(ground_model, scheme):
    weak = weakest_stratum(ground_model['strata'], float(scheme.get('improvement_depth_m', 8.0)))
    d = float(scheme.get('column_diameter_m', 0.8))
    s = float(scheme.get('column_spacing_m', 2.2))
    fines = float(weak.get('fines_percent', 35.0))
    depth = float(scheme.get('improvement_depth_m', 8.0))
    area_ratio = 0.907 * math.pi * (d ** 2) / 4.0 / max(s ** 2, 0.1)
    settlement_reduction = 1.0 / (1.0 + 2.6 * area_ratio)
    bearing_factor = 1.0 + 3.5 * area_ratio
    if fines <= 20 and depth <= 15:
        suitability = 'good'
    elif fines <= 30:
        suitability = 'conditional'
    else:
        suitability = 'poor'
    warnings = []
    if fines > 25:
        warnings.append('high fines content weakens vibro replacement efficiency and stone-column constructability.')
    if depth > 15:
        warnings.append('improvement depth is beyond the most comfortable range for a simple screening assumption.')
    metrics = {
        'area_replacement_ratio': round(area_ratio, 3),
        'screened_settlement_reduction_factor': round(settlement_reduction, 2),
        'screened_bearing_improvement_factor': round(bearing_factor, 2),
        'suitability': suitability,
        'governing_fines_percent': round(fines, 1),
    }
    steps = [
        'estimate area replacement ratio from column spacing and diameter.',
        'screen settlement reduction and bearing improvement at conceptual level.',
        f"stone-column suitability: {suitability}.",
    ]
    return metrics, warnings, steps


def dsm_jet(ground_model, scheme):
    weak = weakest_stratum(ground_model['strata'], float(scheme.get('improvement_depth_m', 8.0)))
    fines = float(weak.get('fines_percent', 35.0))
    depth = float(scheme.get('improvement_depth_m', 8.0))
    target_su = float(scheme.get('target_su_kPa', 55.0))
    current_su = max(float(weak.get('su_kpa', 20.0)), 5.0)
    strength_ratio = target_su / current_su
    dsm_score = 65 + (15 if fines >= 25 else 0) + (8 if depth <= 20 else 0)
    jet_score = 60 + (12 if depth <= 18 else 0) + (10 if ground_model.get('groundwater', {}).get('depth_m', 99.0) <= depth else 0) + (8 if strength_ratio > 2.0 else 0)
    recommended = 'deep_soil_mixing' if dsm_score >= jet_score else 'jet_grouting'
    warnings = []
    if strength_ratio > 3.5:
        warnings.append('required strength gain is high and should be validated with mix trials or treatment trials.')
    metrics = {
        'recommended_method': recommended,
        'screened_strength_gain_ratio': round(strength_ratio, 2),
        'indicative_dsm_binder_kg_m3': round(float(scheme.get('binder_content_kg_m3', 250.0)), 1),
        'indicative_jet_grout_column_diameter_m': round(clamp(1.0 + depth / 30.0, 1.0, 1.8), 2),
        'dsm_score': int(clamp(dsm_score, 0, 100)),
        'jet_grouting_score': int(clamp(jet_score, 0, 100)),
    }
    steps = [
        'compare dsm and jet grouting against soil type, depth, groundwater, and strength objective.',
        f"recommended method after screening: {recommended.replace('_', ' ')}.",
        'leave detailed mix design, spoil handling, and production trials to the project-specific phase.',
    ]
    return metrics, warnings, steps


def vacuum_preload(ground_model, scheme, monitoring_rows):
    weak = weakest_stratum(ground_model['strata'], float(scheme.get('improvement_depth_m', 8.0)))
    fines = float(weak.get('fines_percent', 35.0))
    cv = max(float(weak.get('Cv_m2_day', 0.18)), 0.01)
    thickness = max(float(scheme.get('improvement_depth_m', 8.0)), 1.0)
    preload_h = float(scheme.get('preload_surcharge_height_m', 1.0))
    vacuum = float(scheme.get('vacuum_target_kPa', 80.0))
    spacing = max(float(scheme.get('pvd_spacing_m', 1.5)), 0.5)
    target_u = clamp(float(scheme.get('target_degree_of_consolidation_pct', 90.0)) / 100.0, 0.5, 0.98)
    de = 1.05 * spacing
    time_days = (de ** 2 / cv) * max(math.log(1.0 / (1.0 - target_u)) / 8.0, 0.1)
    eq_height = vacuum / 18.0
    suitability = 'good' if fines >= 35 and thickness >= 4.0 else 'conditional' if fines >= 20 else 'poor'
    latest_u = float(latest_row(monitoring_rows).get('degree_of_consolidation_pct', 0.0))
    warnings = []
    if suitability == 'poor':
        warnings.append('coarse or low-fines ground is usually a weak fit for vacuum consolidation as the primary method.')
    metrics = {
        'suitability': suitability,
        'vacuum_equivalent_fill_height_m': round(eq_height, 2),
        'estimated_time_to_target_u_days': round(time_days, 1),
        'observed_degree_of_consolidation_pct': round(latest_u, 1),
        'preload_height_m': round(preload_h, 2),
    }
    steps = [
        'screen surcharge plus vacuum against soft-ground consolidation objectives.',
        f"vacuum-preload suitability: {suitability}.",
        'use observed consolidation and settlement rate to confirm removal timing later.',
    ]
    return metrics, warnings, steps


def grouting_screen(ground_model, scheme):
    weak = weakest_stratum(ground_model['strata'], float(scheme.get('improvement_depth_m', 8.0)))
    fines = float(weak.get('fines_percent', 35.0))
    k = float(weak.get('permeability_m_s', 1e-7))
    d10 = float(scheme.get('groutability_d10_mm', weak.get('d10_mm', 0.1)))
    d15 = float(scheme.get('groutability_d15_mm', weak.get('d15_mm', 0.15)))
    phi = float(weak.get('phi_deg', 25.0))
    loose_depth = float(scheme.get('loose_granular_zone_depth_m', 0.0))
    permeation_score = 25 + (25 if fines <= 15 else 5) + (20 if k >= 1e-5 else 0) + (10 if d15 > 0.2 and d10 > 0.08 else 0)
    compaction_score = 22 + (18 if phi >= 30 else 8) + (12 if loose_depth > 0 else 4) + (8 if fines <= 25 else 0)
    preferred = 'permeation_grouting' if permeation_score >= compaction_score else 'compaction_grouting'
    warnings = []
    if permeation_score < 45 and preferred == 'permeation_grouting':
        warnings.append('permeation groutability is weak and should be confirmed with particle-size and trial data.')
    metrics = {
        'preferred_grouting_method': preferred,
        'permeation_grouting_score': int(clamp(permeation_score, 0, 100)),
        'compaction_grouting_score': int(clamp(compaction_score, 0, 100)),
        'governing_fines_percent': round(fines, 1),
        'governing_permeability_m_s': k,
        'd10_mm': round(d10, 3),
        'd15_mm': round(d15, 3),
    }
    steps = [
        'screen groutability and densification potential using fines, permeability, and particle-size hints.',
        f"preferred method after screening: {preferred.replace('_', ' ')}.",
        'keep another improvement family available when both scores are weak or close.',
    ]
    return metrics, warnings, steps


def gi_qa(ground_model, scheme, monitoring_rows):
    latest = latest_row(monitoring_rows)
    target_su = float(scheme.get('target_dsm_strength_kPa', scheme.get('target_su_kPa', 200.0)))
    achieved_su = float(latest.get('treated_strength_kPa', 0.0))
    target_ratio = float(scheme.get('stone_column_area_ratio_target', 0.18))
    achieved_ratio = float(latest.get('achieved_replacement_ratio', 0.0))
    target_u = float(scheme.get('target_degree_of_consolidation_pct', 90.0))
    achieved_u = float(latest.get('degree_of_consolidation_pct', 0.0))
    strength_ratio = achieved_su / max(target_su, 1.0)
    replacement_ratio = achieved_ratio / max(target_ratio, 0.01)
    consolidation_ratio = achieved_u / max(target_u, 1.0)
    governing = min(strength_ratio, replacement_ratio if target_ratio > 0 else 1.0, consolidation_ratio)
    if governing >= 1.0:
        status = 'pass'
    elif governing >= 0.85:
        status = 'warning'
    else:
        status = 'fail'
    warnings = []
    if strength_ratio < 1.0:
        warnings.append('observed treated strength is below the target value.')
    if target_ratio > 0 and replacement_ratio < 1.0:
        warnings.append('achieved replacement ratio is below the target.')
    if consolidation_ratio < 1.0:
        warnings.append('observed consolidation progress is below the target level.')
    metrics = {
        'qa_status': status,
        'strength_achievement_ratio': round(strength_ratio, 2),
        'replacement_ratio_achievement': round(replacement_ratio, 2) if target_ratio > 0 else None,
        'consolidation_achievement_ratio': round(consolidation_ratio, 2),
        'governing_achievement_ratio': round(governing, 2),
    }
    steps = [
        'compare achieved qa or qc indicators against the stated treatment targets.',
        f"ground improvement qa status: {status}.",
        'carry deficiencies forward into the reviewer layer instead of assuming treatment success.',
    ]
    return metrics, warnings, steps


def run_mode(mode, ground_model, slope_scheme, embankment_scheme, gi_scheme, monitoring_rows):
    if mode == 'slope_mechanism':
        return slope_mechanism(ground_model, slope_scheme, monitoring_rows)
    if mode == 'slope_review':
        return slope_review(ground_model, slope_scheme)
    if mode == 'rainfall_drawdown':
        return rainfall_drawdown_review(slope_scheme, monitoring_rows)
    if mode == 'embankment_stage':
        return embankment_stage_review(ground_model, embankment_scheme)
    if mode == 'preload_control':
        return preload_control(ground_model, embankment_scheme, monitoring_rows)
    if mode == 'slope_instrumentation':
        return slope_instrumentation(monitoring_rows, slope_scheme)
    if mode == 'gi_option_screen':
        return gi_option_screen(ground_model, gi_scheme)
    if mode == 'stone_columns':
        return stone_columns(ground_model, gi_scheme)
    if mode == 'dsm_jet':
        return dsm_jet(ground_model, gi_scheme)
    if mode == 'vacuum_preload':
        return vacuum_preload(ground_model, gi_scheme, monitoring_rows)
    if mode == 'grouting_screen':
        return grouting_screen(ground_model, gi_scheme)
    if mode == 'gi_qa':
        return gi_qa(ground_model, gi_scheme, monitoring_rows)
    raise ValueError(f'unsupported mode: {mode}')


def build_report(metrics, warnings, steps):
    lines = [
        f"# {PROFILE['display_name']}",
        '',
        '## Summary',
        PROFILE['summary'].capitalize(),
        '',
        '## Key metrics',
    ]
    for key, value in metrics.items():
        if isinstance(value, (list, dict)):
            continue
        lines.append(f"- {key.replace('_', ' ')}: {value}")
    lines.extend(['', '## Engineering workflow'])
    for step in steps:
        lines.append(f"- {step}")
    lines.extend(['', '## Warnings'])
    if warnings:
        for warning in warnings:
            lines.append(f"- {warning}")
    else:
        lines.append('- no blocking warnings in the standalone screening run.')
    list_metrics = {k: v for k, v in metrics.items() if isinstance(v, list)}
    dict_metrics = {k: v for k, v in metrics.items() if isinstance(v, dict)}
    if list_metrics or dict_metrics:
        lines.extend(['', '## Structured details'])
        if list_metrics:
            for key, value in list_metrics.items():
                lines.append(f"### {key.replace('_', ' ')}")
                for item in value:
                    if isinstance(item, dict):
                        lines.append('```json')
                        lines.append(json.dumps(item, indent=2))
                        lines.append('```')
                    else:
                        lines.append(f"- {item}")
        if dict_metrics:
            for key, value in dict_metrics.items():
                lines.append(f"### {key.replace('_', ' ')}")
                lines.append('```json')
                lines.append(json.dumps(value, indent=2))
                lines.append('```')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-dir', default=str(Path(__file__).resolve().parent.parent / 'assets' / 'example-inputs'))
    parser.add_argument('--output-dir', default=str(Path(__file__).resolve().parent.parent / 'outputs'))
    args = parser.parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ground_model = load_json(input_dir / 'ground_model.json')
    slope_scheme = load_json(input_dir / 'slope_scheme.json') if (input_dir / 'slope_scheme.json').exists() else {}
    embankment_scheme = load_json(input_dir / 'embankment_scheme.json') if (input_dir / 'embankment_scheme.json').exists() else {}
    gi_scheme = load_json(input_dir / 'ground_improvement_scheme.json') if (input_dir / 'ground_improvement_scheme.json').exists() else {}
    monitoring_rows = load_csv(input_dir / 'monitoring.csv')

    metrics, warnings, steps = run_mode(PROFILE['mode'], ground_model, slope_scheme, embankment_scheme, gi_scheme, monitoring_rows)
    handoff = {
        'skill': PROFILE['name'],
        'mode': PROFILE['mode'],
        'summary': PROFILE['summary'],
        'metrics': metrics,
        'warnings': warnings,
        'assumptions': [
            'standalone skill output is a production-oriented screening or reviewer layer.',
            'project-specific numerical models, laboratory data, field trials, and code checks remain necessary where flagged.'
        ],
        'recommended_next_tools': PROFILE.get('recommended_next_tools', []),
    }
    artifact_map = {
        'skill': PROFILE['name'],
        'artifacts': {
            'ground-model': 'reuse existing project ground-model dataset where available',
            'analysis-plan': f"attach {PROFILE['name']} workflow output to the analysis-plan or reviewer layer",
            'results': 'store computed metrics and structured details in results or option-matrix artifacts',
            'review-checklist': 'store warnings, trigger states, and audit findings where this skill is used as a reviewer',
            'final-report': 'append engineering_report.md summary to the final report only after review'
        }
    }

    (output_dir / 'swarm_handoff.json').write_text(json.dumps(handoff, indent=2))
    (output_dir / 'engineering_report.md').write_text(build_report(metrics, warnings, steps))
    (output_dir / 'case_file_artifact_map.json').write_text(json.dumps(artifact_map, indent=2))
    print(json.dumps({'status': 'ok', 'skill': PROFILE['name'], 'output_dir': str(output_dir)}, indent=2))


if __name__ == '__main__':
    main()
