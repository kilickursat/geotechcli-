---
name: natm-support-selection
description: select a preliminary conventional tunnelling support class using span, overburden, groundwater, rock mass indices, and monitoring indicators. use when the task is in geotechnical engineering and needs a repeatable conventional tunnelling, rock engineering, or underground support workflow. use when the task matches natm support selection and should produce swarm handoff json, engineering markdown, and case-file artifact mapping from local files.
---

# NATM Support Selection

## Overview

Use this skill to make the agent more reliable in conventional tunnelling, rock engineering, and underground geotechnical workflows. The skill wraps a deterministic standalone tool, a strict local-file contract, and a repeatable engineering output pattern.

## Workflow

1. Confirm that the required local files exist. Read `references/input-contract.md`.
2. Identify the governing underground, rock mass, groundwater, support, or lining conditions from the input files.
3. Run the standalone tool script.
4. Review `swarm_handoff.json`, `engineering_report.md`, and `case_file_artifact_map.json`.
5. If the result is marginal or warning-heavy, route the output to a reviewer or follow-on skill instead of treating it as final design.

## Tooling

```bash
python scripts/natm_support_selection.py --input-dir <path/to/input-dir> --output-dir <path/to/output-dir>
```

## Inputs

- `ground_model.json`
- `tunnel_rock_config.json`
- `monitoring.csv`

## Outputs

- `swarm_handoff.json`
- `engineering_report.md`
- `case_file_artifact_map.json`
