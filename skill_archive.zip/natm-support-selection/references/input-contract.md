# Input contract

Use these local files for all Wave 5 conventional tunnelling and rock-engineering skills:

- `ground_model.json`
- `tunnel_rock_config.json`
- `monitoring.csv`

Treat missing fields conservatively and state the missing items in the outputs.
