# Design basis

This skill is a production-oriented screening and review workflow for natm support selection. Do not treat it as a substitute for project-specific numerical modelling, structural checks, or final code-governed design.
