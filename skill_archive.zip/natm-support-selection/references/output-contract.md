# Output contract

Every run must write these three files:

1. `swarm_handoff.json`
2. `engineering_report.md`
3. `case_file_artifact_map.json`

Keep outputs reviewable, screening-level, and ready for later case-file promotion.
