# NATM Support Selection

- Preliminary support class: moderate
- Shotcrete: 150 mm
- Rock bolts: 4.0 m @ 1.5 x 1.5 m
- Steel ribs: no
- Average wall convergence: 24.7 mm
