#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

def rj(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def rc(p):
    rows=[]
    with open(p, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            clean={}
            for k,v in row.items():
                v=v.strip()
                try:
                    clean[k]=float(v) if '.' in v else int(v)
                except Exception:
                    clean[k]=v
            rows.append(clean)
    return rows

def mean(vals):
    vals=[v for v in vals if isinstance(v,(int,float))]
    return sum(vals)/len(vals) if vals else 0

def write_outputs(out, handoff, report, artifact):
    out.mkdir(parents=True, exist_ok=True)
    (out/'swarm_handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf-8')
    (out/'engineering_report.md').write_text(report, encoding='utf-8')
    (out/'case_file_artifact_map.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--output-dir', required=True)
    args=ap.parse_args()
    inp=Path(args.input_dir)
    out=Path(args.output_dir)
    gm=rj(inp/'ground_model.json')
    cfg=rj(inp/'tunnel_rock_config.json')
    mon=rc(inp/'monitoring.csv')

    rmr=gm.get('rmr',0); q=gm.get('q_value',0); conv=mean([r.get('wall_convergence_mm',0) for r in mon])
    if rmr>=60 and q>=4 and conv<20:
        support='light'; shot=100; bolts='3.0 m @ 2.0 x 2.0 m'; ribs=False
    elif rmr>=45 and q>=1.5 and conv<30:
        support='moderate'; shot=150; bolts='4.0 m @ 1.5 x 1.5 m'; ribs=False
    elif rmr>=30 and q>=0.4:
        support='heavy'; shot=220; bolts='5.0 m @ 1.25 x 1.25 m'; ribs=True
    else:
        support='very-heavy'; shot=280; bolts='5.5 m @ 1.0 x 1.0 m'; ribs=True
    handoff={'skill':'natm-support-selection','status':'review','support_class':support,'shotcrete_mm':shot,'bolts':bolts,'steel_ribs':ribs}
    report = '\n'.join([
        '# NATM Support Selection','',
        f'- Preliminary support class: {support}',
        f'- Shotcrete: {shot} mm',
        f'- Rock bolts: {bolts}',
        f"- Steel ribs: {'yes' if ribs else 'no'}",
        f'- Average wall convergence: {conv:.1f} mm',''
    ])
    artifact={'artifacts':[{'kind':'tunnel-support-screening','title':'natm support selection','path':'engineering_report.md'}]}
    write_outputs(out, handoff, report, artifact)


if __name__=='__main__':
    main()
