# Rainfall And Drawdown Trigger Review

## Summary
Review rainfall, pore-pressure change, and drawdown triggers for slope risk escalation and observational hold points.

## Key metrics
- rainfall 24h ratio: 1.2
- rainfall 72h ratio: 1.2
- drawdown ratio: 1.12
- inclinometer ratio: 1.2
- overall trigger state: red
- recommended action: hold work, inspect drainage and pore-pressure state, and escalate geotechnical review.
- governing ratio: 1.2

## Engineering workflow
- compare rainfall, drawdown, and movement against predefined trigger limits.
- overall trigger state: red.
- treat the result as an observational-method control output, not a design capacity calculation.

## Warnings
- trigger state is red and requires explicit action.
