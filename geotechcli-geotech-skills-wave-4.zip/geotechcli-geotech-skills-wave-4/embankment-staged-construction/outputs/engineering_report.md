# Embankment Staged Construction

## Summary
Screen staged embankment raising against short-term stability, settlement buildup, and required stage holds.

## Key metrics
- governing stage fos: 1.37
- maximum stage settlement mm: 509.5
- overall stage status: pass

## Engineering workflow
- review each embankment stage against short-term undrained stability and settlement growth.
- overall staged construction status: pass.
- use the result to place hold points or preload continuation in the construction sequence.

## Warnings
- no blocking warnings in the standalone screening run.

## Structured details
### stage register
```json
{
  "stage": 1,
  "height_m": 2.5,
  "hold_days": 14.0,
  "screened_fos": 3.05,
  "predicted_total_settlement_mm": 270.3,
  "status": "pass"
}
```
```json
{
  "stage": 2,
  "height_m": 5.0,
  "hold_days": 21.0,
  "screened_fos": 1.87,
  "predicted_total_settlement_mm": 405.0,
  "status": "pass"
}
```
```json
{
  "stage": 3,
  "height_m": 7.5,
  "hold_days": 28.0,
  "screened_fos": 1.37,
  "predicted_total_settlement_mm": 509.5,
  "status": "pass"
}
```
