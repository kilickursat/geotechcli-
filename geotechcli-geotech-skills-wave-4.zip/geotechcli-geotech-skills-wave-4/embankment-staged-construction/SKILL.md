---
name: embankment-staged-construction
description: screen staged embankment raising against short-term stability, settlement buildup, and required stage holds. use when the task is in geotechnical engineering and needs a repeatable wave 4 workflow. use when the task is to screen, review, or structure decisions for embankment staged construction from local files. this skill is for standalone packaged execution with local files and should produce swarm handoff json, engineering markdown, and case-file artifact mapping.
---

# Embankment Staged Construction

## Overview

Use this skill to make the agent more reliable in Wave 4 geotechnical workflows. The skill wraps a deterministic standalone tool, a strict local-file contract, and a repeatable engineering output pattern.

## Workflow

1. Confirm that the required local files exist. Read the shared contract in `references/input-contract.md`.
2. Identify the governing slope, embankment, groundwater, instrumentation, or treatment conditions from the input files.
3. Run the standalone tool script.
4. Review `swarm_handoff.json`, `engineering_report.md`, and `case_file_artifact_map.json`.
5. If the result is marginal, warning-heavy, or reviewer-oriented, route the output to a reviewer or follow-on skill instead of treating it as final design.

## What this skill is trying to answer

- review stage-by-stage embankment raising rather than one final geometry only.
- screen undrained stability margin and cumulative settlement at each stage.
- define where holds or preload continuation are needed.

## Tooling

Run the deterministic script like this:

```bash
python scripts/embankment_staged_construction.py --input-dir <path/to/input-dir> --output-dir <path/to/output-dir>
```

The default bundled input directory is `assets/example-inputs/` and the default output directory is `outputs/`.

## Inputs

- Use `ground_model.json` as the geotechnical baseline.
- Use `slope_scheme.json` for slope and instrumentation tasks.
- Use `embankment_scheme.json` for staged fill, preload, and consolidation tasks.
- Use `ground_improvement_scheme.json` for treatment option and qa workflows.
- Use `monitoring.csv` when trigger logic, observational control, or qa review matters.

Read the exact contract in `references/input-contract.md`.

## Output contract

Always keep the three-output pattern.

- `swarm_handoff.json` for machine-readable orchestration
- `engineering_report.md` for the engineering note
- `case_file_artifact_map.json` for deterministic storage mapping

Read the details in `references/output-contract.md`.

## Design basis

Keep the skill universal and production-oriented. Use the overview in `references/design-basis.md` and explicitly state when project-specific code checks, field trials, or specialist numerical models are still required.

## Repo integration

If this standalone skill is later promoted into geotechCLI itself, use `references/repo-integration.md` to convert the logic into `packages/core/src/geo/`, register tools, add guardrails, expose swarm access, and add tests.
