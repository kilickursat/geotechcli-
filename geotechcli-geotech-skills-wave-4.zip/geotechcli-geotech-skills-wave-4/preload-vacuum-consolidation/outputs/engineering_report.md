# Preload Vacuum Consolidation

## Summary
Screen surcharge preload, pvd acceleration, and vacuum consolidation for soft-ground settlement control.

## Key metrics
- suitability: good
- vacuum equivalent fill height m: 4.44
- estimated time to target u days: 3.0
- observed degree of consolidation pct: 79.0
- preload height m: 1.5

## Engineering workflow
- screen surcharge plus vacuum against soft-ground consolidation objectives.
- vacuum-preload suitability: good.
- use observed consolidation and settlement rate to confirm removal timing later.

## Warnings
- no blocking warnings in the standalone screening run.
