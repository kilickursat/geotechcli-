# geotechCLI geotechnical skills - wave 4

This workspace contains the Wave 4 standalone skill bundle for geotechCLI.

Packs included:
- slopes and embankments
- ground improvement

Each skill folder is ready to package individually and already includes:
- SKILL.md
- agents/openai.yaml
- deterministic python tool script
- bundled example inputs
- shared reference files
- tri-output contract

Dist packages are written under `dist/<skill-name>/skill.zip`.
