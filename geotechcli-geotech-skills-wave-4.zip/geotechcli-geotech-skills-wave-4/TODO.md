# Wave 4 to-do follow-up

1. Promote high-value logic into `packages/core/src/geo/`.
2. Register matching tools in `packages/core/src/agents/tools.ts`.
3. Add guardrails for slope trigger logic, embankment staging, preload control, and ground improvement screening.
4. Add swarm allowlist entries.
5. Add direct CLI commands where repeated workflows justify them.
6. Add repo tests aligned with the standalone output patterns.
