# Ground Improvement Option Screening

## Summary
Screen broad ground improvement options against soil type, groundwater, improvement depth, and performance objectives.

## Key metrics
- preferred option: dsm
- preferred option score: 85

## Engineering workflow
- screen broad ground improvement families against soil type, depth, groundwater, and objective.
- preferred option after screening: dsm.
- keep at least one alternative alive when the score spread is narrow or warning-heavy.

## Warnings
- no blocking warnings in the standalone screening run.

## Structured details
### option shortlist
```json
{
  "option": "dsm",
  "score": 85
}
```
```json
{
  "option": "preload_pvd",
  "score": 81
}
```
```json
{
  "option": "jet_grouting",
  "score": 73
}
```
```json
{
  "option": "stone_columns",
  "score": 60
}
```
```json
{
  "option": "compaction_grouting",
  "score": 45
}
```
```json
{
  "option": "permeation_grouting",
  "score": 26
}
```
