# Preload And Consolidation Control

## Summary
Control preload, surcharge, pvd spacing, and consolidation progress using staged settlement and degree-of-consolidation checks.

## Key metrics
- predicted preload settlement mm: 371.8
- estimated time to target u days: 3.0
- baseline time without drains days: 270.2
- observed degree of consolidation pct: 79.0
- predicted target time days: 3.0
- recommended action: continue preload and maintain monitoring until the target degree of consolidation is reached.

## Engineering workflow
- estimate preload settlement and accelerated time to the target degree of consolidation.
- compare observed consolidation progress against the target.
- recommended preload control action: continue preload and maintain monitoring until the target degree of consolidation is reached.

## Warnings
- no blocking warnings in the standalone screening run.
