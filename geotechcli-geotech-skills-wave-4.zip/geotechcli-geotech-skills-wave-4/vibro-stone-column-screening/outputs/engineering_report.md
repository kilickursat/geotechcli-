# Vibro Stone Column Screening

## Summary
Screen vibro replacement or stone columns for settlement reduction, bearing improvement, and constructability fit.

## Key metrics
- area replacement ratio: 0.094
- screened settlement reduction factor: 0.8
- screened bearing improvement factor: 1.33
- suitability: poor
- governing fines percent: 85.0

## Engineering workflow
- estimate area replacement ratio from column spacing and diameter.
- screen settlement reduction and bearing improvement at conceptual level.
- stone-column suitability: poor.

## Warnings
- high fines content weakens vibro replacement efficiency and stone-column constructability.
