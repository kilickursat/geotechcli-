# Deep Soil Mixing And Jet Grouting Screening

## Summary
Screen deep soil mixing and jet grouting for strength gain, cutoff value, depth, and treatment geometry.

## Key metrics
- recommended method: deep_soil_mixing
- screened strength gain ratio: 1.96
- indicative dsm binder kg m3: 250.0
- indicative jet grout column diameter m: 1.27
- dsm score: 88
- jet grouting score: 82

## Engineering workflow
- compare dsm and jet grouting against soil type, depth, groundwater, and strength objective.
- recommended method after screening: deep soil mixing.
- leave detailed mix design, spoil handling, and production trials to the project-specific phase.

## Warnings
- no blocking warnings in the standalone screening run.
