# Permeation And Compaction Grouting

## Summary
Screen permeation and compaction grouting using fines, permeability, particle size, and improvement objective.

## Key metrics
- preferred grouting method: compaction_grouting
- permeation grouting score: 40
- compaction grouting score: 42
- governing fines percent: 85.0
- governing permeability m s: 2e-09
- d10 mm: 0.12
- d15 mm: 0.35

## Engineering workflow
- screen groutability and densification potential using fines, permeability, and particle-size hints.
- preferred method after screening: compaction grouting.
- keep another improvement family available when both scores are weak or close.

## Warnings
- no blocking warnings in the standalone screening run.
