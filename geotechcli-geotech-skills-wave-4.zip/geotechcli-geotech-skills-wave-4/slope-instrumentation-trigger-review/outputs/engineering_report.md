# Slope Instrumentation Trigger Review

## Summary
Review inclinometer, crest settlement, toe movement, crack, and piezometer trends for slope trigger management.

## Key metrics
- crest settlement ratio: 1.08
- toe movement ratio: 1.0
- crack ratio: 1.2
- piezometer ratio: 0.8
- inclinometer ratio: 1.2
- overall trigger state: red
- recommended action: stop the next work step, inspect the slope, and execute the response plan.
- governing ratio: 1.2

## Engineering workflow
- compare instrumentation movements and pore-pressure response to trigger limits.
- overall trigger state: red.
- treat the result as a field decision aid for the observational method.

## Warnings
- instrumentation trigger state is red.
