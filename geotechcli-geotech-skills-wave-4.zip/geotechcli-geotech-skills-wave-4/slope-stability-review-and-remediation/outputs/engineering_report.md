# Slope Stability Review And Remediation

## Summary
Review screened slope stability, classify the margin, and recommend drainage, geometry, or reinforcement remedies.

## Key metrics
- governing stratum: Soft high plasticity clay
- phi deg: 20.0
- screened cohesion kPa: 5.6
- governing screened fos: 0.27
- water factor: 0.55
- seismic factor: 1.16
- surcharge factor: 1.07
- stability status: poor
- primary remediation: improve crest and sub-surface drainage before committing to geometry changes.

## Engineering workflow
- screen the governing factor of safety using a simplified slope review relationship.
- classify the preliminary stability state as poor.
- recommend drainage, geometry, or reinforcement as follow-on actions rather than treating the screening result as final design.

## Warnings
- screened factor of safety is not comfortably above a preliminary service margin.
- water control is likely to be a major driver of remediation choice.

## Structured details
### recommended remedies
- improve crest and sub-surface drainage before committing to geometry changes.
- consider a toe berm, buttress fill, or structural reinforcement.
