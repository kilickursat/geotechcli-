---
name: tunnel-engineering-reviewer
description: universal tunnel engineering review for tbm (epb, slurry, hard rock), natm, sem, and hybrid tunneling. use when validating tunnel design, checking support adequacy, reviewing construction risks, or enforcing observational method workflows from structured inputs or natural language.
---

# Tunnel Engineering Reviewer

## Input Modes
Accept:
1. Structured files
2. Natural language

## Workflow
1. Normalize inputs
2. Run tools
3. Evaluate:
   - method compatibility
   - support adequacy
   - deformation vs support
   - construction risks
   - observational method

## Output
### Markdown
Engineering review report

### JSON
{
  "method_valid": true,
  "support_adequate": false,
  "deformation_risk": "moderate",
  "critical_risks": [],
  "observational_ready": false,
  "overall_status": "REQUIRES_REVISION"
}

## Rules
- Always produce a verdict
- Always flag missing monitoring
- Prefer conservative engineering judgment
