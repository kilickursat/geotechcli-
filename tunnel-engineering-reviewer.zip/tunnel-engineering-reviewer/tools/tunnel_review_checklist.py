def review_checklist(data):
    issues = []
    if data.get("method") == "EPB" and data.get("ground_type") == "rock":
        issues.append("EPB unsuitable for rock")
    return {"issues": issues, "status": "OK" if not issues else "REVIEW_REQUIRED"}
