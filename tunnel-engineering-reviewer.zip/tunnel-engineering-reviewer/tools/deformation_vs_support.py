def deformation_check(data):
    if data.get("expected_convergence_mm",0) > data.get("support_capacity_mm",0):
        return {"risk":"high","message":"Support overstressed"}
    return {"risk":"low","message":"Within limits"}
