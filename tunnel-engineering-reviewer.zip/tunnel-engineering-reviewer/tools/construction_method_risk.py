def construction_risk(data):
    risks = []
    if data.get("groundwater") == "high":
        risks.append("Water ingress risk")
    if data.get("cover_m",0) < 10:
        risks.append("Low cover instability risk")
    return {"risks": risks}
