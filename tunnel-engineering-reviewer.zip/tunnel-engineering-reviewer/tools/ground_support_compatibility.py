def check_support(data):
    if data.get("ground_class") == "very_weak" and data.get("support_type") == "light":
        return {"compatible": False, "message": "Support insufficient"}
    return {"compatible": True, "message": "Support OK"}
